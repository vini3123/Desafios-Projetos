# Workshop: Criando Agentes de IA com MCP em C#

## 📋 Índice

- [Sobre este Workshop](#sobre-este-workshop)
- [Pré-requisitos](#pré-requisitos)
- [Configuração do Ambiente](#configuração-do-ambiente)
- [Módulo 1: Fundamentos do MCP](#módulo-1-fundamentos-do-mcp)
- [Módulo 2: Primeiro MCP Server com Tools](#módulo-2-primeiro-mcp-server-com-tools)
- [Módulo 3: Trabalhando com Prompts](#módulo-3-trabalhando-com-prompts)
- [Módulo 4: Conexão Local (stdio)](#módulo-4-conexão-local-stdio)
- [Módulo 5: Conexão Remota (HTTP)](#módulo-5-conexão-remota-http)
- [Módulo 6: Integração com Clientes de IA](#módulo-6-integração-com-clientes-de-ia)
- [Troubleshooting](#troubleshooting)
- [Recursos Adicionais](#recursos-adicionais)

---

## Sobre este Workshop

Este workshop ensina como criar **agentes de IA** usando o **Model Context Protocol (MCP)** em C#. O MCP é um protocolo aberto que padroniza como aplicações fornecem contexto para Large Language Models (LLMs).

### O que você vai aprender

- ✅ Criar MCP Servers em C#
- ✅ Implementar Tools (ferramentas) que LLMs podem usar
- ✅ Criar Prompts reutilizáveis
- ✅ Conectar servidores localmente (stdio) e remotamente (HTTP)
- ✅ Integrar com GitHub Copilot e ferramentas de IA
- ✅ Debugar comunicação com MCP Inspector

### Estrutura Real do Projeto

Este workshop contém implementações funcionais prontas para uso:

```text
src/
├── ToolsServer/              → Servidor com ferramentas (calculadora + texto)
├── PromptsServer/            → Servidor com prompts para LLMs
│   └── PromptsServer/
├── ClienteLocal/             → Cliente stdio (conexão local)
│   └── McpClient/
├── ClienteRemoto/            → Cliente HTTP (conexão remota)
│   └── HttpMcpClient/
└── ServidorRemoto/           → Servidor HTTP
    └── HttpMcpServer/
```

**Cada projeto está completo e pode ser executado independentemente!**

---

## Pré-requisitos

### Software Necessário

1. **Visual Studio Code**
   - Instalar de: <https://code.visualstudio.com/>

2. **.NET 9.0 SDK** (ou superior)

   ```powershell
   dotnet --version
   # Deve retornar 9.0 ou superior
   ```

   - Instalar de: <https://dotnet.microsoft.com/download>

3. **Node.js (v18+)** - para ferramentas auxiliares

   ```powershell
   node --version
   npm --version
   ```

   - Instalar de: <https://nodejs.org/>

4. **MCP Inspector** (para debug)

   ```powershell
   npm install -g @modelcontextprotocol/inspector
   ```

5. **GitHub Copilot CLI** (opcional)

   ```powershell
   npm install -g @githubnext/github-copilot-cli
   ```

### Extensões do VS Code Recomendadas

- C# Dev Kit
- C# (Microsoft)
- REST Client (para testar endpoints HTTP)

### Conhecimentos Prévios

- C# básico a intermediário
- Conceitos de async/await
- JSON básico
- Linha de comando (PowerShell)

---

## Configuração do Ambiente

### 1. Clone ou Baixe este Repositório

```powershell
git clone <url-do-repositorio>
cd Agentes
```

### 2. Estrutura do Projeto

```text
Agentes/
├── README.md (este arquivo)
├── src/
│   ├── ToolsServer/           # Servidor MCP com ferramentas (calculadora, texto)
│   ├── PromptsServer/         # Servidor MCP com prompts reutilizáveis
│   │   └── PromptsServer/
│   ├── ClienteLocal/          # Cliente MCP usando conexão stdio
│   │   └── McpClient/
│   ├── ClienteRemoto/         # Cliente MCP usando conexão HTTP
│   │   └── HttpMcpClient/
│   └── ServidorRemoto/        # Servidor MCP acessível via HTTP
│       └── HttpMcpServer/
├── configs/
│   ├── copilot-config.json
│   └── copilot-cli-config.json
└── docs/
    └── referencias.md
```

### 3. Compilar Todos os Projetos

```powershell
# Compilar solução principal (todos os projetos)
cd src
dotnet build AgentesWorkShop.sln

# Ou compilar individualmente:

# ToolsServer
cd ToolsServer
dotnet build

# PromptsServer
cd ..\PromptsServer\PromptsServer
dotnet build

# ClienteLocal
cd ..\..\ClienteLocal\McpClient
dotnet build

# ServidorRemoto
cd ..\..\ServidorRemoto\HttpMcpServer
dotnet build

# ClienteRemoto
cd ..\..\ClienteRemoto\HttpMcpClient
dotnet build
```

### 4. Informações Importantes

**Versões Utilizadas:**

- .NET: 9.0
- ModelContextProtocol: 0.4.0-preview.1
- ModelContextProtocol.AspNetCore: 0.4.0-preview.1
- Microsoft.Extensions.Hosting: 9.0.9

**Principais Mudanças em Relação à Versão Inicial:**

- ✅ Uso correto de `McpClient.CreateAsync()` com opções configuráveis
- ✅ Implementação de `ServerInfo` e `ServerInstructions` para melhor contexto
- ✅ Configuração de logging para stderr (separado do protocolo)
- ✅ Uso de `MapMcp()` simplificado para servidores HTTP
- ✅ Suporte a `HttpClientTransport` com auto-detecção de modo
- ✅ Tratamento robusto de conteúdo (TextContentBlock vs JsonContentBlock)
- ✅ Configurações de timeout e capabilities no cliente
- ✅ Atributo `[McpServerTool(Name = "...")]` para nomes explícitos

---

## Módulo 1: Fundamentos do MCP

### O que é MCP?

O **Model Context Protocol** permite que LLMs acessem ferramentas e dados de forma padronizada. Pense nele como uma "API universal" para LLMs.

**Componentes principais:**
- **Server**: Expõe ferramentas (tools) e prompts
- **Client**: Conecta-se ao servidor e usa suas capacidades
- **Transport**: Canal de comunicação (stdio ou HTTP)

### Conceitos Importantes

#### 1. Tools (Ferramentas)
Funções que o LLM pode chamar para executar ações:
```csharp
[McpServerTool(Name = "add"), Description("Soma dois números")]
public static double Add(
    [Description("Primeiro número")] double a,
    [Description("Segundo número")] double b)
{
    return a + b;
}
```

**⚠️ Pontos de Atenção:**
- Use o atributo `Name` explicitamente para controlar o nome da tool
- Sempre adicione `Description` para parâmetros e métodos
- Ferramentas devem ser `static` e marcadas com `[McpServerTool]`
- A classe deve ser marcada com `[McpServerToolType]`

#### 2. Prompts
Templates reutilizáveis para interações com LLM:
```csharp
[McpServerPrompt(Name = "code_review"), Description("Cria um prompt de revisão de código")]
public static ChatMessage CodeReview(
    [Description("Código para revisar")] string code,
    [Description("Linguagem de programação")] string language = "C#")
{
    return new ChatMessage(ChatRole.User, 
        $"Revise o seguinte código {language} e forneça sugestões de melhoria:\n\n{code}");
}
```

**⚠️ Pontos de Atenção:**
- Use `ChatMessage` do namespace `Microsoft.Extensions.AI`
- Prompts devem retornar `ChatMessage` com role apropriado
- A classe deve ser marcada com `[McpServerPromptType]`

#### 3. Resources
Dados que o servidor pode fornecer (arquivos, URLs, etc.) - não implementado neste workshop básico.

---

## Módulo 2: Primeiro MCP Server com Tools

### Objetivo
Criar um servidor MCP simples que expõe ferramentas úteis usando transporte stdio.

### Localização
[`src/ToolsServer/`](src/ToolsServer/)

### Estrutura do Projeto

O projeto utiliza:
- **.NET 9.0** como framework
- **ModelContextProtocol 0.4.0-preview.1** - pacote principal do SDK
- **Microsoft.Extensions.Hosting 9.0.9** - para hospedagem e dependency injection

### Configuração do Servidor

**Pontos-chave da implementação:**

1. **Configuração de Logging:**
   ```csharp
   builder.Logging.AddConsole(options =>
   {
       options.LogToStandardErrorThreshold = LogLevel.Trace;
   });
   ```
   **⚠️ Importante:** O MCP usa stdout para comunicação do protocolo, então logs devem ir para stderr.

2. **Configuração do Servidor MCP:**
   ```csharp
   builder.Services
       .AddMcpServer(options =>
       {
           options.ServerInfo = new()
           {
               Name = "ToolsServer",
               Version = "1.0.0"
           };
           options.ServerInstructions = "Servidor MCP com ferramentas de calculadora e manipulação de texto.";
       })
       .WithStdioServerTransport()
       .WithToolsFromAssembly();
   ```
   **⚠️ Importante:** `ServerInfo` e `ServerInstructions` ajudam LLMs a entender as capacidades do servidor.

### Implementação das Tools

O servidor implementa duas categorias de ferramentas:

#### 1. **CalculatorTools** - Operações matemáticas

**Pontos-chave:**
```csharp
[McpServerToolType]
public static class CalculatorTools
{
    [McpServerTool(Name = "add"), Description("Soma dois números")]
    public static double Add(
        [Description("Primeiro número")] double a,
        [Description("Segundo número")] double b)
    {
        return a + b;
    }

    [McpServerTool(Name = "divide"), Description("Divide dois números")]
    public static double Divide(
        [Description("Numerador (dividendo)")] double a,
        [Description("Denominador (divisor)")] double b)
    {
        if (b == 0)
            throw new ArgumentException("Não é possível dividir por zero");
        return a / b;
    }
}
```

**⚠️ Pontos de Atenção:**
- Nomes explícitos com `Name = "..."` (camelCase)
- Validação de entrada (divisão por zero)
- Descrições claras para parâmetros

#### 2. **TextTools** - Manipulação de texto

**Pontos-chave:**
```csharp
[McpServerToolType]
public static class TextTools
{
    [McpServerTool(Name = "toUpperCase"), Description("Converte texto para maiúsculas")]
    public static string ToUpperCase(
        [Description("Texto a converter")] string text)
    {
        ArgumentException.ThrowIfNullOrEmpty(text, nameof(text));
        return text.ToUpper();
    }

    [McpServerTool(Name = "countWords"), Description("Conta o número de palavras no texto")]
    public static int CountWords(
        [Description("Texto para contar palavras")] string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return 0;
        
        return text.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length;
    }
}
```

**⚠️ Pontos de Atenção:**
- Validação robusta de entrada
- Tratamento de casos especiais (texto vazio, null)
- Retorno de tipos simples (string, int, double)

### Executar o Servidor

```powershell
cd src\ToolsServer
dotnet run
```

**💡 Dica:** O servidor aguardará conexões via stdin/stdout e não exibirá output visível até que um cliente se conecte.

### Referência Completa

Veja a implementação completa em [`src/ToolsServer/Program.cs`](../../d:/Agentes/src/ToolsServer/Program.cs)

### Exercício Prático

1. Adicione uma nova tool `IsPalindrome` que verifica se um texto é palíndromo
2. Adicione uma tool `Power` que calcula potenciação (base^expoente)
3. Teste suas tools com o MCP Inspector

---

## Módulo 3: Trabalhando com Prompts

### Objetivo

Criar prompts reutilizáveis que LLMs podem usar, combinados com tools auxiliares.

### Localização
[`src/PromptsServer/PromptsServer/`](src/PromptsServer/PromptsServer/)

### Estrutura do Projeto

O projeto utiliza:
- **ModelContextProtocol 0.4.0-preview.1** - para servidor e client
- **Microsoft.Extensions.AI** - para abstrações de chat (ChatMessage, ChatRole)

### Configuração do Servidor

**Pontos-chave:**

```csharp
builder.Services
    .AddMcpServer()
    .WithStdioServerTransport()
    .WithPromptsFromAssembly()
    .WithToolsFromAssembly();
```

**⚠️ Importante:** Este servidor expõe tanto prompts quanto tools auxiliares.

### Implementação dos Prompts

#### 1. **DeveloperPrompts** - Prompts para desenvolvimento

**Exemplo de implementação:**
```csharp
[McpServerPromptType]
public static class DeveloperPrompts
{
    [McpServerPrompt(Name = "code_review"), Description("Cria um prompt para revisão de código")]
    public static ChatMessage CodeReview(
        [Description("Código para revisar")] string code,
        [Description("Linguagem de programação")] string language = "C#")
    {
        return new ChatMessage(ChatRole.User, 
            $"Revise o seguinte código {language} e forneça sugestões de melhoria:\n\n{code}");
    }

    [McpServerPrompt(Name = "refactor_code"), Description("Cria um prompt para refatoração de código")]
    public static ChatMessage RefactorCode(
        [Description("Código para refatorar")] string code,
        [Description("Objetivo da refatoração")] string goal = "melhorar legibilidade")
    {
        return new ChatMessage(ChatRole.User, 
            $"Refatore este código com foco em {goal}:\n\n{code}");
    }
}
```

**⚠️ Pontos de Atenção:**
- Use `ChatMessage` com `ChatRole.User` para prompts
- Parâmetros opcionais têm valores padrão úteis
- Mantenha prompts focados e claros

#### 2. **WritingPrompts** - Prompts para redação

**Exemplo de implementação:**
```csharp
[McpServerPromptType]
public static class WritingPrompts
{
    [McpServerPrompt(Name = "summarize_text"), Description("Cria um prompt para resumir texto")]
    public static ChatMessage Summarize(
        [Description("Texto para resumir")] string content,
        [Description("Número máximo de palavras")] int maxWords = 100)
    {
        return new ChatMessage(ChatRole.User, 
            $"Resuma o seguinte texto em no máximo {maxWords} palavras:\n\n{content}");
    }

    [McpServerPrompt(Name = "translate_text"), Description("Cria um prompt para tradução de texto")]
    public static ChatMessage TranslateText(
        [Description("Texto para traduzir")] string text,
        [Description("Idioma de destino")] string targetLanguage = "inglês")
    {
        return new ChatMessage(ChatRole.User, 
            $"Traduza o seguinte texto para {targetLanguage}, mantendo o tom e contexto:\n\n{text}");
    }
}
```

### Tools Auxiliares

O servidor também expõe tools para ajudar a descobrir e validar prompts:

**Pontos-chave:**
```csharp
[McpServerToolType]
public static class PromptHelpers
{
    [McpServerTool(Name = "list_available_prompts"), Description("Lista todos os prompts disponíveis no servidor")]
    public static string ListAvailablePrompts()
    {
        return @"Prompts Disponíveis:

📝 DESENVOLVIMENTO:
  • code_review - Revisa código e fornece sugestões
  • explain_code - Explica o funcionamento do código
  ...";
    }

    [McpServerTool(Name = "get_prompt_info"), Description("Obtém informações detalhadas sobre um prompt específico")]
    public static string GetPromptInfo(
        [Description("Nome do prompt")] string promptName)
    {
        return promptName.ToLower() switch
        {
            "code_review" => "Revisa código em qualquer linguagem...",
            _ => $"Prompt '{promptName}' não encontrado."
        };
    }
}
```

**⚠️ Pontos de Atenção:**
- Tools auxiliares facilitam descoberta de prompts
- Use switch expressions para mapeamentos limpos
- Forneça mensagens úteis para casos de erro

### Executar o Servidor

```powershell
cd src\PromptsServer\PromptsServer
dotnet run
```

### Configuração para Claude Desktop

O projeto inclui um arquivo de exemplo [`claude_desktop_config.json`](../../d:/Agentes/src/PromptsServer/PromptsServer/claude_desktop_config.json) mostrando como configurar o servidor para uso com Claude Desktop.

### Referência Completa

Veja a implementação completa em [`src/PromptsServer/PromptsServer/Program.cs`](../../d:/Agentes/src/PromptsServer/PromptsServer/Program.cs)

### Exercício Prático

1. Crie um prompt `GenerateTests` que gera testes unitários
2. Adicione uma tool `validate_prompt_args` que valida argumentos JSON
3. Teste seus prompts com o cliente exemplo em [`ClientExample.txt`](../../d:/Agentes/src/PromptsServer/PromptsServer/ClientExample.txt)

---

## Módulo 4: Conexão Local (stdio)

### Objetivo

Criar um cliente que se conecta ao servidor MCP usando transporte stdio (standard input/output) para uso local.

### Localização
[`src/ClienteLocal/McpClient/`](src/ClienteLocal/McpClient/)

### O que é stdio?

**stdio** (standard input/output) permite que o servidor e cliente se comuniquem através de streams de entrada/saída padrão. É ideal para:

- ✅ Desenvolvimento local
- ✅ Ferramentas CLI
- ✅ Integração com editores (VS Code, etc.)
- ✅ Debug e testes rápidos

### Configuração do Cliente

**Pontos-chave da implementação:**

1. **Configuração de Logging:**
   ```csharp
   using var loggerFactory = LoggerFactory.Create(builder =>
   {
       builder
           .AddConsole()
           .SetMinimumLevel(LogLevel.Warning);
   });
   ```

2. **Criação do Transport:**
   ```csharp
   var clientTransport = new StdioClientTransport(new StdioClientTransportOptions
   {
       Name = "ToolsServerClient",
       Command = "dotnet",
       Arguments = ["run", "--project", "../../ToolsServer"],
   });
   ```

3. **Criação do Cliente com Opções:**
   ```csharp
   var clientOptions = new McpClientOptions
   {
       ClientInfo = new Implementation
       {
           Name = "McpClient Demo",
           Version = "1.0.0"
       },
       InitializationTimeout = TimeSpan.FromSeconds(30),
       Capabilities = new ClientCapabilities()
   };

   await using var client = await McpClient.CreateAsync(
       clientTransport,
       clientOptions,
       loggerFactory,
       cts.Token);
   ```

**⚠️ Pontos de Atenção:**
- Use `await using` para garantir disposal correto
- Configure timeout adequado para inicialização
- Forneça informações do cliente para logging

### Usando o Cliente

**1. Listar Tools:**
```csharp
var tools = await client.ListToolsAsync(cancellationToken: cts.Token);
foreach (var tool in tools)
{
    Console.WriteLine($"  • {tool.Name}: {tool.Description}");
}
```

**2. Chamar Tools:**
```csharp
var addResult = await client.CallToolAsync(
    "add",
    new Dictionary<string, object?> { ["a"] = 10, ["b"] = 5 },
    cancellationToken: cts.Token);
```

**3. Extrair Conteúdo de Forma Robusta:**
```csharp
static string ExtractTextContent(CallToolResult result)
{
    if (result?.Content == null || !result.Content.Any())
        return "N/A";

    var textContent = result.Content.FirstOrDefault(c => c.Type == "text");
    if (textContent != null)
    {
        var json = JsonSerializer.SerializeToElement(textContent);
        if (json.TryGetProperty("text", out var textProp))
        {
            return textProp.GetString() ?? "N/A";
        }
    }

    return "N/A";
}
```

**⚠️ Pontos de Atenção:**
- Sempre verifique se `Content` não é null
- Use serialização JSON para acessar propriedades de forma segura
- Forneça valores padrão para casos de erro

### Tratamento de Erros

O cliente implementa tratamento robusto de exceções:

```csharp
try
{
    // ... código do cliente ...
}
catch (OperationCanceledException)
{
    Console.WriteLine("\n❌ Operação cancelada pelo usuário.");
}
catch (TimeoutException ex)
{
    Console.WriteLine($"\n❌ Timeout durante conexão: {ex.Message}");
}
catch (McpException ex)
{
    Console.WriteLine($"\n❌ Erro do protocolo MCP: {ex.Message}");
}
catch (Exception ex)
{
    Console.WriteLine($"\n❌ Erro inesperado: {ex.GetType().Name}");
    Console.WriteLine($"   Mensagem: {ex.Message}");
}
```

### Executar o Cliente

```powershell
cd src\ClienteLocal\McpClient
dotnet run
```

**Saída esperada:**
```
=== Cliente MCP - Demonstração ===

✅ Conectado ao servidor MCP com sucesso
   Servidor: ToolsServer v1.0.0
   Protocolo: 2024-11-05

📋 Ferramentas disponíveis:
  • add: Soma dois números
  • subtract: Subtrai dois números
  ...

🧮 Exemplo 1: Ferramentas de Calculadora
  ➕ Adição: 10 + 5 = 15
  ➖ Subtração: 20 - 8 = 12
  ...
```

### Configuração para GitHub Copilot

Para usar o servidor com GitHub Copilot, edite as configurações do VS Code:

```json
{
  "github.copilot.advanced": {
    "mcp": {
      "enabled": true,
      "servers": {
        "csharp-tools": {
          "command": "dotnet",
          "args": ["run", "--project", "D:\\Agentes\\src\\ToolsServer"],
          "transport": "stdio"
        }
      }
    }
  }
}
```

**⚠️ Importante:** Use caminhos absolutos corretos para seu sistema.

### Testando com MCP Inspector

```powershell
cd src\ToolsServer
npx @modelcontextprotocol/inspector dotnet run
```

Isso abrirá uma interface web onde você pode:
- 📋 Ver todas as tools disponíveis
- 🧪 Testar cada tool interativamente
- 📊 Ver logs de comunicação
- 🔍 Debugar problemas

### Referência Completa

Veja a implementação completa em [`src/ClienteLocal/McpClient/Program.cs`](../../d:/Agentes/src/ClienteLocal/McpClient/Program.cs)

### Exercício Prático

1. Modifique o cliente para se conectar ao PromptsServer
2. Adicione retry logic para chamadas de tools
3. Implemente cache de resultados para tools determinísticas

---

## Módulo 5: Conexão Remota (HTTP)

### Objetivo

Criar e conectar a um servidor MCP acessível via HTTP com Server-Sent Events (SSE), permitindo acesso remoto através de uma API web.

### Localizações
- Servidor: [`src/ServidorRemoto/HttpMcpServer/`](src/ServidorRemoto/HttpMcpServer/)
- Cliente: [`src/ClienteRemoto/HttpMcpClient/`](src/ClienteRemoto/HttpMcpClient/)

### O que é HTTP/SSE?

**HTTP com SSE** (Server-Sent Events) ou **Streamable HTTP** permite comunicação bidirecional através de HTTP. É ideal para:

- ✅ Acesso remoto a servidores MCP
- ✅ Serviços web e APIs públicas
- ✅ Integração com aplicações web
- ✅ Deploy em nuvem (Azure, AWS, etc.)
- ✅ Compartilhamento de ferramentas entre equipes
- ✅ Escalabilidade e load balancing

### Quando usar HTTP vs stdio?

| Característica | stdio (Módulo 4) | HTTP/SSE (Módulo 5) |
|----------------|------------------|---------------------|
| **Uso** | Local, mesmo processo | Remoto, através da rede |
| **Cenário** | Desenvolvimento, CLI | Produção, web apps |
| **Segurança** | Isolado | Requer autenticação |
| **Escalabilidade** | 1 cliente | Múltiplos clientes |
| **Latência** | Muito baixa | Depende da rede |

### Implementação do Servidor HTTP

**Pacotes necessários:**
- **ModelContextProtocol.AspNetCore 0.4.0-preview.1** - para suporte HTTP

**Pontos-chave da configuração:**

1. **Logging para stderr:**
   ```csharp
   builder.Logging.ClearProviders();
   builder.Logging.AddConsole(options =>
   {
       options.LogToStandardErrorThreshold = LogLevel.Information;
   });
   ```

2. **Configuração do servidor MCP:**
   ```csharp
   builder.Services
       .AddMcpServer(options =>
       {
           options.ServerInfo = new Implementation
           {
               Name = "HttpMcpServer",
               Version = "1.0.0"
           };
           
           options.ServerInstructions = """
               Este é um servidor MCP HTTP remoto que fornece ferramentas de informações do sistema.
               Ferramentas disponíveis:
               - GetSystemInfo: Retorna informações do sistema
               - GenerateUuid: Gera um UUID único
               - CalculateHash: Calcula hash SHA256
               ...
               """;
       })
       .WithHttpTransport(httpOptions =>
       {
           httpOptions.IdleTimeout = TimeSpan.FromHours(2);
           httpOptions.MaxIdleSessionCount = 10_000;
           // httpOptions.Stateless = true; // Para ambientes com load balancing
       })
       .WithToolsFromAssembly();
   ```

**⚠️ Pontos de Atenção:**
- `ServerInstructions` fornece contexto rico para LLMs
- Configure `IdleTimeout` apropriadamente
- Use `Stateless = true` para ambientes distribuídos

3. **Configuração CORS:**
   ```csharp
   builder.Services.AddCors(options =>
   {
       options.AddDefaultPolicy(policy =>
       {
           policy.AllowAnyOrigin()
                 .AllowAnyMethod()
                 .AllowAnyHeader()
                 .WithExposedHeaders("Mcp-Session-Id");
       });
   });
   ```

4. **Mapeamento de endpoints:**
   ```csharp
   var app = builder.Build();

   app.UseCors();
   app.MapMcp();  // Mapeia MCP na raiz "/"

   // Endpoints auxiliares
   app.MapGet("/health", () => Results.Ok(new { status = "saudavel", ... }));
   app.MapGet("/info", () => Results.Ok(new { name = "HttpMcpServer", ... }));

   app.Run();
   ```

### Implementação das Tools Remotas

**Exemplo de tools otimizadas para uso remoto:**

```csharp
[McpServerToolType]
public static class RemoteTools
{
    [McpServerTool]
    [Description("Obtém informações detalhadas do sistema...")]
    public static object GetSystemInfo()
    {
        return new
        {
            MachineName = Environment.MachineName,
            OSVersion = Environment.OSVersion.ToString(),
            ProcessorCount = Environment.ProcessorCount,
            CurrentTime = DateTime.Now,
            CurrentTimeUtc = DateTime.UtcNow,
            Uptime = TimeSpan.FromMilliseconds(Environment.TickCount64),
            // ... mais informações
        };
    }

    [McpServerTool]
    [Description("Gera um identificador único (UUID/GUID)")]
    public static string GenerateUuid()
    {
        return Guid.NewGuid().ToString();
    }

    [McpServerTool]
    [Description("Calcula hash SHA256 de um texto")]
    public static string CalculateHash(
        [Description("Texto de entrada")] string input)
    {
        if (string.IsNullOrEmpty(input))
            throw new ArgumentException("A entrada não pode ser nula ou vazia");

        using var sha256 = System.Security.Cryptography.SHA256.Create();
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(input);
        byte[] hash = sha256.ComputeHash(bytes);
        return Convert.ToHexString(hash);
    }
}
```

**⚠️ Pontos de Atenção:**
- Valide sempre entradas de usuários
- Retorne objetos estruturados para JSON
- Forneça informações detalhadas nas descrições

### Executar o Servidor

```powershell
cd src\ServidorRemoto\HttpMcpServer
dotnet run
```

**URLs disponíveis:**
- **MCP Endpoint**: `http://localhost:5000/`
- **Health Check**: `http://localhost:5000/health`
- **Server Info**: `http://localhost:5000/info`

### Implementação do Cliente HTTP

**Pontos-chave:**

1. **Configuração via appsettings:**
   ```json
   {
     "McpServer": {
       "Endpoint": "http://localhost:5000"
     }
   }
   ```

2. **Criação do transport HTTP:**
   ```csharp
   var transportOptions = new HttpClientTransportOptions
   {
       Endpoint = new Uri(endpoint),
       TransportMode = HttpTransportMode.AutoDetect,
       Name = "HttpMcpClient"
   };
   
   await using var transport = new HttpClientTransport(transportOptions);
   await using var client = await McpClient.CreateAsync(transport);
   ```

**⚠️ Pontos de Atenção:**
- `AutoDetect` escolhe automaticamente entre StreamableHttp e SSE
- Use `await using` para disposal correto

3. **Tratamento de diferentes tipos de conteúdo:**
   ```csharp
   static string GetContentString(CallToolResult result)
   {
       // Tentar TextContentBlock
       if (result.Content.FirstOrDefault(c => c.Type == "text") is TextContentBlock textBlock)
       {
           return textBlock.Text ?? "N/A";
       }

       // Tentar JSON
       if (result.Content.FirstOrDefault(c => c.Type == "json") is var jsonBlock && jsonBlock != null)
       {
           var jsonProp = jsonBlock.GetType().GetProperty("Json");
           if (jsonProp?.GetValue(jsonBlock) is JsonElement jsonElement)
           {
               return JsonSerializer.Serialize(jsonElement, new JsonSerializerOptions { WriteIndented = true });
           }
       }

       return "N/A";
   }
   ```

**⚠️ Pontos de Atenção:**
- Ferramentas podem retornar text ou JSON
- Use `JsonElement` para conteúdo JSON
- Sempre forneça fallback

### Executar o Cliente

**Terminal 1 (Servidor):**
```powershell
cd src\ServidorRemoto\HttpMcpServer
dotnet run
```

**Terminal 2 (Cliente):**
```powershell
cd src\ClienteRemoto\HttpMcpClient
dotnet run
```

### Testando com cURL

```powershell
# Health check
curl http://localhost:5000/health

# Server info
curl http://localhost:5000/info
```

### Configurações de Produção

**1. HTTPS:**
```json
// appsettings.json
{
  "Kestrel": {
    "Endpoints": {
      "Https": {
        "Url": "https://localhost:5001"
      }
    }
  }
}
```

**2. Rate Limiting e Timeouts:**
```json
{
  "Kestrel": {
    "Limits": {
      "MaxConcurrentConnections": 100,
      "MaxConcurrentUpgradedConnections": 100,
      "MaxRequestBodySize": 10485760,
      "KeepAliveTimeout": "00:02:00",
      "RequestHeadersTimeout": "00:00:30"
    }
  }
}
```

### Referências Completas

- Servidor: [`src/ServidorRemoto/HttpMcpServer/Program.cs`](../../d:/Agentes/src/ServidorRemoto/HttpMcpServer/Program.cs)
- Cliente: [`src/ClienteRemoto/HttpMcpClient/Program.cs`](../../d:/Agentes/src/ClienteRemoto/HttpMcpClient/Program.cs)
- Configurações: [`appsettings.json`](../../d:/Agentes/src/ServidorRemoto/HttpMcpServer/appsettings.json)

### Exercício Prático

1. Adicione autenticação por API Key ao servidor
2. Implemente retry logic no cliente com backoff exponencial
3. Configure o servidor para HTTPS com certificado
4. Adicione métricas de uso (número de chamadas, latência)

---

## Módulo 6: Integração com Clientes de IA

### GitHub Copilot (VS Code)

#### Configurar Settings

Abra VS Code Settings (JSON) pressionando `Ctrl+Shift+P` e digitando "Preferences: Open User Settings (JSON)":

```json
{
  "github.copilot.advanced": {
    "mcp": {
      "enabled": true,
      "servers": {
        "csharp-tools": {
          "command": "dotnet",
          "args": ["run", "--project", "D:\\Agentes\\src\\ToolsServer"],
          "transport": "stdio",
          "env": {
            "DOTNET_ENVIRONMENT": "Production"
          }
        },
        "csharp-prompts": {
          "command": "dotnet",
          "args": ["run", "--project", "D:\\Agentes\\src\\PromptsServer\\PromptsServer"],
          "transport": "stdio"
        }
      }
    }
  }
}
```

**⚠️ Importante:** 
- Use caminhos absolutos corretos para seu sistema
- Configure variáveis de ambiente se necessário
- Teste cada servidor individualmente antes

#### Usar no Chat

1. Abra o GitHub Copilot Chat (`Ctrl+Shift+I`)
2. Digite comandos como:
   - `@mcp/csharp-tools add 15 e 25`
   - `@mcp/csharp-tools countWords "Olá mundo MCP"`
   - `@mcp/csharp-prompts get code_review para revisar meu código`

3. O Copilot usará suas tools automaticamente!

### GitHub Copilot CLI

#### Configuração

Crie ou edite `~/.config/github-copilot/config.yml`:

```yaml
mcp:
  servers:
    csharp-tools:
      command: dotnet
      args: ["run", "--project", "D:\\Agentes\\src\\ToolsServer"]
      transport: stdio
```

#### Usar na Linha de Comando

```powershell
# Usar ferramentas
gh copilot suggest "calculate 15 plus 25"

# O Copilot detectará automaticamente suas tools disponíveis
```

### Claude Desktop

#### Configuração

Edite o arquivo de configuração do Claude Desktop:

**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`
**macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "csharp-tools": {
      "command": "dotnet",
      "args": [
        "run",
        "--project",
        "D:\\Agentes\\src\\ToolsServer"
      ],
      "env": {
        "DOTNET_ENVIRONMENT": "Production"
      }
    },
    "csharp-prompts": {
      "command": "dotnet",
      "args": [
        "run",
        "--project",
        "D:\\Agentes\\src\\PromptsServer\\PromptsServer"
      ]
    }
  }
}
```

#### Usar no Claude

1. Reinicie o Claude Desktop
2. Os servidores MCP aparecerão como ferramentas disponíveis
3. Claude usará as tools automaticamente quando relevante

### MCP Inspector

#### O que é?

Ferramenta oficial para debugar servidores MCP. Permite:

- 🔍 Inspecionar tools e prompts
- 🧪 Testar ferramentas interativamente
- 📊 Ver comunicação em tempo real
- 🐛 Debugar problemas de protocolo
- 📝 Ver logs detalhados

#### Instalação

```powershell
npm install -g @modelcontextprotocol/inspector
```

#### Usar com Servidor stdio

```powershell
# Navegar até o diretório do servidor
cd src\ToolsServer

# Iniciar com Inspector
npx @modelcontextprotocol/inspector dotnet run
```

Isso abrirá uma interface web em `http://localhost:5173` onde você pode:

1. **Ver todas as tools:**
   - Nomes, descrições e parâmetros
   - Tipos de retorno

2. **Testar tools:**
   - Fornecer argumentos
   - Ver resultados em tempo real

3. **Ver logs de comunicação:**
   - Mensagens JSON-RPC
   - Erros e avisos

#### Usar com Servidor HTTP

```powershell
# Iniciar o servidor HTTP normalmente
cd src\ServidorRemoto\HttpMcpServer
dotnet run

# Em outro terminal, conectar o Inspector
npx @modelcontextprotocol/inspector http://localhost:5000
```

#### Dicas de Debug

**Problemas comuns identificados pelo Inspector:**

1. **Tool não aparece:**
   - Verifique atributos `[McpServerTool]` e `[McpServerToolType]`
   - Confirme que `.WithToolsFromAssembly()` está configurado

2. **Erro ao chamar tool:**
   - Veja a mensagem de erro no Inspector
   - Verifique tipos de parâmetros
   - Confirme validações de entrada

3. **Timeout de conexão:**
   - Verifique se o servidor está rodando
   - Confirme que não há conflitos de porta
   - Veja logs em stderr

### Testando Integração Completa

**Fluxo de teste recomendado:**

1. **Testar servidor isolado com Inspector:**
   ```powershell
   cd src\ToolsServer
   npx @modelcontextprotocol/inspector dotnet run
   ```

2. **Testar com cliente stdio:**
   ```powershell
   cd src\ClienteLocal\McpClient
   dotnet run
   ```

3. **Configurar no GitHub Copilot:**
   - Adicionar nas configurações do VS Code
   - Testar com comandos simples no chat

4. **Monitorar comportamento:**
   - Observar quais tools o LLM escolhe usar
   - Ver como interpreta descrições
   - Ajustar descrições se necessário

### Arquivo de Configuração Exemplo

Veja exemplos completos em:
- [`configs/copilot-config.json`](configs/copilot-config.json)
- [`configs/copilot-cli-config.json`](configs/copilot-cli-config.json)
- [`src/PromptsServer/PromptsServer/claude_desktop_config.json`](../../d:/Agentes/src/PromptsServer/PromptsServer/claude_desktop_config.json)

### Exercício Prático

1. Configure todos os três servidores (Tools, Prompts, HTTP) no GitHub Copilot
2. Teste interações complexas que usam múltiplas tools
3. Use o MCP Inspector para debugar uma tool com erro
4. Configure e teste com Claude Desktop

---

## Troubleshooting

### Problema: Servidor não responde

**Sintomas:**
- Cliente trava ao conectar
- Timeout de conexão
- Sem output no console

**Soluções:**

1. **Verificar se o servidor está rodando:**
   ```powershell
   # Listar processos dotnet
   Get-Process dotnet
   ```

2. **Verificar logs em stderr:**
   ```powershell
   # Redirecionar stderr para arquivo
   dotnet run 2> error.log
   ```

3. **Testar com MCP Inspector primeiro:**
   ```powershell
   cd src\ToolsServer
   npx @modelcontextprotocol/inspector dotnet run
   ```

4. **Verificar caminhos de projeto:**
   - Use caminhos absolutos em configs
   - Confirme que `.csproj` existe no caminho

### Problema: Tools não aparecem no cliente

**Sintomas:**
- `ListToolsAsync()` retorna lista vazia
- LLM não vê as ferramentas

**Soluções:**

1. **Verificar atributos:**
   ```csharp
   // ✅ Correto
   [McpServerToolType]
   public static class MyTools
   {
       [McpServerTool(Name = "myTool")]
       [Description("...")]
       public static string MyTool() { ... }
   }

   // ❌ Incorreto - faltam atributos
   public static class MyTools
   {
       public static string MyTool() { ... }
   }
   ```

2. **Confirmar registro no servidor:**
   ```csharp
   builder.Services
       .AddMcpServer()
       .WithStdioServerTransport()
       .WithToolsFromAssembly();  // ← Importante!
   ```

3. **Recompilar projeto:**
   ```powershell
   dotnet clean
   dotnet build
   ```

4. **Verificar com Inspector:**
   - Deve mostrar todas as tools
   - Se aparecer no Inspector mas não no cliente, o problema é na comunicação

### Problema: Erro ao chamar tool

**Sintomas:**
- Exceção ao chamar `CallToolAsync`
- Erro "Tool not found"
- Timeout na chamada

**Soluções:**

1. **Verificar nome da tool:**
   ```csharp
   // Nome definido no servidor
   [McpServerTool(Name = "add")]

   // Deve corresponder ao usado no cliente
   await client.CallToolAsync("add", ...);
   ```

2. **Verificar tipos de argumentos:**
   ```csharp
   // Servidor espera double
   public static double Add(double a, double b)

   // Cliente deve enviar double, não string
   await client.CallToolAsync("add", new Dictionary<string, object?>
   {
       ["a"] = 10.0,    // ✅ double
       ["b"] = 5.0      // ✅ double
   });
   ```

3. **Ver detalhes do erro:**
   ```csharp
   try
   {
       await client.CallToolAsync(...);
   }
   catch (McpException ex)
   {
       Console.WriteLine($"Erro MCP: {ex.Message}");
       Console.WriteLine($"Detalhes: {ex.InnerException?.Message}");
   }
   ```

4. **Testar com Inspector:**
   - Fornece interface para testar argumentos
   - Mostra erro exato do servidor

### Problema: Erro de conexão HTTP

**Sintomas:**
- Cliente HTTP não conecta
- "Connection refused"
- Timeout na requisição

**Soluções:**

1. **Verificar se servidor está rodando:**
   ```powershell
   # Testar health check
   curl http://localhost:5000/health
   ```

2. **Verificar porta disponível:**
   ```powershell
   # Ver o que está usando a porta
   netstat -ano | findstr :5000
   ```

3. **Confirmar URL correta:**
   ```csharp
   // appsettings.json ou código
   "Endpoint": "http://localhost:5000"  // Sem /mcp no final!
   ```

4. **Verificar firewall:**
   - Windows pode bloquear a porta
   - Adicionar exceção se necessário

5. **Testar com curl primeiro:**
   ```powershell
   # Health check deve responder
   curl http://localhost:5000/health

   # Info do servidor
   curl http://localhost:5000/info
   ```

### Problema: Conteúdo null ou "N/A"

**Sintomas:**
- Tool executa mas retorna "N/A"
- Content é null no resultado

**Soluções:**

1. **Verificar tipo de retorno:**
   ```csharp
   // ✅ Tipos suportados
   public static string MyTool()  // text
   public static int MyTool()     // number
   public static object MyTool()  // json

   // ❌ Tipos não suportados diretamente
   public static MyCustomClass MyTool()
   ```

2. **Usar extraction robusta:**
   ```csharp
   static string ExtractTextContent(CallToolResult result)
   {
       if (result?.Content == null || !result.Content.Any())
           return "N/A";

       // Tentar como texto
       var textContent = result.Content.FirstOrDefault(c => c.Type == "text");
       if (textContent != null)
       {
           var json = JsonSerializer.SerializeToElement(textContent);
           if (json.TryGetProperty("text", out var textProp))
           {
               return textProp.GetString() ?? "N/A";
           }
       }

       return "N/A";
   }
   ```

3. **Verificar logs do servidor:**
   - Ver se tool está sendo executada
   - Confirmar que não há exceções

### Problema: MCP Inspector não abre

**Sintomas:**
- Comando não inicia interface web
- Erro "inspector not found"

**Soluções:**

1. **Reinstalar Inspector:**
   ```powershell
   npm uninstall -g @modelcontextprotocol/inspector
   npm install -g @modelcontextprotocol/inspector
   ```

2. **Verificar instalação:**
   ```powershell
   npx @modelcontextprotocol/inspector --version
   ```

3. **Limpar cache do npm:**
   ```powershell
   npm cache clean --force
   ```

4. **Usar npx diretamente:**
   ```powershell
   # Sem instalar globalmente
   npx @modelcontextprotocol/inspector dotnet run
   ```

### Problema: GitHub Copilot não vê o servidor

**Sintomas:**
- Servidor configurado mas Copilot não usa tools
- Sem erro, mas tools não aparecem

**Soluções:**

1. **Verificar sintaxe do JSON:**
   ```json
   {
     "github.copilot.advanced": {
       "mcp": {
         "enabled": true,  // ← Não esquecer
         "servers": { ... }
       }
     }
   }
   ```

2. **Usar caminhos absolutos:**
   ```json
   {
     "args": ["run", "--project", "D:\\Agentes\\src\\ToolsServer"]
                                 // ↑ Caminho completo
   }
   ```

3. **Reiniciar VS Code:**
   - Fechar completamente
   - Reabrir
   - Aguardar carregamento completo

4. **Verificar logs do VS Code:**
   - Ver console de desenvolvedor (`Help > Toggle Developer Tools`)
   - Procurar por erros relacionados a MCP

5. **Testar servidor isoladamente:**
   - Confirmar que funciona com Inspector
   - Confirmar que funciona com cliente C#
   - Só depois integrar com Copilot

### Logs de Debug

**Habilitar logs detalhados no servidor:**

```csharp
builder.Logging.AddConsole(options =>
{
    options.LogToStandardErrorThreshold = LogLevel.Trace;  // ← Debug máximo
});
```

**Habilitar logs detalhados no cliente:**

```csharp
using var loggerFactory = LoggerFactory.Create(builder =>
{
    builder
        .AddConsole()
        .SetMinimumLevel(LogLevel.Debug);  // ← Debug máximo
});
```

**Capturar logs em arquivo:**

```powershell
# Windows PowerShell
dotnet run 2> logs.txt

# Ou redirecionar ambos stdout e stderr
dotnet run > output.txt 2>&1
```

### Checklist Geral de Debug

Quando algo não funciona, siga esta ordem:

- [ ] 1. Servidor compila sem erros?
- [ ] 2. Servidor inicia sem exceções?
- [ ] 3. Tools aparecem no MCP Inspector?
- [ ] 4. Tools funcionam no Inspector?
- [ ] 5. Cliente consegue listar tools?
- [ ] 6. Cliente consegue chamar tools?
- [ ] 7. Configuração de cliente IA está correta?
- [ ] 8. Cliente IA está reiniciado?
- [ ] 9. Logs mostram algo anormal?
- [ ] 10. Versões de pacotes estão corretas?

---

## Recursos Adicionais

### Documentação Oficial

- 📚 [MCP Specification](https://spec.modelcontextprotocol.io/) - Especificação completa do protocolo
- 📖 [C# SDK Documentation](https://modelcontextprotocol.github.io/csharp-sdk/) - API Reference completa
- 🔧 [GitHub Repository](https://github.com/modelcontextprotocol/csharp-sdk) - Código-fonte e issues
- 🌐 [MCP Website](https://modelcontextprotocol.io/) - Site oficial com overview

### Pacotes NuGet

**Versões usadas neste workshop:**

- **ModelContextProtocol 0.4.0-preview.1**
  - Pacote principal com servidor e cliente stdio
  - [NuGet Package](https://www.nuget.org/packages/ModelContextProtocol)

- **ModelContextProtocol.AspNetCore 0.4.0-preview.1**
  - Extensões para servidores HTTP com ASP.NET Core
  - [NuGet Package](https://www.nuget.org/packages/ModelContextProtocol.AspNetCore)

- **ModelContextProtocol.Core 0.4.0-preview.1**
  - APIs de baixo nível do cliente e servidor
  - [NuGet Package](https://www.nuget.org/packages/ModelContextProtocol.Core)

- **Microsoft.Extensions.Hosting 9.0.9**
  - Hospedagem e dependency injection
  - [NuGet Package](https://www.nuget.org/packages/Microsoft.Extensions.Hosting)

- **Microsoft.Extensions.AI.Abstractions**
  - Abstrações para integração com LLMs (ChatMessage, ChatRole)
  - [NuGet Package](https://www.nuget.org/packages/Microsoft.Extensions.AI.Abstractions)

### Frameworks e Tecnologias

- .NET: 9.0
- C# Language: 13.0 (latest)
- MCP Protocol: Specification 2024-11-05

### Exemplos e Tutoriais

- [MCP Samples (C#)](https://github.com/modelcontextprotocol/csharp-sdk/tree/main/samples) - Exemplos oficiais do SDK
- [Awesome MCP Servers](https://github.com/punkpeye/awesome-mcp-servers) - Lista curada de servidores MCP
- [MCP Community Servers](https://github.com/modelcontextprotocol/servers) - Servidores em várias linguagens

### Referências Complementares

Para uma lista completa de recursos, tutoriais avançados e casos de uso, consulte:

📖 **[docs/referencias.md](docs/referencias.md)**

Este arquivo contém:
- Tutoriais aprofundados
- Padrões e best practices
- Casos de uso reais
- Exemplos de projetos avançados
- Roadmap do MCP
- Lista de ferramentas úteis

### Comunidade e Suporte

| Canal | Descrição | Link |
|-------|-----------|------|
| **Discord MCP** | Comunidade oficial | https://discord.gg/modelcontextprotocol |
| **GitHub Discussions** | Discussões técnicas | https://github.com/modelcontextprotocol/csharp-sdk/discussions |
| **Stack Overflow** | Q&A técnico | Tag: `model-context-protocol` |

### Ferramentas Úteis

| Ferramenta | Propósito | Link |
|-----------|-----------|------|
| **MCP Inspector** | Debug de servidores | `npm install -g @modelcontextprotocol/inspector` |
| **Postman** | Testar endpoints HTTP | https://www.postman.com/ |
| **Insomnia** | Cliente REST | https://insomnia.rest/ |
| **REST Client** | Extensão VS Code | Marketplace |

### Leitura Complementar

1. **Understanding LLM Agents**
   - https://www.anthropic.com/index/claude-agent
   - Como LLMs usam ferramentas efetivamente

2. **Tool Use Best Practices**
   - https://docs.anthropic.com/claude/docs/tool-use
   - Padrões para criar tools úteis

3. **Prompt Engineering Guide**
   - https://www.promptingguide.ai/
   - Como escrever prompts efetivos

4. **Async/Await in C#**
   - https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/
   - Programação assíncrona

### Projetos de Exemplo Avançados

**Ideias para próximos projetos:**

1. **File System Server**
   - Tools para ler/escrever arquivos
   - Buscar arquivos por padrão
   - Listar diretórios

2. **Database Query Server**
   - Executar queries SQL seguras
   - Ver schemas de tabelas
   - Exports de dados

3. **API Gateway Server**
   - Integrar múltiplas APIs externas
   - Weather, stocks, news, etc.
   - Cache e rate limiting

4. **Development Tools Server**
   - Formatar código
   - Lint e análise estática
   - Gerar testes unitários

### Próximos Passos

Depois de completar este workshop, você pode:

1. ✅ **Explorar os exemplos oficiais**
   - Ver casos de uso mais complexos
   - Aprender padrões avançados

2. ✅ **Criar seu próprio servidor MCP**
   - Integrar com suas ferramentas
   - Expor APIs internas como tools

3. ✅ **Contribuir com a comunidade**
   - Compartilhar seus servidores
   - Abrir issues e PRs
   - Ajudar outros desenvolvedores

4. ✅ **Deploy em produção**
   - Configurar HTTPS e autenticação
   - Deploy na nuvem (Azure, AWS)
   - Monitorar uso e performance

5. ✅ **Integrar com projetos existentes**
   - Adicionar MCP a aplicações .NET
   - Expor funcionalidades via tools
   - Criar interfaces conversacionais

### Como Contribuir

#### Para este Workshop

- 🐛 **Encontrou um bug?** Abra uma issue
- 💡 **Tem uma sugestão?** Crie uma discussion
- 🔧 **Quer contribuir?** Envie um pull request
- 📝 **Melhorou algo?** Compartilhe sua experiência

#### Para o SDK C#

1. Fork do repositório oficial
2. Crie branch feature: `git checkout -b feature/minha-feature`
3. Commit mudanças: `git commit -am 'Adiciona feature X'`
4. Push branch: `git push origin feature/minha-feature`
5. Abra Pull Request

### Atualizações Futuras

Este workshop será atualizado conforme:
- Novas versões do SDK C#
- Novos recursos do protocolo MCP
- Feedback da comunidade
- Melhores práticas emergentes

**Última atualização:** Janeiro 2025

**Versão do workshop:** 2.0.0 (atualizada para SDK 0.4.0-preview.1)

---

## Feedback e Contribuições

Este é um projeto educacional em constante evolução. Seu feedback é essencial!

**Como ajudar:**

- ⭐ Dê uma estrela no repositório se achou útil
- 🐛 Reporte bugs ou problemas
- 💡 Sugira melhorias
- 📝 Compartilhe sua experiência
- 🔧 Contribua com código
- 📖 Melhore a documentação

**Contato:**

- GitHub Issues: Para bugs e features
- GitHub Discussions: Para perguntas e ideias
- Discord MCP: Para discussões em tempo real

---

## Licença

Este workshop é disponibilizado sob licença MIT. Veja o arquivo LICENSE para mais detalhes.

Você é livre para:
- ✅ Usar comercialmente
- ✅ Modificar
- ✅ Distribuir
- ✅ Uso privado

Desde que:
- 📋 Inclua a licença e copyright
- 📋 Forneça atribuição

---

## Agradecimentos

Este workshop não seria possível sem:

- **Anthropic** - Pela criação do Model Context Protocol
- **Microsoft** - Pelo desenvolvimento do SDK C#
- **Comunidade .NET** - Pelas ferramentas e frameworks
- **Contribuidores** - Por feedback e melhorias
- **Você** - Por dedicar tempo para aprender!

---

## Conclusão

**🎉 Parabéns por completar o workshop!**

Você agora sabe como:

- ✅ Criar servidores MCP em C#
- ✅ Implementar tools e prompts
- ✅ Conectar clientes localmente e remotamente
- ✅ Integrar com GitHub Copilot e outras ferramentas
- ✅ Debugar problemas com MCP Inspector
- ✅ Seguir melhores práticas de segurança
- ✅ Deploy servidores
