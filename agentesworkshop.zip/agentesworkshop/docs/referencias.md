# Referências Complementares - Workshop MCP em C#

## 📚 Documentação Oficial

### Model Context Protocol (MCP)

| Recurso | Descrição | Link |
|---------|-----------|------|
| **Especificação MCP** | Documentação completa do protocolo | https://spec.modelcontextprotocol.io/ |
| **MCP Website** | Site oficial com overview e guias | https://modelcontextprotocol.io/ |
| **MCP GitHub** | Repositório principal da organização | https://github.com/modelcontextprotocol |

### SDK C# para MCP

| Recurso | Descrição | Link |
|---------|-----------|------|
| **C# SDK Repository** | Código-fonte e issues | https://github.com/modelcontextprotocol/csharp-sdk |
| **API Documentation** | Documentação completa da API | https://modelcontextprotocol.github.io/csharp-sdk/api/ModelContextProtocol.html |
| **NuGet - ModelContextProtocol** | Pacote principal | https://www.nuget.org/packages/ModelContextProtocol |
| **NuGet - AspNetCore** | Pacote para HTTP/SSE | https://www.nuget.org/packages/ModelContextProtocol.AspNetCore |
| **NuGet - Core** | Pacote mínimo | https://www.nuget.org/packages/ModelContextProtocol.Core |

---

## 🎓 Tutoriais e Guias

### Conceitos de LLM e Agentes

1. **Understanding AI Agents**
   - https://www.anthropic.com/index/claude-agent
   - Introdução aos conceitos de agentes de IA

2. **Tool Use with Claude**
   - https://docs.anthropic.com/claude/docs/tool-use
   - Como LLMs usam ferramentas efetivamente

3. **Prompt Engineering Guide**
   - https://www.promptingguide.ai/
   - Guia completo sobre engenharia de prompts

### C# e .NET

1. **Async/Await Best Practices**
   - https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/
   - Programação assíncrona em C#

2. **Dependency Injection in .NET**
   - https://learn.microsoft.com/en-us/dotnet/core/extensions/dependency-injection
   - Injeção de dependências no .NET

3. **Generic Host in .NET**
   - https://learn.microsoft.com/en-us/dotnet/core/extensions/generic-host
   - Usando Generic Host para aplicações

---

## 🛠️ Ferramentas e Extensões

### Desenvolvimento

| Ferramenta | Propósito | Instalação |
|-----------|-----------|------------|
| **Visual Studio Code** | IDE principal | https://code.visualstudio.com/ |
| **C# Dev Kit** | Extensão VS Code | Marketplace VS Code |
| **.NET SDK** | Runtime e ferramentas | https://dotnet.microsoft.com/download |
| **REST Client** | Testar APIs no VS Code | Marketplace VS Code |

### MCP Tools

| Ferramenta | Propósito | Instalação |
|-----------|-----------|------------|
| **MCP Inspector** | Debug de servidores MCP | `npm install -g @modelcontextprotocol/inspector` |
| **MCP CLI** | Ferramenta de linha de comando | Em desenvolvimento |

### Clientes de IA

| Cliente | Descrição | Como Usar |
|---------|-----------|-----------|
| **GitHub Copilot** | Assistente de código AI | Extensão VS Code + Subscription |
| **Copilot CLI** | CLI do GitHub Copilot | `npm install -g @githubnext/github-copilot-cli` |
| **Claude Desktop** | App desktop do Claude | https://claude.ai/download |

### Testing & Debug

| Ferramenta | Propósito | Link |
|-----------|-----------|------|
| **Postman** | Cliente HTTP | https://www.postman.com/ |
| **Insomnia** | Cliente REST | https://insomnia.rest/ |
| **ngrok** | Tunnel para localhost | https://ngrok.com/ |
| **Fiddler** | Proxy de debug HTTP | https://www.telerik.com/fiddler |

---

## 📖 Exemplos e Projetos

### Repositórios Oficiais

1. **MCP Samples (C#)**
   ```
   https://github.com/modelcontextprotocol/csharp-sdk/tree/main/samples
   ```
   - Exemplos oficiais do SDK
   - Casos de uso comuns
   - Padrões recomendados

2. **MCP Servers (Community)**
   ```
   https://github.com/modelcontextprotocol/servers
   ```
   - Servidores MCP em várias linguagens
   - Referência de implementações

3. **Awesome MCP Servers**
   ```
   https://github.com/punkpeye/awesome-mcp-servers
   ```
   - Lista curada de servidores MCP
   - Inspiração para projetos

### Projetos de Exemplo Avançados

#### 1. File System MCP Server
**Descrição**: Servidor que expõe operações de sistema de arquivos

**Tools:**
- `ReadFile(path)` - Ler conteúdo de arquivo
- `WriteFile(path, content)` - Escrever em arquivo
- `ListDirectory(path)` - Listar diretório
- `SearchFiles(pattern)` - Buscar arquivos

**Código exemplo:**
```csharp
[McpServerTool, Description("Lê conteúdo de um arquivo")]
public static async Task<string> ReadFile(
    [Description("Caminho do arquivo")] string path)
{
    return await File.ReadAllTextAsync(path);
}
```

#### 2. Database Query Server
**Descrição**: Servidor MCP para queries SQL seguras

**Tools:**
- `ExecuteQuery(sql)` - Executar SELECT
- `GetSchema(table)` - Ver estrutura da tabela
- `GetTableList()` - Listar tabelas

**Segurança:**
- Apenas queries SELECT
- Parametrização obrigatória
- Rate limiting

#### 3. Web API Gateway
**Descrição**: MCP que integra múltiplas APIs externas

**Tools:**
- `GetWeather(city)` - Dados meteorológicos
- `GetStockPrice(symbol)` - Cotação de ações
- `TranslateText(text, target)` - Tradução

**Padrões:**
- Cache de respostas
- Retry logic
- Circuit breaker

#### 4. Development Tools Server
**Descrição**: Ferramentas de desenvolvimento via MCP

**Tools:**
- `FormatCode(code, language)` - Formatar código
- `LintCode(code, language)` - Análise estática
- `GenerateTests(code)` - Gerar testes unitários
- `ExplainError(error)` - Explicar mensagens de erro

---

## 🎯 Padrões e Best Practices

### Design de Tools

#### ✅ Boas Práticas

1. **Nomes Descritivos**
   ```csharp
   // ✅ Bom
   [McpServerTool, Description("Calcula o fatorial de um número")]
   public static long CalculateFactorial(int n)
   
   // ❌ Evitar
   [McpServerTool]
   public static long Fact(int n)
   ```

2. **Descrições Claras**
   ```csharp
   // ✅ Bom - descrição clara do parâmetro
   public static string FormatDate(
       [Description("Data no formato ISO 8601")] string isoDate)
   
   // ❌ Evitar - sem descrição
   public static string FormatDate(string date)
   ```

3. **Validação de Entrada**
   ```csharp
   [McpServerTool]
   public static double Divide(double a, double b)
   {
       if (b == 0)
           throw new ArgumentException("Divisor não pode ser zero");
       return a / b;
   }
   ```

4. **Tratamento de Erros**
   ```csharp
   [McpServerTool]
   public static async Task<string> FetchUrl(string url)
   {
       try
       {
           // ... código ...
       }
       catch (HttpRequestException ex)
       {
           throw new McpException($"Falha ao buscar URL: {ex.Message}");
       }
   }
   ```

### Design de Prompts

#### ✅ Boas Práticas

1. **Templates Estruturados**
   ```csharp
   [McpServerPrompt, Description("Analisa código para problemas")]
   public static ChatMessage CodeAnalysis(string code, string[] focusAreas)
   {
       var areas = string.Join(", ", focusAreas);
       return new ChatMessage(ChatRole.User,
           $@"Analise este código focando em: {areas}
           
           Código:
           ```
           {code}
           ```
           
           Forneça:
           1. Problemas encontrados
           2. Sugestões de correção
           3. Melhorias de performance");
   }
   ```

2. **Parâmetros Opcionais**
   ```csharp
   [McpServerPrompt]
   public static ChatMessage Summarize(
       string content,
       int maxWords = 100,
       string tone = "neutral")
   ```

### Segurança

#### 🔒 Checklist de Segurança

- [ ] **Validação de Input**: Sempre validar entradas
- [ ] **Rate Limiting**: Limitar chamadas por minuto
- [ ] **Autenticação**: Para servidores HTTP públicos
- [ ] **Sanitização**: Limpar dados antes de usar
- [ ] **Logging**: Registrar ações importantes
- [ ] **Error Handling**: Não vazar informações sensíveis

#### Exemplo de Rate Limiting

```csharp
private static readonly Dictionary<string, Queue<DateTime>> _rateLimits = new();
private const int MaxCallsPerMinute = 60;

[McpServerTool]
public static string RateLimitedTool(string clientId, string input)
{
    if (!CheckRateLimit(clientId))
        throw new McpException("Rate limit excedido. Tente novamente mais tarde.");
    
    // ... lógica da tool ...
}

private static bool CheckRateLimit(string clientId)
{
    if (!_rateLimits.ContainsKey(clientId))
        _rateLimits[clientId] = new Queue<DateTime>();
    
    var now = DateTime.UtcNow;
    var calls = _rateLimits[clientId];
    
    // Remover chamadas antigas (mais de 1 minuto)
    while (calls.Count > 0 && (now - calls.Peek()).TotalMinutes > 1)
        calls.Dequeue();
    
    if (calls.Count >= MaxCallsPerMinute)
        return false;
    
    calls.Enqueue(now);
    return true;
}
```

---

## 🤝 Comunidade e Suporte

### Canais Oficiais

| Canal | Descrição | Link |
|-------|-----------|------|
| **Discord MCP** | Comunidade oficial | https://discord.gg/modelcontextprotocol |
| **GitHub Discussions** | Discussões técnicas | https://github.com/modelcontextprotocol/csharp-sdk/discussions |
| **Stack Overflow** | Q&A técnico | Tag: `model-context-protocol` |

### Como Obter Ajuda

1. **Verifique a Documentação**: Sempre consulte docs primeiro
2. **Busque Issues Existentes**: Problema pode já estar reportado
3. **Crie Issue Detalhada**: Inclua código, erro e ambiente
4. **Participe da Comunidade**: Discord e Discussions

### Como Contribuir

#### Para o SDK C#

1. Fork do repositório
2. Crie branch feature: `git checkout -b feature/minha-feature`
3. Commit mudanças: `git commit -am 'Adiciona feature X'`
4. Push branch: `git push origin feature/minha-feature`
5. Abra Pull Request

#### Para este Workshop

- Reporte erros via Issues
- Sugira melhorias via Discussions
- Contribua com exemplos via Pull Requests
- Compartilhe seus projetos MCP

---

## 📊 Casos de Uso Reais

### 1. Assistente de Desenvolvimento

**Problema**: Desenvolvedores perdem tempo com tarefas repetitivas

**Solução MCP**:
- Tools para gerar boilerplate code
- Prompts para revisão de código
- Integração com ferramentas de build

**Benefício**: 30% de redução em tarefas repetitivas

### 2. Análise de Dados

**Problema**: Analistas precisam consultar múltiplas fontes

**Solução MCP**:
- Tools para queries em diferentes DBs
- Integração com APIs de dados
- Geração automática de relatórios

**Benefício**: Consolidação de 5+ ferramentas em 1

### 3. Customer Support

**Problema**: Agentes precisam acessar múltiplos sistemas

**Solução MCP**:
- Tools para buscar histórico de cliente
- Integração com CRM
- Geração de respostas contextualizadas

**Benefício**: Tempo de resolução 40% menor

### 4. DevOps Automation

**Problema**: Operações manuais propensas a erro

**Solução MCP**:
- Tools para deployment
- Monitoramento de sistemas
- Troubleshooting automatizado

**Benefício**: 95% redução em erros humanos

---

## 🎯 Roadmap do MCP

### Recursos Atuais (Q4 2024 - Q1 2025)

- ✅ Protocolo Core estável
- ✅ SDK C# oficial
- ✅ Suporte stdio e HTTP
- ✅ Tools e Prompts
- ✅ MCP Inspector

### Próximos Recursos (Q2-Q3 2025)

- 🔄 Streaming de respostas
- 🔄 Recursos (Resources) completos
- 🔄 Autenticação OAuth
- 🔄 Rate limiting integrado
- 🔄 Métricas e observabilidade

### Futuro (Q4 2025+)

- 📋 Suporte WebSocket
- 📋 Marketplace de servidores
- 📋 SDKs para mais linguagens
- 📋 Ferramentas de testes automatizados

---

## 📚 Leitura Adicional

### Artigos Técnicos

1. **"Building Reliable LLM Agents"**
   - Padrões de design para agentes
   - Tratamento de erros
   - Fallback strategies

2. **"MCP: A Protocol for AI Context"**
   - Arquitetura do protocolo
   - Decisões de design
   - Comparação com outras soluções

3. **"Securing AI Tool Integrations"**
   - Vulnerabilidades comuns
   - Mitigações
   - Best practices

### Livros Recomendados

1. **"Designing Data-Intensive Applications"** - Martin Kleppmann
   - Fundamentos de sistemas distribuídos
   - Relevante para MCP remoto

2. **"C# in Depth"** - Jon Skeet
   - Domínio profundo de C#
   - Patterns avançados

3. **"Building Microservices"** - Sam Newman
   - Arquitetura de serviços
   - Aplicável a design de MCP servers

### Vídeos e Webinars

1. **Anthropic Claude Developer Series**
   - https://www.youtube.com/@AnthropicAI
   - Webinars sobre Claude e MCP

2. **dotNET YouTube Channel**
   - https://www.youtube.com/@dotnet
   - Tutoriais C# e .NET

---

## 🔗 Links Rápidos

### Essenciais
- 📖 [MCP Spec](https://spec.modelcontextprotocol.io/)
- 💻 [C# SDK](https://github.com/modelcontextprotocol/csharp-sdk)
- 🔧 [MCP Inspector](https://github.com/modelcontextprotocol/inspector)
- 💬 [Discord](https://discord.gg/modelcontextprotocol)

### Ferramentas
- ⚙️ [VS Code](https://code.visualstudio.com/)
- 🎯 [.NET SDK](https://dotnet.microsoft.com/download)
- 📦 [NuGet](https://www.nuget.org/)

### Aprendizado
- 🎓 [Prompt Engineering](https://www.promptingguide.ai/)
- 📚 [C# Docs](https://learn.microsoft.com/en-us/dotnet/csharp/)
- 🧠 [LLM Patterns](https://www.anthropic.com/research)

---

## 📝 Notas Finais

Este documento é atualizado regularmente. Para a versão mais recente, visite o repositório do workshop.

**Última atualização**: Janeiro 2025

**Versão**: 1.0.0

**Mantenedores**: [Seu Nome/Organização]

---

**Tem alguma sugestão de recurso para adicionar? Abra uma issue ou PR!** 🚀