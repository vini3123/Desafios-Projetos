﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ModelContextProtocol.Server;
using System.ComponentModel;
using Microsoft.Extensions.AI;

var builder = Host.CreateApplicationBuilder(args);

// Configuração de logs para stderr (melhor prática MCP)
builder.Logging.AddConsole(options =>
{
    options.LogToStandardErrorThreshold = LogLevel.Trace;
});

// Configuração do servidor MCP com stdio transport e registro automático
builder.Services
    .AddMcpServer()
    .WithStdioServerTransport()
    .WithPromptsFromAssembly()
    .WithToolsFromAssembly();

await builder.Build().RunAsync();

// ===== PROMPTS =====

/// <summary>
/// Prompts para desenvolvimento de software.
/// </summary>
[McpServerPromptType]
public static class DeveloperPrompts
{
    [McpServerPrompt(Name = "code_review"), Description("Cria um prompt para revisão de código")]
    public static ChatMessage CodeReview(
        [Description("Código para revisar")] string code,
        [Description("Linguagem de programação")] string language = "C#")
    {
        return new ChatMessage(ChatRole.User, 
            $"Revise o seguinte código {language} e forneça sugestões de melhoria:\n\n{code}");
    }

    [McpServerPrompt(Name = "explain_code"), Description("Cria um prompt para explicar código")]
    public static ChatMessage ExplainCode(
        [Description("Código para explicar")] string code)
    {
        return new ChatMessage(ChatRole.User, 
            $"Explique o que este código faz de forma clara e didática:\n\n{code}");
    }

    [McpServerPrompt(Name = "document_function"), Description("Cria um prompt para documentar função")]
    public static ChatMessage DocumentFunction(
        [Description("Código da função")] string functionCode)
    {
        return new ChatMessage(ChatRole.User, 
            $"Crie documentação XML completa para esta função:\n\n{functionCode}");
    }

    [McpServerPrompt(Name = "refactor_code"), Description("Cria um prompt para refatoração de código")]
    public static ChatMessage RefactorCode(
        [Description("Código para refatorar")] string code,
        [Description("Objetivo da refatoração")] string goal = "melhorar legibilidade")
    {
        return new ChatMessage(ChatRole.User, 
            $"Refatore este código com foco em {goal}:\n\n{code}");
    }
}

/// <summary>
/// Prompts para redação e escrita.
/// </summary>
[McpServerPromptType]
public static class WritingPrompts
{
    [McpServerPrompt(Name = "summarize_text"), Description("Cria um prompt para resumir texto")]
    public static ChatMessage Summarize(
        [Description("Texto para resumir")] string content,
        [Description("Número máximo de palavras")] int maxWords = 100)
    {
        return new ChatMessage(ChatRole.User, 
            $"Resuma o seguinte texto em no máximo {maxWords} palavras:\n\n{content}");
    }

    [McpServerPrompt(Name = "improve_writing"), Description("Cria um prompt para melhorar redação")]
    public static ChatMessage ImproveWriting(
        [Description("Texto para melhorar")] string text)
    {
        return new ChatMessage(ChatRole.User, 
            $"Melhore a redação deste texto, mantendo o significado original:\n\n{text}");
    }

    [McpServerPrompt(Name = "translate_text"), Description("Cria um prompt para tradução de texto")]
    public static ChatMessage TranslateText(
        [Description("Texto para traduzir")] string text,
        [Description("Idioma de destino")] string targetLanguage = "inglês")
    {
        return new ChatMessage(ChatRole.User, 
            $"Traduza o seguinte texto para {targetLanguage}, mantendo o tom e contexto:\n\n{text}");
    }

    [McpServerPrompt(Name = "check_grammar"), Description("Cria um prompt para correção gramatical")]
    public static ChatMessage CheckGrammar(
        [Description("Texto para corrigir")] string text)
    {
        return new ChatMessage(ChatRole.User, 
            $"Corrija os erros gramaticais e ortográficos neste texto:\n\n{text}");
    }
}

// ===== TOOLS AUXILIARES =====

/// <summary>
/// Ferramentas auxiliares para o servidor de prompts.
/// </summary>
[McpServerToolType]
public static class PromptHelpers
{
    [McpServerTool(Name = "list_available_prompts"), Description("Lista todos os prompts disponíveis no servidor")]
    public static string ListAvailablePrompts()
    {
        return @"Prompts Disponíveis:

📝 DESENVOLVIMENTO:
  • code_review - Revisa código e fornece sugestões
  • explain_code - Explica o funcionamento do código
  • document_function - Cria documentação XML
  • refactor_code - Refatora código com objetivo específico

✍️ ESCRITA:
  • summarize_text - Resume texto com limite de palavras
  • improve_writing - Melhora a redação do texto
  • translate_text - Traduz texto para outro idioma
  • check_grammar - Corrige erros gramaticais

Use GetPromptAsync() para obter um prompt específico.";
    }

    [McpServerTool(Name = "get_prompt_info"), Description("Obtém informações detalhadas sobre um prompt específico")]
    public static string GetPromptInfo(
        [Description("Nome do prompt")] string promptName)
    {
        return promptName.ToLower() switch
        {
            "code_review" => "Revisa código em qualquer linguagem e fornece sugestões de melhoria. Parâmetros: code (obrigatório), language (opcional, padrão: C#)",
            "explain_code" => "Explica o funcionamento de um código de forma didática. Parâmetros: code (obrigatório)",
            "document_function" => "Gera documentação XML completa para uma função. Parâmetros: functionCode (obrigatório)",
            "refactor_code" => "Refatora código com objetivo específico. Parâmetros: code (obrigatório), goal (opcional, padrão: melhorar legibilidade)",
            "summarize_text" => "Resume texto em número específico de palavras. Parâmetros: content (obrigatório), maxWords (opcional, padrão: 100)",
            "improve_writing" => "Melhora a redação mantendo o significado. Parâmetros: text (obrigatório)",
            "translate_text" => "Traduz texto para outro idioma. Parâmetros: text (obrigatório), targetLanguage (opcional, padrão: inglês)",
            "check_grammar" => "Corrige erros gramaticais e ortográficos. Parâmetros: text (obrigatório)",
            _ => $"Prompt '{promptName}' não encontrado. Use list_available_prompts para ver todos os prompts."
        };
    }

    [McpServerTool(Name = "validate_prompt_args"), Description("Valida se os argumentos fornecidos são válidos para um prompt")]
    public static string ValidatePromptArgs(
        [Description("Nome do prompt")] string promptName,
        [Description("Argumentos em formato JSON")] string argsJson)
    {
        try
        {
            // Validação básica de estrutura JSON
            if (string.IsNullOrWhiteSpace(argsJson))
            {
                return "❌ Erro: argumentos não fornecidos";
            }

            return promptName.ToLower() switch
            {
                "code_review" or "explain_code" or "document_function" or "refactor_code" 
                    => argsJson.Contains("code") 
                        ? "✅ Argumentos válidos" 
                        : "❌ Erro: argumento 'code' é obrigatório",
                
                "summarize_text" or "improve_writing" or "translate_text" or "check_grammar"
                    => argsJson.Contains("text") || argsJson.Contains("content")
                        ? "✅ Argumentos válidos"
                        : "❌ Erro: argumento 'text' ou 'content' é obrigatório",
                
                _ => $"❌ Prompt '{promptName}' não encontrado"
            };
        }
        catch (Exception ex)
        {
            return $"❌ Erro ao validar argumentos: {ex.Message}";
        }
    }
}