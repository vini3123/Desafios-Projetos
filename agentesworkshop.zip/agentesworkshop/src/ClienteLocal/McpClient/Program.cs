﻿using Microsoft.Extensions.Logging;
using ModelContextProtocol;
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;
using System.Text.Json;

// Configurar logging para diagnóstico
using var loggerFactory = LoggerFactory.Create(builder =>
{
    builder
        .AddConsole()
        .SetMinimumLevel(LogLevel.Warning); // Ajuste para Debug se precisar de mais detalhes
});

// Token de cancelamento para operações assíncronas
using var cts = new CancellationTokenSource();
Console.CancelKeyPress += (s, e) =>
{
    Console.WriteLine("\n⚠️  Cancelamento solicitado...");
    cts.Cancel();
    e.Cancel = true;
};

try
{
    Console.WriteLine("=== Cliente MCP - Demonstração ===\n");

    // Configurar transporte para conectar ao servidor
    var clientTransport = new StdioClientTransport(new StdioClientTransportOptions
    {
        Name = "ToolsServerClient",
        Command = "dotnet",
        Arguments = ["run", "--project", "../../ToolsServer"],
    });

    // Configurar opções do cliente com informações e timeouts
    var clientOptions = new McpClientOptions
    {
        ClientInfo = new Implementation
        {
            Name = "McpClient Demo",
            Version = "1.0.0"
        },
        InitializationTimeout = TimeSpan.FromSeconds(30),
        Capabilities = new ClientCapabilities()
    };

    // Criar e conectar o cliente
    await using var client = await McpClient.CreateAsync(
        clientTransport,
        clientOptions,
        loggerFactory,
        cts.Token);

    Console.WriteLine("✅ Conectado ao servidor MCP com sucesso");
    
    // Exibir informações do servidor
    if (client.ServerInfo != null)
    {
        Console.WriteLine($"   Servidor: {client.ServerInfo.Name} v{client.ServerInfo.Version}");
    }
    if (!string.IsNullOrEmpty(client.ServerInstructions))
    {
        Console.WriteLine($"   Instruções: {client.ServerInstructions}");
    }
    Console.WriteLine($"   Protocolo: {client.NegotiatedProtocolVersion}\n");

    // Listar todas as ferramentas disponíveis
    Console.WriteLine("📋 Ferramentas disponíveis:");
    var tools = await client.ListToolsAsync(cancellationToken: cts.Token);
    
    if (!tools.Any())
    {
        Console.WriteLine("   ⚠️  Nenhuma ferramenta disponível no servidor.");
        return;
    }

    foreach (var tool in tools)
    {
        Console.WriteLine($"  • {tool.Name}");
        if (!string.IsNullOrEmpty(tool.Description))
        {
            Console.WriteLine($"    {tool.Description}");
        }
    }

    Console.WriteLine("\n" + new string('=', 50) + "\n");

    // Exemplo 1: Ferramentas de Calculadora
    Console.WriteLine("🧮 Exemplo 1: Ferramentas de Calculadora\n");
    
    var addResult = await client.CallToolAsync(
        "add",
        new Dictionary<string, object?> { ["a"] = 10, ["b"] = 5 },
        cancellationToken: cts.Token);
    Console.WriteLine($"  ➕ Adição: 10 + 5 = {ExtractTextContent(addResult)}");

    var subtractResult = await client.CallToolAsync(
        "subtract",
        new Dictionary<string, object?> { ["a"] = 20, ["b"] = 8 },
        cancellationToken: cts.Token);
    Console.WriteLine($"  ➖ Subtração: 20 - 8 = {ExtractTextContent(subtractResult)}");

    var multiplyResult = await client.CallToolAsync(
        "multiply",
        new Dictionary<string, object?> { ["a"] = 7, ["b"] = 6 },
        cancellationToken: cts.Token);
    Console.WriteLine($"  ✖️  Multiplicação: 7 × 6 = {ExtractTextContent(multiplyResult)}");

    var divideResult = await client.CallToolAsync(
        "divide",
        new Dictionary<string, object?> { ["a"] = 100, ["b"] = 4 },
        cancellationToken: cts.Token);
    Console.WriteLine($"  ➗ Divisão: 100 ÷ 4 = {ExtractTextContent(divideResult)}");

    Console.WriteLine("\n" + new string('=', 50) + "\n");

    // Exemplo 2: Ferramentas de Manipulação de Texto
    Console.WriteLine("📝 Exemplo 2: Ferramentas de Manipulação de Texto\n");
    var text = "Olá Mundo MCP";
    Console.WriteLine($"  Texto original: \"{text}\"\n");

    var upperResult = await client.CallToolAsync(
        "toUpperCase",
        new Dictionary<string, object?> { ["text"] = text },
        cancellationToken: cts.Token);
    Console.WriteLine($"  🔠 Maiúsculas: {ExtractTextContent(upperResult)}");

    var lowerResult = await client.CallToolAsync(
        "toLowerCase",
        new Dictionary<string, object?> { ["text"] = text },
        cancellationToken: cts.Token);
    Console.WriteLine($"  🔡 Minúsculas: {ExtractTextContent(lowerResult)}");

    var reverseResult = await client.CallToolAsync(
        "reverseText",
        new Dictionary<string, object?> { ["text"] = text },
        cancellationToken: cts.Token);
    Console.WriteLine($"  🔄 Reverso: {ExtractTextContent(reverseResult)}");

    var countWordsResult = await client.CallToolAsync(
        "countWords",
        new Dictionary<string, object?> { ["text"] = text },
        cancellationToken: cts.Token);
    Console.WriteLine($"  📊 Palavras: {ExtractTextContent(countWordsResult)}");

    var countCharsResult = await client.CallToolAsync(
        "countCharacters",
        new Dictionary<string, object?> { ["text"] = text },
        cancellationToken: cts.Token);
    Console.WriteLine($"  🔢 Caracteres: {ExtractTextContent(countCharsResult)}");

    Console.WriteLine("\n✨ Demo concluída com sucesso! Todas as ferramentas foram testadas.");
}
catch (OperationCanceledException)
{
    Console.WriteLine("\n❌ Operação cancelada pelo usuário.");
}
catch (TimeoutException ex)
{
    Console.WriteLine($"\n❌ Timeout durante conexão: {ex.Message}");
}
catch (McpException ex)
{
    Console.WriteLine($"\n❌ Erro do protocolo MCP: {ex.Message}");
}
catch (Exception ex)
{
    Console.WriteLine($"\n❌ Erro inesperado: {ex.GetType().Name}");
    Console.WriteLine($"   Mensagem: {ex.Message}");
    if (ex.InnerException != null)
    {
        Console.WriteLine($"   Causa: {ex.InnerException.Message}");
    }
}

// Função auxiliar para extrair conteúdo de texto de forma robusta
static string ExtractTextContent(CallToolResult result)
{
    if (result?.Content == null || !result.Content.Any())
    {
        return "N/A";
    }

    // Procurar por conteúdo do tipo texto
    var textContent = result.Content.FirstOrDefault(c => c.Type == "text");
    if (textContent != null)
    {
        // Serializar e deserializar para obter a propriedade text
        var json = JsonSerializer.SerializeToElement(textContent);
        if (json.TryGetProperty("text", out var textProp))
        {
            return textProp.GetString() ?? "N/A";
        }
    }

    return "N/A";
}