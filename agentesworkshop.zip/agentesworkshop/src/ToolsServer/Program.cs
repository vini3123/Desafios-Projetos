﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ModelContextProtocol.Server;
using System.ComponentModel;

var builder = Host.CreateApplicationBuilder(args);

// Configurar logs para stderr (MCP usa stdout para protocolo)
builder.Logging.AddConsole(options =>
{
    options.LogToStandardErrorThreshold = LogLevel.Trace;
});

// Adicionar MCP Server com informações do servidor
builder.Services
    .AddMcpServer(options =>
    {
        options.ServerInfo = new()
        {
            Name = "ToolsServer",
            Version = "1.0.0"
        };
        options.ServerInstructions = "Servidor MCP com ferramentas de calculadora e manipulação de texto.";
    })
    .WithStdioServerTransport()
    .WithToolsFromAssembly();

await builder.Build().RunAsync();

// ===== FERRAMENTAS (TOOLS) =====

/// <summary>
/// Ferramentas de calculadora para operações matemáticas básicas
/// </summary>
[McpServerToolType]
public static class CalculatorTools
{
    [McpServerTool(Name = "add"), Description("Soma dois números")]
    public static double Add(
        [Description("Primeiro número")] double a,
        [Description("Segundo número")] double b)
    {
        return a + b;
    }

    [McpServerTool(Name = "subtract"), Description("Subtrai dois números")]
    public static double Subtract(
        [Description("Primeiro número (minuendo)")] double a,
        [Description("Segundo número (subtraendo)")] double b) => a - b;

    [McpServerTool(Name = "multiply"), Description("Multiplica dois números")]
    public static double Multiply(
        [Description("Primeiro número")] double a,
        [Description("Segundo número")] double b) => a * b;

    [McpServerTool(Name = "divide"), Description("Divide dois números")]
    public static double Divide(
        [Description("Numerador (dividendo)")] double a,
        [Description("Denominador (divisor)")] double b)
    {
        if (b == 0)
            throw new ArgumentException("Não é possível dividir por zero");
        return a / b;
    }
}

/// <summary>
/// Ferramentas para manipulação e análise de texto
/// </summary>
[McpServerToolType]
public static class TextTools
{
    [McpServerTool(Name = "toUpperCase"), Description("Converte texto para maiúsculas")]
    public static string ToUpperCase(
        [Description("Texto a converter")] string text)
    {
        ArgumentException.ThrowIfNullOrEmpty(text, nameof(text));
        return text.ToUpper();
    }

    [McpServerTool(Name = "toLowerCase"), Description("Converte texto para minúsculas")]
    public static string ToLowerCase(
        [Description("Texto a converter")] string text)
    {
        ArgumentException.ThrowIfNullOrEmpty(text, nameof(text));
        return text.ToLower();
    }

    [McpServerTool(Name = "countWords"), Description("Conta o número de palavras no texto")]
    public static int CountWords(
        [Description("Texto para contar palavras")] string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return 0;
        
        return text.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length;
    }

    [McpServerTool(Name = "reverseText"), Description("Reverte a ordem dos caracteres de uma string")]
    public static string Reverse(
        [Description("Texto a reverter")] string text)
    {
        ArgumentException.ThrowIfNullOrEmpty(text, nameof(text));
        char[] chars = text.ToCharArray();
        Array.Reverse(chars);
        return new string(chars);
    }

    [McpServerTool(Name = "countCharacters"), Description("Conta o número de caracteres no texto")]
    public static int CountCharacters(
        [Description("Texto para contar caracteres")] string text)
    {
        return text?.Length ?? 0;
    }
}