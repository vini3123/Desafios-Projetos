using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using ModelContextProtocol.AspNetCore;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;
using System.ComponentModel;

var builder = WebApplication.CreateBuilder(args);

// Configure logging to stderr (best practice for MCP servers)
builder.Logging.ClearProviders();
builder.Logging.AddConsole(options =>
{
    options.LogToStandardErrorThreshold = LogLevel.Information;
});

// Configure URLs
builder.WebHost.UseUrls("http://localhost:5000");

// Configure MCP Server with best practices
builder.Services
    .AddMcpServer(options =>
    {
        // Definir informações do servidor
        options.ServerInfo = new Implementation
        {
            Name = "HttpMcpServer",
            Version = "1.0.0"
        };
        
        // Adicionar instruções do servidor para melhor contexto da LLM
        options.ServerInstructions = """
            Este é um servidor MCP HTTP remoto que fornece ferramentas de informações do sistema.
            Ferramentas disponíveis:
            - GetSystemInfo: Retorna informações detalhadas do sistema incluindo SO, contagem de CPU e tempo de atividade
            - GenerateUuid: Gera um UUID único
            - CalculateHash: Calcula o hash SHA256 do texto de entrada
            - GetCurrentTime: Obtém data e hora em vários formatos
            - GetProcessInfo: Obtém estatísticas do processo atual
            """;
    })
    .WithHttpTransport(httpOptions =>
    {
        // Configurar tempo limite de inatividade (padrão é 2 horas)
        // Use Timeout.InfiniteTimeSpan se quiser que as sessões nunca expirem
        httpOptions.IdleTimeout = TimeSpan.FromHours(2);
        
        // Número máximo de sessões inativas a rastrear
        httpOptions.MaxIdleSessionCount = 10_000;
        
        // Habilitar modo stateless se estiver executando em ambiente com balanceamento de carga
        // httpOptions.Stateless = true;
    })
    .WithToolsFromAssembly();

// Adicionar CORS com configuração mais específica
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader()
              .WithExposedHeaders("Mcp-Session-Id"); // Expor cabeçalho de sessão MCP
    });
});

var app = builder.Build();

// Usar CORS antes do roteamento
app.UseCors();

// Mapear endpoint MCP na raiz
app.MapMcp();

// Endpoint de verificação de saúde
app.MapGet("/health", () => Results.Ok(new
{
    status = "saudavel",
    service = "Servidor MCP HTTP",
    version = "1.0.0",
    timestamp = DateTime.UtcNow
}));

// Endpoint de informações do servidor
app.MapGet("/info", () => Results.Ok(new
{
    name = "HttpMcpServer",
    version = "1.0.0",
    transport = "HTTP (Streamable HTTP)",
    endpoints = new
    {
        mcp = "/",
        health = "/health",
        info = "/info"
    }
}));

Console.WriteLine("🚀 Servidor MCP HTTP em execução em http://localhost:5000");
Console.WriteLine("📍 Endpoint MCP: http://localhost:5000/");
Console.WriteLine("💚 Verificação de Saúde: http://localhost:5000/health");
Console.WriteLine("ℹ️  Informações do Servidor: http://localhost:5000/info");
Console.WriteLine();
Console.WriteLine("Ferramentas Disponíveis:");
Console.WriteLine("  • GetSystemInfo - Obter informações do sistema");
Console.WriteLine("  • GenerateUuid - Gerar um UUID único");
Console.WriteLine("  • CalculateHash - Calcular hash SHA256");
Console.WriteLine("  • GetCurrentTime - Obter data e hora em vários formatos");
Console.WriteLine("  • GetProcessInfo - Obter estatísticas do processo");

app.Run();

// ===== FERRAMENTAS =====

/// <summary>
/// Coleção de ferramentas remotas do sistema para clientes MCP.
/// </summary>
[McpServerToolType]
public static class RemoteTools
{
    /// <summary>
    /// Obtém informações completas do sistema.
    /// </summary>
    /// <returns>Informações do sistema incluindo nome da máquina, versão do SO, contagem de processadores, hora atual e tempo de atividade.</returns>
    [McpServerTool]
    [Description("Obtém informações detalhadas do sistema incluindo nome da máquina, versão do SO, contagem de processadores, hora atual e tempo de atividade")]
    public static object GetSystemInfo()
    {
        return new
        {
            MachineName = Environment.MachineName,
            OSVersion = Environment.OSVersion.ToString(),
            ProcessorCount = Environment.ProcessorCount,
            Is64BitOperatingSystem = Environment.Is64BitOperatingSystem,
            Is64BitProcess = Environment.Is64BitProcess,
            SystemDirectory = Environment.SystemDirectory,
            CurrentTime = DateTime.Now,
            CurrentTimeUtc = DateTime.UtcNow,
            Uptime = TimeSpan.FromMilliseconds(Environment.TickCount64),
            UserName = Environment.UserName,
            UserDomainName = Environment.UserDomainName,
            WorkingSet = Environment.WorkingSet,
            SystemPageSize = Environment.SystemPageSize
        };
    }

    /// <summary>
    /// Gera um novo identificador único (UUID/GUID).
    /// </summary>
    /// <returns>Um UUID recém-gerado em formato string.</returns>
    [McpServerTool]
    [Description("Gera um identificador único universal (UUID/GUID) em formato string")]
    public static string GenerateUuid()
    {
        return Guid.NewGuid().ToString();
    }

    /// <summary>
    /// Calcula o hash criptográfico SHA256 do texto de entrada.
    /// </summary>
    /// <param name="input">O texto string para calcular o hash.</param>
    /// <returns>A representação hexadecimal do hash SHA256.</returns>
    [McpServerTool]
    [Description("Calcula o hash criptográfico SHA256 de um texto e retorna em formato hexadecimal")]
    public static string CalculateHash(
        [Description("O texto de entrada para calcular o hash SHA256")] string input)
    {
        if (string.IsNullOrEmpty(input))
        {
            throw new ArgumentException("A entrada não pode ser nula ou vazia", nameof(input));
        }

        using var sha256 = System.Security.Cryptography.SHA256.Create();
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(input);
        byte[] hash = sha256.ComputeHash(bytes);
        return Convert.ToHexString(hash);
    }

    /// <summary>
    /// Obtém a data e hora atual em vários formatos e fusos horários.
    /// </summary>
    /// <returns>Informações de hora atual em múltiplos formatos.</returns>
    [McpServerTool]
    [Description("Obtém a data e hora atual em vários formatos e fusos horários")]
    public static object GetCurrentTime()
    {
        var now = DateTime.Now;
        var utcNow = DateTime.UtcNow;
        
        return new
        {
            Local = now.ToString("O"),
            UTC = utcNow.ToString("O"),
            UnixTimestamp = ((DateTimeOffset)utcNow).ToUnixTimeSeconds(),
            UnixTimestampMilliseconds = ((DateTimeOffset)utcNow).ToUnixTimeMilliseconds(),
            ISO8601 = utcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
            TimeZone = TimeZoneInfo.Local.DisplayName,
            TimeZoneId = TimeZoneInfo.Local.Id
        };
    }

    /// <summary>
    /// Obtém informações sobre o processo atual.
    /// </summary>
    /// <returns>Informações do processo incluindo ID, uso de memória e contagem de threads.</returns>
    [McpServerTool]
    [Description("Obtém informações sobre o processo atual incluindo ID, uso de memória e contagem de threads")]
    public static object GetProcessInfo()
    {
        using var process = System.Diagnostics.Process.GetCurrentProcess();
        
        return new
        {
            ProcessId = process.Id,
            ProcessName = process.ProcessName,
            StartTime = process.StartTime,
            TotalProcessorTime = process.TotalProcessorTime,
            UserProcessorTime = process.UserProcessorTime,
            PrivilegedProcessorTime = process.PrivilegedProcessorTime,
            WorkingSet64 = process.WorkingSet64,
            PrivateMemorySize64 = process.PrivateMemorySize64,
            VirtualMemorySize64 = process.VirtualMemorySize64,
            ThreadCount = process.Threads.Count,
            HandleCount = process.HandleCount
        };
    }
}