using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;
using Microsoft.Extensions.Configuration;
using System.Text.Json;

Console.WriteLine("=== MCP HTTP Client Demo ===\n");

// Load configuration from appsettings.json
var configuration = new ConfigurationBuilder()
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
    .Build();   

// Get endpoint from configuration
var endpoint = configuration["McpServer:Endpoint"] ?? "http://localhost:5000";

Console.WriteLine($"🔗 Conectando ao servidor: {endpoint}\n");

try
{
    // Create HTTP client transport using the built-in SDK class
    var transportOptions = new HttpClientTransportOptions
    {
        Endpoint = new Uri(endpoint),
        TransportMode = HttpTransportMode.AutoDetect, // Auto-detect between StreamableHttp and SSE
        Name = "HttpMcpClient"
    };
    
    await using var transport = new HttpClientTransport(transportOptions);
    await using var client = await McpClient.CreateAsync(transport);

    Console.WriteLine("✅ Conectado ao servidor HTTP MCP\n");

    // List available tools
    var tools = await client.ListToolsAsync();
    Console.WriteLine("📋 Ferramentas disponíveis:");
    foreach (var tool in tools)
    {
        Console.WriteLine($"  • {tool.Name}: {tool.Description}");
    }

    // Test tools
    Console.WriteLine("\n🔧 Testando ferramentas:\n");

    // get_system_info returns JSON
    var sysInfo = await client.CallToolAsync(
        "get_system_info",
        cancellationToken: CancellationToken.None);
    Console.WriteLine($"System Info: {GetContentString(sysInfo)}");

    // generate_uuid returns text
    var uuid = await client.CallToolAsync(
        "generate_uuid",
        cancellationToken: CancellationToken.None);
    Console.WriteLine($"UUID: {GetContentString(uuid)}");

    // calculate_hash returns text
    var hash = await client.CallToolAsync(
        "calculate_hash",
        new Dictionary<string, object?> { ["input"] = "Hello MCP" },
        cancellationToken: CancellationToken.None);
    Console.WriteLine($"Hash: {GetContentString(hash)}");

    Console.WriteLine("\n✨ Demo concluída!");
}
catch (Exception ex)
{
    Console.WriteLine($"❌ Erro: {ex.Message}");
    Console.WriteLine($"Stack: {ex.StackTrace}");
}

// Helper: extracts text or JSON content as string
static string GetContentString(CallToolResult result)
{
    // Try text block
    if (result.Content.FirstOrDefault(c => c.Type == "text") is TextContentBlock textBlock)
    {
        return textBlock.Text ?? "N/A";
    }

    // Try JSON block - handle as JsonElement
    if (result.Content.FirstOrDefault(c => c.Type == "json") is var jsonBlock && jsonBlock != null)
    {
        try
        {
            var jsonProp = jsonBlock.GetType().GetProperty("Json");
            if (jsonProp?.GetValue(jsonBlock) is JsonElement jsonElement)
            {
                return JsonSerializer.Serialize(jsonElement, new JsonSerializerOptions { WriteIndented = true });
            }
        }
        catch
        {
            // Fallback
        }
    }

    // Fallback
    return "N/A";
}