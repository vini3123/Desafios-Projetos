# Zenith - Wireframe

Este é um wireframe de média fidelidade para um site de uma página para um aplicativo de produtividade fictício chamado Zenith.

## Como visualizar

1. Abra o arquivo `index.html` em um navegador da web.

## Tecnologias utilizadas

* HTML
* CSS
* Bootstrap
