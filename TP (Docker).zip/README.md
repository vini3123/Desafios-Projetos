# Solução Arquitetural: OMS com Vertical Slice e Event-Driven (C# + Docker Compose)

Este projeto demonstra a aplicação da arquitetura **Vertical Slice** complementada pelo padrão **Event-Driven** (Baseada em Mensagens), conforme proposto na análise do cenário de um Sistema de Gerenciamento de Pedidos (OMS) para restaurantes.

A solução é implementada em **C# (.NET 8)** e orquestrada com **Docker Compose**, utilizando **RabbitMQ** como Message Broker.

## 1. Arquitetura Implementada

A arquitetura é dividida em dois serviços principais, representando duas *Vertical Slices* desacopladas:

| Serviço (Slice) | Tipo de Projeto | Responsabilidade | Padrão Arquitetural |
| :--- | :--- | :--- | :--- |
| `Oms.OrderSlice` | ASP.NET Core Web API | Receber pedidos (síncrono) e publicar o evento `OrderCreatedEvent`. | **Vertical Slice** (Criação de Pedido) |
| `Oms.NotificationSlice` | .NET Worker Service | Consumir o evento `OrderCreatedEvent` e simular o envio de notificação ao cliente (assíncrono). | **Event-Driven** (Consumidor de Eventos) |

O **RabbitMQ** atua como o **Message Broker**, garantindo o desacoplamento e a resiliência entre os serviços.

## 2. Fluxo de Execução

1.  O cliente envia uma requisição HTTP POST para a API `Oms.OrderSlice` (Web API).
2.  O `OrdersController` (dentro da *slice* de Pedidos) simula a lógica de negócio.
3.  O `RabbitMQPublisher` publica o evento `OrderCreatedEvent` no `oms_events` Exchange do RabbitMQ.
4.  A API retorna uma resposta síncrona ao cliente.
5.  O `Oms.NotificationSlice` (Worker Service) consome o evento da fila.
6.  O `Worker` (dentro da *slice* de Notificação) simula o processamento assíncrono (envio de e-mail).

## 3. Estrutura do Projeto

```
.
├── OmsArchitecture.sln
├── docker-compose.yml
└── src/
    ├── Oms.OrderSlice/
    │   ├── Controllers/OrdersController.cs  # Ponto de entrada da Slice
    │   ├── Models/OrderCreatedEvent.cs      # DTO do Evento
    │   ├── Services/RabbitMQPublisher.cs    # Produtor de Eventos
    │   ├── Program.cs
    │   └── Dockerfile
    └── Oms.NotificationSlice/
        ├── Models/OrderCreatedEvent.cs      # DTO do Evento (Consumidor)
        ├── Worker.cs                        # Consumidor de Eventos (Handler da Slice)
        └── Dockerfile
```

## 4. Instruções de Execução

### Pré-requisitos

*   Docker e Docker Compose instalados.

### Passos

1.  **Construir e Iniciar os Contêineres:**
    Execute o comando na raiz do projeto (onde está o `docker-compose.yml`):
    ```bash
    docker-compose up --build
    ```
    *Aguarde alguns segundos até que todos os serviços estejam saudáveis e o `notification-slice` comece a rodar.*

2.  **Enviar um Pedido (Web API):**
    A API de Pedidos está exposta na porta `8080`. Você pode usar `curl` ou qualquer cliente HTTP (como Postman) para enviar um pedido.

    **Exemplo de `curl`:**
    ```bash
    curl -X POST http://localhost:8080/api/orders \
    -H "Content-Type: application/json" \
    -d '{
        "customerEmail": "cliente@exemplo.com",
        "items": ["Pizza", "Refrigerante"],
        "totalAmount": 45.99
    }'
    ```

3.  **Verificar o Fluxo Assíncrono:**
    Observe os logs no seu terminal. Você verá:
    *   O `order-slice` registrando o recebimento do pedido e a publicação do evento.
    *   O `notification-slice` registrando o consumo do evento e a simulação do envio do e-mail.

    Isso demonstra o **desacoplamento** (a API responde rapidamente) e o **processamento assíncrono** (a notificação é processada em segundo plano).

4.  **Parar os Contêineres:**
    Pressione `Ctrl+C` no terminal e execute:
    ```bash
    docker-compose down
    ```

***

*Documento elaborado por Manus AI.*
