using Microsoft.AspNetCore.Mvc;
using Oms.OrderSlice.Models;
using Oms.OrderSlice.Services;

namespace Oms.OrderSlice.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly RabbitMQPublisher _publisher;

    public OrdersController(RabbitMQPublisher publisher)
    {
        _publisher = publisher;
    }

    // Este método representa a "Vertical Slice" de criação de pedido.
    // Ele contém toda a lógica necessária para esta feature:
    // 1. Receber a requisição (Controller)
    // 2. Simular a lógica de negócio (Handler/Service)
    // 3. Publicar o evento (Event-Driven)
    [HttpPost]
    public IActionResult CreateOrder([FromBody] CreateOrderRequest request)
    {
        // 1. Simulação da Lógica de Negócio (Vertical Slice - Handler)
        // Em um projeto real, aqui haveria validação, persistência no DB, etc.
        var newOrderId = Guid.NewGuid();
        
        Console.WriteLine($"[OrderSlice] Pedido {newOrderId} recebido de {request.CustomerEmail}. Total: {request.TotalAmount:C}");
        
        // 2. Publicação do Evento (Event-Driven)
        var orderEvent = new OrderCreatedEvent
        {
            OrderId = newOrderId,
            CustomerEmail = request.CustomerEmail,
            TotalAmount = request.TotalAmount
        };
        
        _publisher.PublishOrderCreatedEvent(orderEvent);

        // 3. Resposta Síncrona
        return CreatedAtAction(nameof(CreateOrder), new { id = newOrderId }, new { message = "Pedido criado e evento publicado com sucesso." });
    }
}
