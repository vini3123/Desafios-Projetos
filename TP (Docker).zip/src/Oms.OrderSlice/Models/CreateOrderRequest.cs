using System.ComponentModel.DataAnnotations;

namespace Oms.OrderSlice.Models;

public class CreateOrderRequest
{
    [Required]
    public string CustomerEmail { get; set; }
    
    [Required]
    public List<string> Items { get; set; } = new List<string>();
    
    [Required]
    [Range(0.01, double.MaxValue)]
    public decimal TotalAmount { get; set; }
}
