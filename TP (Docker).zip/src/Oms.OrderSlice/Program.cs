using Oms.OrderSlice.Services;

var builder = WebApplication.CreateBuilder(args);

// 1. Adicionar serviços ao contêiner.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Adiciona o RabbitMQPublisher como Singleton para reutilizar a conexão.
builder.Services.AddSingleton<RabbitMQPublisher>();

var app = builder.Build();

// 2. Configurar o pipeline de requisições HTTP.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
();
