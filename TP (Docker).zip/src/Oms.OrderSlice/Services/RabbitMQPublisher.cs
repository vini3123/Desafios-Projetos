using System.Text;
using System.Text.Json;
using RabbitMQ.Client;
using Oms.OrderSlice.Models;

namespace Oms.OrderSlice.Services;

public class RabbitMQPublisher : IDisposable
{
    private readonly IConnection _connection;
    private readonly IModel _channel;
    private const string ExchangeName = "oms_events";

    public RabbitMQPublisher()
    {
        var factory = new ConnectionFactory { HostName = "rabbitmq" }; // 'rabbitmq' é o nome do serviço no docker-compose
        _connection = factory.CreateConnection();
        _channel = _connection.CreateModel();
        
        // Declara o Exchange para o padrão Publish/Subscribe
        _channel.ExchangeDeclare(exchange: ExchangeName, type: ExchangeType.Fanout);
    }

    public void PublishOrderCreatedEvent(OrderCreatedEvent orderEvent)
    {
        var message = JsonSerializer.Serialize(orderEvent);
        var body = Encoding.UTF8.GetBytes(message);

        _channel.BasicPublish(
            exchange: ExchangeName,
            routingKey: string.Empty, // Fanout ignora routing key
            basicProperties: null,
            body: body);

        Console.WriteLine($" [x] Sent OrderCreatedEvent for OrderId: {orderEvent.OrderId}");
    }

    public void Dispose()
    {
        _channel.Dispose();
        _connection.Dispose();
    }
}
