using System.Text;
using System.Text.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Oms.NotificationSlice.Models;

namespace Oms.NotificationSlice;

public class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private IConnection _connection;
    private IModel _channel;
    private const string ExchangeName = "oms_events";
    private const string QueueName = "notification_queue";

    public Worker(ILogger<Worker> logger)
    {
        _logger = logger;
        // A inicialização será feita no ExecuteAsync para garantir que o RabbitMQ esteja pronto
    }

    private void InitializeRabbitMQ()
    {
        var factory = new ConnectionFactory { HostName = "rabbitmq", DispatchConsumersAsync = true };
        _connection = factory.CreateConnection();
        _channel = _connection.CreateModel();

        _channel.ExchangeDeclare(exchange: ExchangeName, type: ExchangeType.Fanout);
        _channel.QueueDeclare(queue: QueueName, durable: true, exclusive: false, autoDelete: false, arguments: null);
        _channel.QueueBind(queue: QueueName, exchange: ExchangeName, routingKey: "");

        _logger.LogInformation("--> RabbitMQ connection established.");
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        stoppingToken.ThrowIfCancellationRequested();

        // Adiciona um delay para garantir que o RabbitMQ esteja pronto no Docker Compose
        await Task.Delay(15000, stoppingToken); 

        InitializeRabbitMQ();

        var consumer = new AsyncEventingBasicConsumer(_channel);
        consumer.Received += async (model, ea) =>
        {
            var body = ea.Body.ToArray();
            var message = Encoding.UTF8.GetString(body);
            try
            {
                var orderEvent = JsonSerializer.Deserialize<OrderCreatedEvent>(message);
                HandleOrderCreatedEvent(orderEvent);
                _channel.BasicAck(ea.DeliveryTag, false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing message: {Message}", message);
                _channel.BasicNack(ea.DeliveryTag, false, true);
            }
            await Task.Yield();
        };

        _channel.BasicConsume(queue: QueueName, autoAck: false, consumer: consumer);

        await Task.CompletedTask;
    }

    private void HandleOrderCreatedEvent(OrderCreatedEvent orderEvent)
    {
        _logger.LogInformation("[NotificationSlice] Received OrderCreatedEvent for OrderId: {OrderId}", orderEvent.OrderId);
        _logger.LogInformation("[NotificationSlice] Sending confirmation email to {CustomerEmail} for amount {TotalAmount}", orderEvent.CustomerEmail, orderEvent.TotalAmount);
    }

    public override void Dispose()
    {
        _channel?.Close();
        _connection?.Close();
        base.Dispose();
    }
}
