import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import os

def verificar_arquivos():
    """Verifica se os arquivos necessários existem"""
    arquivos_necessarios = ['emprestimos_sample.csv', 'acervo_sample.csv']
    faltantes = [arq for arq in arquivos_necessarios if not os.path.exists(arq)]
    
    if faltantes:
        print(f"Erro: Os seguintes arquivos não foram encontrados: {', '.join(faltantes)}")
        print("Certifique-se de que os arquivos estão na mesma pasta do script.")
        return False
    return True

def carregar_dados():
    """Carrega e limpa os dados de empréstimos e acervo"""
    try:
        # Carregar os dados
        emprestimos = pd.read_csv('emprestimos_sample.csv', parse_dates=['data_emprestimo', 'data_devolucao'])
        acervo = pd.read_csv('acervo_sample.csv')
        
        print("\nDados carregados com sucesso!")
        print(f"Total de registros de empréstimos: {len(emprestimos)}")
        print(f"Total de itens no acervo: {len(acervo)}")
        
        return emprestimos, acervo
    except Exception as e:
        print(f"\nErro ao carregar dados: {e}")
        return None, None

def preprocessar_emprestimos(df):
    """Preprocessa os dados de empréstimos"""
    print("\nPré-processamento de empréstimos:")
    
    # Filtrar últimos 10 anos
    ano_atual = datetime.now().year
    df = df[df['data_emprestimo'].dt.year >= (ano_atual - 10)]
    print(f"- Filtrado para últimos 10 anos: {len(df)} registros")
    
    # Remover duplicatas
    df = df.drop_duplicates()
    print(f"- Removidas duplicatas: {len(df)} registros")
    
    # Remover linhas com valores nulos essenciais
    df = df.dropna(subset=['codigo_barras', 'data_emprestimo'])
    print(f"- Removidos registros com valores nulos: {len(df)} registros finais")
    
    return df

def preprocessar_acervo(df):
    """Preprocessa os dados do acervo"""
    print("\nPré-processamento do acervo:")
    
    # Remover duplicatas
    df = df.drop_duplicates(subset=['codigo_barras'])
    print(f"- Removidas duplicatas: {len(df)} registros")
    
    # Preencher valores nulos
    df['biblioteca'] = df['biblioteca'].fillna('DESCONHECIDA')
    df['tema'] = df['tema'].fillna('SEM TEMA')
    print("- Valores nulos preenchidos")
    
    return df

def mesclar_dados(emprestimos, acervo):
    """Mescla os dados de empréstimos e acervo"""
    print("\nMesclando dados...")
    dados_completos = pd.merge(emprestimos, acervo, on='codigo_barras', how='left')
    
    # Preencher NA após merge
    dados_completos['biblioteca'] = dados_completos['biblioteca'].fillna('NÃO ENCONTRADO')
    dados_completos['tema'] = dados_completos['tema'].fillna('NÃO CATALOGADO')
    
    print(f"Total de registros após merge: {len(dados_completos)}")
    print("\nAmostra dos dados mesclados:")
    print(dados_completos.head())
    
    return dados_completos

def analisar_tendencia_anual(df):
    """Analisa a tendência de empréstimos por ano"""
    df['ano'] = df['data_emprestimo'].dt.year
    emprestimos_por_ano = df.groupby('ano').size().reset_index(name='total')
    
    plt.figure(figsize=(10, 6))
    sns.lineplot(data=emprestimos_por_ano, x='ano', y='total', marker='o')
    plt.title('Empréstimos por Ano - UFRN')
    plt.xlabel('Ano')
    plt.ylabel('Total de Empréstimos')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('emprestimos_por_ano.png')
    plt.close()
    print("\nGráfico de tendência anual salvo como 'emprestimos_por_ano.png'")

def analisar_bibliotecas(df):
    """Analisa as bibliotecas com mais empréstimos"""
    top_bibliotecas = df['biblioteca'].value_counts().head(10)
    
    plt.figure(figsize=(12, 6))
    sns.barplot(x=top_bibliotecas.values, y=top_bibliotecas.index, palette='viridis')
    plt.title('Top 10 Bibliotecas por Empréstimos - UFRN')
    plt.xlabel('Total de Empréstimos')
    plt.ylabel('Biblioteca')
    plt.tight_layout()
    plt.savefig('top_bibliotecas.png')
    plt.close()
    print("Gráfico de top bibliotecas salvo como 'top_bibliotecas.png'")

def analisar_temas(df):
    """Analisa os temas mais populares"""
    top_temas = df['tema'].value_counts().head(10)
    
    plt.figure(figsize=(12, 6))
    sns.barplot(x=top_temas.values, y=top_temas.index, palette='rocket')
    plt.title('Top 10 Temas por Empréstimos - UFRN')
    plt.xlabel('Total de Empréstimos')
    plt.ylabel('Tema')
    plt.tight_layout()
    plt.savefig('top_temas.png')
    plt.close()
    print("Gráfico de top temas salvo como 'top_temas.png'")

def gerar_relatorio(df):
    """Gera um relatório textual com as principais estatísticas"""
    relatorio = []
    
    # Cabeçalho
    relatorio.append("=== RELATÓRIO DE ANÁLISE DE EMPRÉSTIMOS DA UFRN ===")
    relatorio.append(f"Data da análise: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    relatorio.append(f"Período analisado: {df['data_emprestimo'].dt.year.min()} - {df['data_emprestimo'].dt.year.max()}")
    relatorio.append(f"Total de empréstimos analisados: {len(df):,}")
    
    # Bibliotecas
    top_bib = df['biblioteca'].value_counts().head(3)
    relatorio.append("\n=== TOP 3 BIBLIOTECAS ===")
    for i, (bib, qtd) in enumerate(top_bib.items(), 1):
        relatorio.append(f"{i}. {bib}: {qtd:,} empréstimos ({qtd/len(df)*100:.1f}%)")
    
    # Temas
    top_temas = df['tema'].value_counts().head(3)
    relatorio.append("\n=== TOP 3 TEMAS ===")
    for i, (tema, qtd) in enumerate(top_temas.items(), 1):
        relatorio.append(f"{i}. {tema}: {qtd:,} empréstimos ({qtd/len(df)*100:.1f}%)")
    
    # Duração dos empréstimos
    df['duracao'] = (df['data_devolucao'] - df['data_emprestimo']).dt.days
    relatorio.append("\n=== DURAÇÃO DOS EMPRÉSTIMOS ===")
    relatorio.append(f"Duração média: {df['duracao'].mean():.1f} dias")
    relatorio.append(f"Duração máxima: {df['duracao'].max()} dias")
    relatorio.append(f"Duração mínima: {df['duracao'].min()} dias")
    
    # Salvar relatório
    with open('relatorio_emprestimos.txt', 'w', encoding='utf-8') as f:
        f.write('\n'.join(relatorio))
    
    print("\nRelatório textual salvo como 'relatorio_emprestimos.txt'")
    print("\nConteúdo do relatório:")
    print('\n'.join(relatorio))

def main():
    print("=== ANÁLISE DE DADOS DE EMPRÉSTIMOS - SISTEMA DE BIBLIOTECAS DA UFRN ===")
    
    # Verificar arquivos
    if not verificar_arquivos():
        return
    
    # 1. Carregar dados
    emprestimos, acervo = carregar_dados()
    if emprestimos is None or acervo is None:
        return
    
    # 2. Pré-processamento
    emprestimos = preprocessar_emprestimos(emprestimos)
    acervo = preprocessar_acervo(acervo)
    
    # 3. Mesclar dados
    dados_completos = mesclar_dados(emprestimos, acervo)
    
    # 4. Análises e visualizações
    analisar_tendencia_anual(dados_completos)
    analisar_bibliotecas(dados_completos)
    analisar_temas(dados_completos)
    
    # 5. Relatório
    gerar_relatorio(dados_completos)
    
    print("\n=== ANÁLISE CONCLUÍDA COM SUCESSO ===")
    print("Arquivos gerados:")
    print("- emprestimos_por_ano.png (Tendência anual de empréstimos)")
    print("- top_bibliotecas.png (Bibliotecas com mais empréstimos)")
    print("- top_temas.png (Temas mais populares)")
    print("- relatorio_emprestimos.txt (Relatório completo)")

if __name__ == "__main__":
    main()