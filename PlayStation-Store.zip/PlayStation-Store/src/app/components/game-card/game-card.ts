import { Component, Input } from '@angular/core';
import { Game } from '../../models/game.model';

@Component({
  selector: 'app-game-card',
  templateUrl: './game-card.html',
  styleUrls: ['./game-card.scss'],
  standalone: false
})
export class GameCardComponent {
  @Input() game!: Game;
}
