import { RenderMode, ServerRoute } from '@angular/ssr';
import { inject } from '@angular/core';
import { GameService } from './services/game';
import { firstValueFrom } from 'rxjs'; // Import firstValueFrom

export const serverRoutes: ServerRoute[] = [
  {
    path: 'game/:id',
    renderMode: RenderMode.Prerender,
    getPrerenderParams: async () => {
      const gameService = inject(GameService);
      const games = await firstValueFrom(gameService.getGames()); // Await the observable
      return games.map(game => ({ id: game.id.toString() }));
    }
  },
  {
    path: '**',
    renderMode: RenderMode.Prerender
  }
];
