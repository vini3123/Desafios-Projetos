import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GameService } from '../../services/game';
import { Game } from '../../models/game.model';
import { Observable, switchMap } from 'rxjs';

@Component({
  selector: 'app-game-detail',
  templateUrl: './game-detail.html',
  styleUrls: ['./game-detail.scss'],
  standalone: false
})
export class GameDetailComponent implements OnInit {
  game$: Observable<Game | undefined> | undefined;

  constructor(
    private route: ActivatedRoute,
    private gameService: GameService
  ) { }

  ngOnInit(): void {
    this.game$ = this.route.paramMap.pipe(
      switchMap(params => {
        const gameId = Number(params.get('id'));
        return this.gameService.getGame(gameId);
      })
    );
  }
}
