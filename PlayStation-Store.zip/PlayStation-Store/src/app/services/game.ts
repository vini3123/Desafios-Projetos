import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, tap, map } from 'rxjs';
import { Game } from '../models/game.model';

@Injectable({
  providedIn: 'root',
})
export class GameService {
  private apiUrl = '/api/games';
  private _games = new BehaviorSubject<Game[]>([]);
  public readonly games$: Observable<Game[]> = this._games.asObservable();

  constructor(private http: HttpClient) {}

  fetchGames(): Observable<Game[]> {
    return this.http.get<Game[]>(this.apiUrl).pipe(
      tap(games => this._games.next(games))
    );
  }

  getGames(): Observable<Game[]> {
    if (!this._games.getValue().length) {
      return this.fetchGames();
    }
    return this.games$;
  }

  getGame(id: number): Observable<Game | undefined> {
    return this.games$.pipe(
      map(games => games.find(game => game.id === id))
    );
  }
}
