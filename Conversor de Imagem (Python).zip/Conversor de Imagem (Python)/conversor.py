from PIL import Image #type: ignore
import os
import argparse

def converter_imagem(caminho_entrada, caminho_saida, formato_saida, qualidade=75):
    """
    Converte uma imagem para outro formato
    
    Notas:
    - Formatos JPEG não suportam transparência (canal alfa)
    - Para formatos com compressão, a qualidade padrão é 75
    - O script mantém o perfil de cor original, mas converte para RGB quando necessário
    """
    try:
        # Abre a imagem
        with Image.open(caminho_entrada) as img:
            # Converte para RGB se necessário (para formatos que não suportam transparência)
            if formato_saida.upper() in ['JPEG', 'JPG']:
                print("Nota: Convertendo para RGB (JPEG não suporta transparência)")
                img = img.convert('RGB')
            
            # Salva no novo formato com opções específicas
            opcoes_salvamento = {}
            
            # Configura qualidade para formatos com compressão
            if formato_saida.upper() in ['JPEG', 'JPG', 'WEBP']:
                opcoes_salvamento['quality'] = qualidade
                print(f"Nota: Usando qualidade {qualidade} (padrão é 75)")
            
            # Configura otimização para PNG
            if formato_saida.upper() == 'PNG':
                opcoes_salvamento['optimize'] = True
            
            # Salva a imagem
            img.save(caminho_saida, formato_saida.upper(), **opcoes_salvamento)
            print(f"✓ Conversão bem-sucedida: {caminho_entrada} -> {caminho_saida}")
            
    except Exception as e:
        print(f"✗ Erro ao converter {caminho_entrada}: {str(e)}")

def main():
    parser = argparse.ArgumentParser(
        description='Conversor de Imagens - Suporta JPEG, PNG, BMP, WEBP, etc.',
        epilog='''
Notas importantes:
• Formatos JPEG não suportam transparência (canal alfa)
• Para formatos com compressão, a qualidade padrão é 75
• O script mantém o perfil de cor original, mas converte para RGB quando necessário
        '''
    )
    
    parser.add_argument('entrada', help='Caminho da imagem ou diretório de entrada')
    parser.add_argument('-f', '--formato', required=True, 
                       choices=['JPEG', 'PNG', 'BMP', 'WEBP', 'TIFF', 'GIF'],
                       help='Formato de saída')
    parser.add_argument('-o', '--output', 
                       help='Caminho de saída (arquivo ou diretório)')
    parser.add_argument('-q', '--qualidade', type=int, default=75,
                       choices=range(1, 101),
                       metavar='[1-100]',
                       help='Qualidade da compressão (1-100, padrão: 75)')
    parser.add_argument('--info', action='store_true',
                       help='Mostra informações sobre a conversão')
    
    args = parser.parse_args()
    
    # Mostra informações se solicitado
    if args.info:
        print("\n" + "="*50)
        print("INFORMAÇÕES SOBRE A CONVERSÃO")
        print("="*50)
        print(f"• Formato de destino: {args.formato}")
        print(f"• Qualidade: {args.qualidade}")
        if args.formato.upper() in ['JPEG', 'JPG']:
            print("• AVISO: JPEG não suporta transparência (imagens serão convertidas para RGB)")
        if args.formato.upper() in ['JPEG', 'JPG', 'WEBP']:
            print(f"• Nota: Qualidade de compressão definida para {args.qualidade}")
        print("="*50 + "\n")
    
    # Verifica se é arquivo único ou diretório
    if os.path.isfile(args.entrada):
        arquivos = [args.entrada]
        diretorio_saida = args.output or os.path.dirname(args.entrada)
    elif os.path.isdir(args.entrada):
        arquivos = [os.path.join(args.entrada, f) for f in os.listdir(args.entrada) 
                   if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.webp', '.tiff', '.tif', '.gif'))]
        diretorio_saida = args.output or args.entrada
    else:
        print("Erro: Caminho de entrada inválido!")
        return

    # Cria diretório de saída se não existir
    if not os.path.exists(diretorio_saida):
        os.makedirs(diretorio_saida)

    # Processa cada arquivo
    for caminho_entrada in arquivos:
        if os.path.isfile(caminho_entrada) and caminho_entrada.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.webp', '.tiff', '.tif', '.gif')):
            # Define nome de saída
            nome_arquivo = os.path.splitext(os.path.basename(caminho_entrada))[0]
            extensao = f".{args.formato.lower()}"
            
            if os.path.isdir(args.entrada):
                caminho_saida = os.path.join(diretorio_saida, nome_arquivo + extensao)
            else:
                if args.output and not args.output.endswith(extensao):
                    caminho_saida = args.output + extensao
                else:
                    caminho_saida = args.output or nome_arquivo + extensao

            # Mostra informações da imagem original
            if args.info:
                try:
                    with Image.open(caminho_entrada) as img_info:
                        print(f"\nInformações de {os.path.basename(caminho_entrada)}:")
                        print(f"  - Formato: {img_info.format}")
                        print(f"  - Modo: {img_info.mode}")
                        print(f"  - Tamanho: {img_info.size}")
                        if hasattr(img_info, 'filename'):
                            print(f"  - Arquivo: {img_info.filename}")
                except Exception as e:
                    print(f"  - Erro ao ler informações: {e}")

            converter_imagem(caminho_entrada, caminho_saida, args.formato, args.qualidade)

    print(f"\nConversão concluída! Arquivos processados: {len(arquivos)}")

if __name__ == "__main__":
    main()