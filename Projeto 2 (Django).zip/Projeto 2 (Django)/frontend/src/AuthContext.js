import React, { createContext, useState, useEffect } from 'react';
import { login, logout, signup } from './services/AuthService';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Verificar autenticação ao carregar
        const checkAuth = async () => {
            try {
                const response = await fetch('/api/check-auth/');
                if (response.ok) {
                    const data = await response.json();
                    setUser(data.user);
                }
            } catch (error) {
                console.error('Auth check failed:', error);
            } finally {
                setLoading(false);
            }
        };
        checkAuth();
    }, []);

    const handleLogin = async (username, password) => {
        try {
            await login(username, password);
            setUser({ username });
            return true;
        } catch (error) {
            console.error('Login failed:', error);
            return false;
        }
    };

    const handleLogout = async () => {
        try {
            await logout();
            setUser(null);
        } catch (error) {
            console.error('Logout failed:', error);
        }
    };

    const handleSignup = async (username, password, email) => {
        try {
            await signup(username, password, email);
            setUser({ username });
            return true;
        } catch (error) {
            console.error('Signup failed:', error);
            return false;
        }
    };

    return (
        <AuthContext.Provider value={{
            user,
            loading,
            login: handleLogin,
            logout: handleLogout,
            signup: handleSignup
        }}>
            {children}
        </AuthContext.Provider>
    );
};