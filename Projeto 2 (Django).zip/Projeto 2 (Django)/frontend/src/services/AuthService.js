import axios from 'axios';

const API_URL = 'http://localhost:8000';

export const login = (username, password) => {
    return axios.post(`${API_URL}/login/`, {
        username,
        password
    }, {
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        withCredentials: true
    });
};

export const logout = () => {
    return axios.post(`${API_URL}/logout/`, {}, {
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        withCredentials: true
    });
};

export const signup = (username, password, email) => {
    return axios.post(`${API_URL}/signup/`, {
        username,
        password,
        email
    }, {
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        withCredentials: true
    });
};

// Helper function to get CSRF token
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}