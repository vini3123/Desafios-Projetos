import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { AuthProvider } from './AuthContext';
import AuthButtons from './components/AuthButtons';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import HomePage from './pages/HomePage';

function App() {
    return (
        <AuthProvider>
            <Router>
                <div className="App">
                    <header>
                        <AuthButtons />
                    </header>
                    
                    <main>
                        <Switch>
                            <Route exact path="/" component={HomePage} />
                            <Route path="/login" component={LoginPage} />
                            <Route path="/signup" component={SignupPage} />
                        </Switch>
                    </main>
                </div>
            </Router>
        </AuthProvider>
    );
}

export default App;