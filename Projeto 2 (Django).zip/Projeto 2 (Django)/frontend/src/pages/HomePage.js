import React, { useContext } from 'react';
import { AuthContext } from '../AuthContext';
import { Typography, Container } from '@material-ui/core';

const HomePage = () => {
    const { user } = useContext(AuthContext);

    return (
        <Container maxWidth="md">
            <Typography variant="h3" gutterBottom>
                Welcome {user ? user.username : 'Guest'}
            </Typography>
            <Typography variant="body1">
                {user ? 'You are logged in!' : 'Please log in or sign up.'}
            </Typography>
        </Container>
    );
};

export default HomePage;