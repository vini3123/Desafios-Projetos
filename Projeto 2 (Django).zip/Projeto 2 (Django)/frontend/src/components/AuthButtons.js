import React, { useContext } from 'react';
import { AuthContext } from '../AuthContext';
import Button from '@material-ui/core/Button';

const AuthButtons = () => {
    const { user, logout } = useContext(AuthContext);

    if (user) {
        return (
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span>Hello, {user.username}!</span>
                <Button 
                    variant="contained" 
                    color="secondary" 
                    onClick={logout}
                >
                    Logout
                </Button>
            </div>
        );
    }

    return (
        <div style={{ display: 'flex', gap: '10px' }}>
            <Button 
                variant="contained" 
                color="primary" 
                href="/login"
            >
                Login
            </Button>
            <Button 
                variant="outlined" 
                color="primary" 
                href="/signup"
            >
                Sign Up
            </Button>
        </div>
    );
};

export default AuthButtons;