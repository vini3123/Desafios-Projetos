import pandas as pd

# Criando o DataFrame corrigido (sem zeros à esquerda)
data = {
    'localizacao': [720, 28, 150, 350, 550, 750, 850, 950],
    'registro_sistema': [12345, 67890, 54321, 98765, 13579, 24680, 86420, 97531],
    'matricula_ou_siape': [1234567, 7654321, 9876543, 3456789, 5678901, 9012345, 2345678, 6789012],
    'titulo': ['Arquitetura Moderna', 'Introdução à Ciência', 'Filosofia Contemporânea', 
               'Sociologia Urbana', 'Física Quântica', 'Pintura a Óleo', 
               'Gramática Avançada', 'História Antiga']
}

df = pd.DataFrame(data)

# 1. Excluir a coluna 'registro_sistema' que não faz sentido para a análise
# CORREÇÃO: O nome da coluna estava escrito errado no drop()
df = df.drop(columns=['registro_sistema'])

# 2. Transformar a coluna 'matricula_ou_siape' para formato string
df['matricula_ou_siape'] = df['matricula_ou_siape'].astype(str)

# 3. Criar uma nova coluna com a classe geral baseada na localização CDU
def classificar_cdu(localizacao):
    localizacao = int(localizacao)
    if 0 <= localizacao <= 99:
        return "Generalidades. Ciência e conhecimento."
    elif 100 <= localizacao <= 199:
        return "Filosofia e psicologia."
    elif 200 <= localizacao <= 299:
        return "Religião."
    elif 300 <= localizacao <= 399:
        return "Ciências sociais."
    elif 400 <= localizacao <= 499:
        return "Classe vaga. Provisoriamente não ocupada."
    elif 500 <= localizacao <= 599:
        return "Matemática e ciências naturais."
    elif 600 <= localizacao <= 699:
        return "Ciências aplicadas."
    elif 700 <= localizacao <= 799:
        return "Belas artes."
    elif 800 <= localizacao <= 899:
        return "Linguagem. Língua. Linguística."
    elif 900 <= localizacao <= 999:
        return "Geografia. Biografia. História."
    else:
        return "Classificação desconhecida"

# Aplicar a função para criar a nova coluna
df['classe_CDU'] = df['localizacao'].apply(classificar_cdu)

# Mostrar o DataFrame resultante
print(df)