document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const userForm = document.getElementById('user-form');
    const initialForm = document.getElementById('initial-form');
    const resultContainer = document.getElementById('result-container');
    const feedbackQuestion = document.getElementById('feedback-question');
    const feedbackResult = document.getElementById('feedback-result');
    
    // Elementos de resultado
    const resultName = document.getElementById('result-name');
    const resultAge = document.getElementById('result-age');
    const resultLanguage = document.getElementById('result-language');
    const feedbackLanguage = document.getElementById('feedback-language');
    const feedbackText = document.getElementById('feedback-text');
    
    // Botões
    const btnYes = document.getElementById('btn-yes');
    const btnNo = document.getElementById('btn-no');
    const btnRestart = document.getElementById('btn-restart');
    
    // Manipulador do formulário inicial
    userForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Obter valores do formulário
        const name = document.getElementById('name').value;
        const age = document.getElementById('age').value;
        const language = document.getElementById('language').value;
        
        // Atualizar a exibição com os dados do usuário
        resultName.textContent = name;
        resultAge.textContent = age;
        resultLanguage.textContent = language;
        feedbackLanguage.textContent = language;
        
        // Mostrar resultados e esconder o formulário inicial
        initialForm.classList.add('hidden');
        resultContainer.classList.remove('hidden');
        feedbackQuestion.classList.remove('hidden');
        feedbackResult.classList.add('hidden');
    });
    
    // Manipuladores dos botões de feedback
    btnYes.addEventListener('click', function() {
        showFeedback(true);
    });
    
    btnNo.addEventListener('click', function() {
        showFeedback(false);
    });
    
    // Função para mostrar o feedback
    function showFeedback(liked) {
        feedbackQuestion.classList.add('hidden');
        feedbackResult.classList.remove('hidden');
        
        if (liked) {
            feedbackText.textContent = "Muito bom! Continue estudando e você terá muito sucesso.";
        } else {
            feedbackText.textContent = "Ahh que pena... Já tentou aprender outras linguagens?";
        }
    }
    
    // Manipulador do botão de recomeçar
    btnRestart.addEventListener('click', function() {
        // Limpar formulário
        userForm.reset();
        
        // Mostrar formulário inicial e esconder resultados
        resultContainer.classList.add('hidden');
        initialForm.classList.remove('hidden');
    });
});