// Funções das operações matemáticas
function somar(a, b) {
    return a + b;
}

function subtrair(a, b) {
    return a - b;
}

function multiplicar(a, b) {
    return a * b;
}

function dividir(a, b) {
    if (b === 0) {
        return "Erro: divisão por zero!";
    }
    return a / b;
}

// Elementos da interface
const display = document.getElementById('display');
const num1Input = document.getElementById('num1');
const num2Input = document.getElementById('num2');
const operationSelect = document.getElementById('operation');
const calculateBtn = document.getElementById('calculate');
const clearBtn = document.getElementById('clear');
const exitBtn = document.getElementById('exit');
const resultDiv = document.getElementById('result');

// Atualizar display quando os números mudam
num1Input.addEventListener('input', updateDisplay);
num2Input.addEventListener('input', updateDisplay);

function updateDisplay() {
    const num1 = num1Input.value || '0';
    const num2 = num2Input.value || '0';
    const operation = operationSelect.selectedOptions[0].text.split(' ')[0];
    
    display.textContent = `${num1} ${getOperationSymbol()} ${num2}`;
}

function getOperationSymbol() {
    switch(operationSelect.value) {
        case '1': return '+';
        case '2': return '-';
        case '3': return '×';
        case '4': return '÷';
        default: return '';
    }
}

// Calcular quando o botão é clicado
calculateBtn.addEventListener('click', () => {
    const num1 = parseFloat(num1Input.value);
    const num2 = parseFloat(num2Input.value);
    const operation = operationSelect.value;
    
    if (isNaN(num1)) {
        resultDiv.textContent = "Digite o primeiro número!";
        return;
    }
    
    if (isNaN(num2)) {
        resultDiv.textContent = "Digite o segundo número!";
        return;
    }
    
    let resultado;
    let operacaoNome;
    
    switch(operation) {
        case '1':
            resultado = somar(num1, num2);
            operacaoNome = 'soma';
            break;
        case '2':
            resultado = subtrair(num1, num2);
            operacaoNome = 'subtração';
            break;
        case '3':
            resultado = multiplicar(num1, num2);
            operacaoNome = 'multiplicação';
            break;
        case '4':
            resultado = dividir(num1, num2);
            operacaoNome = 'divisão';
            break;
        default:
            resultado = "Operação inválida";
    }
    
    if (typeof resultado === 'number') {
        resultado = resultado.toFixed(2).replace(/\.?0+$/, '');
    }
    
    resultDiv.textContent = `Resultado da ${operacaoNome}: ${resultado}`;
    resultDiv.style.color = '#2c3e50';
});

// Limpar campos
clearBtn.addEventListener('click', () => {
    num1Input.value = '';
    num2Input.value = '';
    resultDiv.textContent = '';
    display.textContent = '0';
});

// Sair da calculadora
exitBtn.addEventListener('click', () => {
    resultDiv.textContent = 'Até a próxima!';
    resultDiv.style.color = '#e74c3c';
    
    setTimeout(() => {
        alert('Obrigado por usar a calculadora! Até a próxima!');
        // Em um ambiente real, você poderia fechar a janela ou redirecionar
        // window.close(); ou window.location.href = '...';
    }, 500);
});

// Inicializar display
updateDisplay();