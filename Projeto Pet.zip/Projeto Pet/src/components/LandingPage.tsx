import React from 'react';
import './LandingPage.css';
import { useNavigate } from 'react-router-dom';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="landing-container">
      <nav className="navbar">
        <div className="logo">PetCare</div>
        <div className="nav-links">
          <a href="#features">Funcionalidades</a>
          <a href="#how-it-works">Como funciona</a>
          <button className="btn-secondary" onClick={() => navigate('/login')}>Entrar</button>
        </div>
      </nav>

      <header className="hero">
        <div className="hero-content">
          <h1>Encontre o melhor cuidado para o seu pet</h1>
          <p>Conectamos você a cuidadores apaixonados e confiáveis em sua região.</p>
          <div className="hero-btns">
            <button className="btn-primary" onClick={() => navigate('/login')}>Encontrar um cuidador</button>
            <button className="btn-outline" onClick={() => navigate('/login')}>Quero ser cuidador</button>
          </div>
        </div>
        <div className="hero-image">
          <img src="https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&q=80&w=1469" alt="Happy pet" />
        </div>
      </header>

      <section id="features" className="features">
        <h2>Por que escolher o PetCare?</h2>
        <div className="feature-grid">
          <div className="feature-card">
            <div className="icon">🛡️</div>
            <h3>Segurança Garantida</h3>
            <p>Todos os cuidadores passam por um rigoroso processo de verificação.</p>
          </div>
          <div className="feature-card">
            <div className="icon">📍</div>
            <h3>Geolocalização</h3>
            <p>Encontre cuidadores pertinho de você através do nosso mapa interativo.</p>
          </div>
          <div className="feature-card">
            <div className="icon">📸</div>
            <h3>Fotos Diárias</h3>
            <p>Receba fotos e atualizações do seu pet durante todo o período de estadia.</p>
          </div>
          <div className="feature-card">
            <div className="icon">💬</div>
            <h3>Chat Interno</h3>
            <p>Comunicação direta e rápida com o cuidador do seu melhor amigo.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
