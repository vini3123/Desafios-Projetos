import React, { useState } from 'react';
import './Login.css';
import { useNavigate } from 'react-router-dom';

const Login: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Em um cenário real, aqui teria a lógica de autenticação
    navigate('/search');
  };

  return (
    <div className="login-container">
      <div className="login-image-section">
        <div className="image-overlay">
          <div className="hero-text">
            <h1>PetCare</h1>
            <p>Conectando quem ama com quem cuida.</p>
          </div>
        </div>
      </div>
      <div className="login-form-section">
        <div className="form-card">
          <div className="logo-mobile">PetCare</div>
          <h2>{isLogin ? 'Bem-vindo de volta!' : 'Crie sua conta'}</h2>
          <p className="subtitle">{isLogin ? 'Entre com seus dados para continuar' : 'Junte-se à nossa comunidade de amantes de pets'}</p>
          
          <form onSubmit={handleSubmit}>
            {!isLogin && (
              <div className="input-group">
                <label>Nome completo</label>
                <input type="text" placeholder="Seu nome" required />
              </div>
            )}
            <div className="input-group">
              <label>E-mail</label>
              <input type="email" placeholder="seu@email.com" required />
            </div>
            <div className="input-group">
              <label>Senha</label>
              <input type="password" placeholder="senha" required />
            </div>
            
            {isLogin && (
              <div className="forgot-password">
                <a href="#">Esqueceu a senha?</a>
              </div>
            )}
            
            <button type="submit" className="btn-primary">
              {isLogin ? 'Entrar' : 'Cadastrar'}
            </button>
          </form>
          
          <div className="social-login">
            <div className="divider">
              <span>ou continue com</span>
            </div>
            <div className="social-buttons">
              <button className="social-btn">G</button>
              <button className="social-btn">f</button>
              <button className="social-btn">I</button>
            </div>
          </div>
          
          <p className="switch-auth">
            {isLogin ? 'Não tem uma conta?' : 'Já tem uma conta?'}
            <button onClick={() => setIsLogin(!isLogin)}>
              {isLogin ? 'Cadastre-se' : 'Faça login'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
