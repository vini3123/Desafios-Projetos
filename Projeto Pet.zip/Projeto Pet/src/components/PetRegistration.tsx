import React from 'react';
import './PetRegistration.css';

const PetRegistration: React.FC = () => {
  return (
    <div className="pet-reg-container">
      <div className="pet-reg-card">
        <h2>Cadastre seu Pet</h2>
        <p>Conte-nos mais sobre seu melhor amigo!</p>
        
        <form className="pet-form">
          <div className="form-row">
            <div className="form-group">
              <label>Nome do Pet</label>
              <input type="text" placeholder="Rex, Luna..." />
            </div>
            <div className="form-group">
              <label>Tipo</label>
              <select>
                <option>Cachorro</option>
                <option>Gato</option>
                <option>Pássaro</option>
                <option>Outro</option>
              </select>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Raça</label>
              <input type="text" placeholder="Ex: Golden Retriever" />
            </div>
            <div className="form-group">
              <label>Idade (anos)</label>
              <input type="number" placeholder="Ex: 3" />
            </div>
          </div>

          <div className="form-group">
            <label>Cuidados Especiais ou Remédios</label>
            <textarea placeholder="Ex: Precisa de colírio às 14h, não gosta de outros cães..."></textarea>
          </div>

          <div className="form-group">
            <label>Foto do Pet</label>
            <div className="upload-box">
              <span>Clique para carregar foto</span>
            </div>
          </div>

          <button type="submit" className="btn-primary">Salvar Cadastro</button>
        </form>
      </div>
    </div>
  );
};

export default PetRegistration;
