import React, { useState } from 'react';
import './SitterSearch.css';

interface Sitter {
  id: number;
  name: string;
  rating: number;
  price: number;
  location: string;
  image: string;
  description: string;
}

const mockSitters: Sitter[] = [
  {
    id: 1,
    name: "Ana Oliveira",
    rating: 4.9,
    price: 60,
    location: "São Paulo, SP (2km)",
    image: "https://images.unsplash.com/photo-1551730459-92db2a308d6a?auto=format&fit=crop&q=80&w=300&h=300",
    description: "Amante de animais com 5 anos de experiência cuidando de cães de todos os tamanhos."
  },
  {
    id: 2,
    name: "Carlos Santos",
    rating: 4.7,
    price: 45,
    location: "São Paulo, SP (5km)",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=300&h=300",
    description: "Especialista em gatos e animais de pequeno porte. Espaço amplo e seguro."
  },
  {
    id: 3,
    name: "Juliana Mendes",
    rating: 5.0,
    price: 80,
    location: "São Paulo, SP (1.5km)",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=300&h=300",
    description: "Médica veterinária oferecendo serviços de hospedagem com cuidados médicos se necessário."
  }
];

const SitterSearch: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");

  return (
    <div className="search-container">
      <header className="search-header">
        <h2>Encontre o cuidador perfeito</h2>
        <div className="search-bar">
          <input 
            type="text" 
            placeholder="Sua localização (ex: São Paulo, SP)" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button className="btn-primary">Buscar</button>
        </div>
      </header>

      <div className="results-section">
        <aside className="filters">
          <h3>Filtros</h3>
          <div className="filter-group">
            <label>Preço por noite</label>
            <input type="range" min="20" max="200" />
          </div>
          <div className="filter-group">
            <label>Tipo de animal</label>
            <div className="checkboxes">
              <label><input type="checkbox" defaultChecked /> Cães</label>
              <label><input type="checkbox" defaultChecked /> Gatos</label>
              <label><input type="checkbox" /> Outros</label>
            </div>
          </div>
        </aside>

        <main className="sitter-list">
          {mockSitters.map(sitter => (
            <div key={sitter.id} className="sitter-card">
              <div className="sitter-image" style={{ backgroundImage: `url(${sitter.image})` }}></div>
              <div className="sitter-info">
                <div className="sitter-main">
                  <h3>{sitter.name}</h3>
                  <span className="rating">⭐ {sitter.rating}</span>
                </div>
                <p className="location">📍 {sitter.location}</p>
                <p className="description">{sitter.description}</p>
                <div className="sitter-footer">
                  <span className="price">R$ {sitter.price} / noite</span>
                  <button className="btn-secondary">Ver Perfil</button>
                </div>
              </div>
            </div>
          ))}
        </main>
      </div>
    </div>
  );
};

export default SitterSearch;
