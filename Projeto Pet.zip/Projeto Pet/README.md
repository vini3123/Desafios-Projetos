# 🐾 PetCare - Conectando quem ama com quem cuida

O **PetCare** é uma plataforma moderna projetada para conectar donos de pets a cuidadores apaixonados e confiáveis. Seja para uma viagem de última hora ou cuidados diários, o PetCare garante que seu melhor amigo receba todo o carinho e segurança que merece em um ambiente caseiro e confortável.

Este projeto foi desenvolvido com base nos requisitos detalhados na planilha `Ideia-Pet.xlsx`.

---

## ✨ Funcionalidades Principais

- **🚀 Landing Page Impressionante**: Uma porta de entrada profissional destacando os benefícios da plataforma.
- **🔐 Login & Cadastro Moderno**: Interface de autenticação com design focado em UX, incluindo suporte a login social.
- **🔍 Busca de Cuidadores por Geolocalização**: Encontre cuidadores próximos a você com filtros de preço, avaliação e tipo de pet.
- **🐶 Cadastro Detalhado de Pets**: Registro completo dos animais, incluindo campos específicos para cuidados especiais e medicamentos.
- **📱 Design Responsivo**: Experiência otimizada para dispositivos móveis e desktops.
- **🖼️ Visual de Impacto**: Uso de imagens de alta qualidade e interface limpa com *glassmorphism*.

---

## 🛠️ Tecnologias Utilizadas

- **Frontend**: [React](https://reactjs.org/) com [TypeScript](https://www.typescriptlang.org/)
- **Build Tool**: [Vite](https://vitejs.dev/)
- **Roteamento**: [React Router Dom v6](https://reactrouter.com/)
- **Estilização**: CSS Moderno (Vanilla CSS com Variáveis)
- **Icons & Imagens**: [Unsplash](https://unsplash.com/)

---

## 🚀 Como Executar o Projeto

### Pré-requisitos

Certifique-se de ter o [Node.js](https://nodejs.org/) (versão 18 ou superior) instalado em sua máquina.

### Passo a Passo

1. **Instale as dependências:**
   ```bash
   npm install
   ```

2. **Inicie o servidor de desenvolvimento:**
   ```bash
   npm run dev
   ```

3. **Acesse no navegador:**
   O projeto estará disponível em `http://localhost:5173`.

---

## 📁 Estrutura de Pastas

```text
src/
├── components/          # Componentes principais (Login, LandingPage, etc.)
│   ├── LandingPage.tsx
│   ├── Login.tsx
│   ├── PetRegistration.tsx
│   └── SitterSearch.tsx
├── App.tsx              # Configuração de rotas
├── main.tsx             # Ponto de entrada do React
└── index.css            # Estilos globais
```

---

## 📝 Base de Requisitos

O desenvolvimento seguiu a "Ficha Técnica" e a "Lista de Funcionalidades" do arquivo `Ideia-Pet.xlsx` presente na raiz do projeto, priorizando as funcionalidades classificadas como **Obrigatórias**.

---

Desenvolvido com ❤️ para todos os amantes de pets.
