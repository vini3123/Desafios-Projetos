import { getPosterUrl } from './api.js';
import { isFavorite, removeFavorite, saveFavorite } from './storage.js';

export function renderMovies(movies, containerId, showFavoriteButton = true) {
  const container = document.getElementById(containerId);
  container.innerHTML = '';

  if (!movies || movies.length === 0) {
    container.innerHTML = '<p>Nenhum filme encontrado.</p>';
    return;
  }

  movies.forEach(movie => {
    const movieCard = document.createElement('div');
    movieCard.className = 'movie-card';
    
    const isFav = isFavorite(movie.id);
    
    movieCard.innerHTML = `
      <img src="${getPosterUrl(movie.poster_path)}" alt="${movie.title}" class="movie-poster">
      <div class="movie-info">
        <div class="movie-title">${movie.title}</div>
        <div class="movie-year">${movie.release_date ? movie.release_date.substring(0, 4) : 'N/A'}</div>
        ${showFavoriteButton ? `
          <button class="favorite-btn ${isFav ? 'added' : ''}" data-id="${movie.id}">
            ${isFav ? 'Remover dos Favoritos' : 'Adicionar aos Favoritos'}
          </button>
        ` : ''}
      </div>
    `;
    
    container.appendChild(movieCard);
  });

  if (showFavoriteButton) {
    setupFavoriteButtons();
  }
}

function setupFavoriteButtons() {
  document.querySelectorAll('.favorite-btn').forEach(button => {
    button.addEventListener('click', (e) => {
      const movieId = parseInt(e.target.dataset.id);
      
      if (isFavorite(movieId)) {
        removeFavorite(movieId);
        e.target.textContent = 'Adicionar aos Favoritos';
        e.target.classList.remove('added');
      } else {
        const movieCard = e.target.closest('.movie-card');
        const movie = {
          id: movieId,
          title: movieCard.querySelector('.movie-title').textContent,
          release_date: movieCard.querySelector('.movie-year').textContent,
          poster_path: movieCard.querySelector('img').src.split('/').pop()
        };
        saveFavorite(movie);
        e.target.textContent = 'Remover dos Favoritos';
        e.target.classList.add('added');
      }
      
      // Atualiza a lista de favoritos
      renderFavorites();
    });
  });
}

export function renderFavorites() {
  const favorites = getFavorites();
  renderMovies(favorites, 'favorites-container', false);
}