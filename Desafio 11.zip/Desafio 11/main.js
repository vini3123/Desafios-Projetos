import { searchMovies } from 'api.js';
import { renderMovies, renderFavorites } from 'ui.js';

document.addEventListener('DOMContentLoaded', () => {
  // Carrega favoritos ao iniciar
  renderFavorites();

  // Configura o botão de busca
  document.getElementById('search-btn').addEventListener('click', performSearch);
  document.getElementById('search-input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') performSearch();
  });
});

async function performSearch() {
  const query = document.getElementById('search-input').value.trim();
  
  if (!query) {
    alert('Por favor, digite um termo para buscar');
    return;
  }

  try {
    const movies = await searchMovies(query);
    renderMovies(movies, 'results-container');
  } catch (error) {
    document.getElementById('results-container').innerHTML = `
      <p class="error-message">Erro ao buscar filmes. Tente novamente mais tarde.</p>
    `;
  }
}