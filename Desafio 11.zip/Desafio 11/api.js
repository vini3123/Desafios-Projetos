const API_KEY = 'f139b13b2e8b06bd102618d0231605df'; // Substitua por uma API key real
const BASE_URL = 'https://api.themoviedb.org/3';

export async function searchMovies(query) {
  try {
    const response = await fetch(
      `${BASE_URL}/search/movie?api_key=${API_KEY}&language=pt-BR&query=${query}`
    );
    
    if (!response.ok) {
      throw new Error('Erro ao buscar filmes');
    }
    
    const data = await response.json();
    return data.results;
  } catch (error) {
    console.error('Erro na API:', error);
    throw error;
  }
}

export async function getMovieDetails(movieId) {
  try {
    const response = await fetch(
      `${BASE_URL}/movie/${movieId}?api_key=${API_KEY}&language=pt-BR`
    );
    
    if (!response.ok) {
      throw new Error('Erro ao buscar detalhes do filme');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Erro na API:', error);
    throw error;
  }
}

export function getPosterUrl(posterPath, size = 'w500') {
  return posterPath 
    ? `https://image.tmdb.org/t/p/${size}${posterPath}`
    : 'https://via.placeholder.com/500x750?text=Poster+Não+Disponível';
}