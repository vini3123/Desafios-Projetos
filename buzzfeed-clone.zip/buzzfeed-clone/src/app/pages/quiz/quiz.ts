import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { quizzes } from '../../data/quizzes';

@Component({
  selector: 'app-quiz',
  standalone: false,
  templateUrl: './quiz.html',
  styleUrl: './quiz.css',
})
export class Quiz implements OnInit {
  quiz: any;
  questionIndex = 0;
  selectedAnswers: string[] = [];
  result = '';

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      const quizId = Number(params.get('id'));
      this.quiz = quizzes.find((q) => q.id === quizId);
    });
  }

  selectAnswer(alias: string): void {
    this.selectedAnswers.push(alias);
    if (this.questionIndex < this.quiz.questions.length - 1) {
      this.questionIndex++;
    } else {
      this.calculateResult();
    }
  }

  calculateResult(): void {
    const mostFrequentAnswer = this.selectedAnswers.sort((a,b) =>
          this.selectedAnswers.filter(v => v===a).length
        - this.selectedAnswers.filter(v => v===b).length
    ).pop();

    if(mostFrequentAnswer) {
      this.result = this.quiz.results[mostFrequentAnswer];
    }
  }
}
