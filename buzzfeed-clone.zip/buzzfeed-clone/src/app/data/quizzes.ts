export const quizzes = [
  {
    id: 1,
    title: "Which 'Friends' Character Are You?",
    image: "https://placehold.co/600x400?text=Friends",
    questions: [
      {
        question: "What's your favorite food?",
        options: [
          { text: "Pizza", alias: "A" },
          { text: "Salad", alias: "B" },
          { text: "Tacos", alias: "C" },
          { text: "Sushi", alias: "D" },
        ],
      },
      {
        question: "What's your ideal Friday night?",
        options: [
          { text: "Going out with friends", alias: "A" },
          { text: "Staying in and watching a movie", alias: "B" },
          { text: "Trying a new restaurant", alias: "C" },
          { text: "Reading a book", alias: "D" },
        ],
      },
    ],
    results: {
      A: "You are Joey! You love food and having fun.",
      B: "You are Monica! You are organized and love to host.",
      C: "You are Rachel! You are fashionable and a great friend.",
      D: "You are Ross! You are smart and a little bit quirky.",
    },
  },
  {
    id: 2,
    title: "What's Your Hogwarts House?",
    image: "https://placehold.co/600x400?text=Hogwarts",
    questions: [
      {
        question: "What is your best quality?",
        options: [
          { text: "Bravery", alias: "A" },
          { text: "Loyalty", alias: "B" },
          { text: "Wisdom", alias: "C" },
          { text: "Ambition", alias: "D" },
        ],
      },
      {
        question: "Which animal do you like the most?",
        options: [
          { text: "Lion", alias: "A" },
          { text: "Badger", alias: "B" },
          { text: "Eagle", alias: "C" },
          { text: "Snake", alias: "D" },
        ],
      },
    ],
    results: {
      A: "You are from Gryffindor!",
      B: "You are from Hufflepuff!",
      C: "You are from Ravenclaw!",
      D: "You are from Slytherin!",
    },
  },
];
