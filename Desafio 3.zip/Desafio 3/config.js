// config.js
export const API_KEY = 'f139b13b2e8b06bd102618d0231605df';