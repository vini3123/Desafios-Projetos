// app.js
import { API_KEY } from './config.js';

async function getPopularMovies() {
    const url = `https://api.themoviedb.org/3/movie/popular?api_key=${API_KEY}&language=pt-BR`;
    
    try {
        const response = await fetch(url);
        const data = await response.json();
        return data.results;
    } catch (error) {
        console.error('Erro ao buscar filmes:', error);
        return [];
    }
}

function renderMovies(movies) {
    const filmesContainer = document.getElementById('filmes');
    filmesContainer.innerHTML = '';

    movies.forEach(movie => {
        const filmeDiv = document.createElement('div');
        filmeDiv.className = 'filme';
        
        filmeDiv.innerHTML = `
            <img src="https://image.tmdb.org/t/p/w500${movie.poster_path}" alt="${movie.title}">
            <h2>${movie.title}</h2>
            <p>${movie.overview || 'Descrição não disponível'}</p>
            <p>Nota: ${movie.vote_average.toFixed(1)}</p>
        `;
        
        filmesContainer.appendChild(filmeDiv);
    });
}

async function main() {
    const movies = await getPopularMovies();
    renderMovies(movies);
}

main();