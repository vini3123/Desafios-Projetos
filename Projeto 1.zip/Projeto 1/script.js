document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const currentTimeElement = document.getElementById('current-time');
    const currentMonthYearElement = document.getElementById('current-month-year');
    const calendarElement = document.getElementById('calendar');
    const prevMonthButton = document.getElementById('prev-month');
    const nextMonthButton = document.getElementById('next-month');
    const birthdayInput = document.getElementById('birthday-input');
    
    // Datas importantes
    const importantDates = {
        christmas: getNextChristmas(),
        newYear: getNextNewYear(),
        easter: getNextEaster(),
        birthday: null
    };
    
    // Variáveis de estado
    let currentDate = new Date();
    let currentMonth = currentDate.getMonth();
    let currentYear = currentDate.getFullYear();
    
    // Inicialização
    updateCurrentTime();
    renderCalendar(currentMonth, currentYear);
    updateCountdowns();
    setInterval(updateCurrentTime, 1000);
    
    // Event Listeners
    prevMonthButton.addEventListener('click', () => {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        renderCalendar(currentMonth, currentYear);
    });
    
    nextMonthButton.addEventListener('click', () => {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        renderCalendar(currentMonth, currentYear);
    });
    
    birthdayInput.addEventListener('change', (e) => {
        const date = new Date(e.target.value);
        if (!isNaN(date.getTime())) {
            importantDates.birthday = date;
            updateCountdowns();
        }
    });
    
    // Funções
    function updateCurrentTime() {
        const now = new Date();
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' 
        };
        currentTimeElement.textContent = now.toLocaleDateString('pt-BR', options);
    }
    
    function renderCalendar(month, year) {
        // Limpa o calendário
        calendarElement.innerHTML = '';
        
        // Define o mês/ano atual no cabeçalho
        const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", 
                           "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
        currentMonthYearElement.textContent = `${monthNames[month]} ${year}`;
        
        // Cria cabeçalhos dos dias da semana
        const dayNames = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
        dayNames.forEach(day => {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day-header';
            dayElement.textContent = day;
            calendarElement.appendChild(dayElement);
        });
        
        // Obtém o primeiro dia do mês e quantos dias tem o mês
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        
        // Obtém o último dia do mês anterior
        const daysInLastMonth = new Date(year, month, 0).getDate();
        
        // Preenche os dias do mês anterior (se necessário)
        for (let i = 0; i < firstDay; i++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day empty';
            calendarElement.appendChild(dayElement);
        }
        
        // Preenche os dias do mês atual
        const today = new Date();
        for (let day = 1; day <= daysInMonth; day++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';
            
            // Verifica se é fim de semana
            const dayOfWeek = new Date(year, month, day).getDay();
            if (dayOfWeek === 0 || dayOfWeek === 6) {
                dayElement.classList.add('weekend');
            }
            
            // Verifica se é hoje
            if (day === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
                dayElement.classList.add('today');
            }
            
            const dayNumberElement = document.createElement('div');
            dayNumberElement.className = 'calendar-day-number';
            dayNumberElement.textContent = day;
            dayElement.appendChild(dayNumberElement);
            
            calendarElement.appendChild(dayElement);
        }
    }
    
    function updateCountdowns() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // Atualiza contagem regressiva para o Natal
        const christmasCard = document.querySelector('#christmas .countdown-days');
        const daysToChristmas = Math.ceil((importantDates.christmas - today) / (1000 * 60 * 60 * 24));
        christmasCard.textContent = daysToChristmas > 0 ? `${daysToChristmas} dias` : "Hoje!";
        
        // Atualiza contagem regressiva para o Ano Novo
        const newYearCard = document.querySelector('#new-year .countdown-days');
        const daysToNewYear = Math.ceil((importantDates.newYear - today) / (1000 * 60 * 60 * 24));
        newYearCard.textContent = daysToNewYear > 0 ? `${daysToNewYear} dias` : "Hoje!";
        
        // Atualiza contagem regressiva para a Páscoa
        const easterCard = document.querySelector('#easter .countdown-days');
        const daysToEaster = Math.ceil((importantDates.easter - today) / (1000 * 60 * 60 * 24));
        easterCard.textContent = daysToEaster > 0 ? `${daysToEaster} dias` : "Hoje!";
        
        // Atualiza a data da Páscoa no card
        const easterDateElement = document.getElementById('easter-date');
        const options = { day: 'numeric', month: 'long' };
        easterDateElement.textContent = importantDates.easter.toLocaleDateString('pt-BR', options);
        
        // Atualiza contagem regressiva para o aniversário (se definido)
        if (importantDates.birthday) {
            const nextBirthday = getNextBirthday(importantDates.birthday);
            const birthdayCard = document.querySelector('#birthday .countdown-days');
            const daysToBirthday = Math.ceil((nextBirthday - today) / (1000 * 60 * 60 * 24));
            
            if (daysToBirthday === 0) {
                birthdayCard.textContent = "Hoje!";
            } else if (daysToBirthday === 365) {
                birthdayCard.textContent = "365 dias (próximo ano)";
            } else {
                birthdayCard.textContent = `${daysToBirthday} dias`;
            }
        }
    }
    
    // Funções auxiliares para calcular datas importantes
    function getNextChristmas() {
        const today = new Date();
        const currentYear = today.getFullYear();
        const christmas = new Date(currentYear, 11, 25);
        
        if (today > christmas) {
            christmas.setFullYear(currentYear + 1);
        }
        
        return christmas;
    }
    
    function getNextNewYear() {
        const today = new Date();
        const currentYear = today.getFullYear();
        const newYear = new Date(currentYear + 1, 0, 1);
        
        return newYear;
    }
    
    function getNextEaster() {
        const today = new Date();
        const year = today.getFullYear();
        
        // Algoritmo de Gauss para calcular a Páscoa
        const a = year % 19;
        const b = Math.floor(year / 100);
        const c = year % 100;
        const d = Math.floor(b / 4);
        const e = b % 4;
        const f = Math.floor((b + 8) / 25);
        const g = Math.floor((b - f + 1) / 3);
        const h = (19 * a + b - d - g + 15) % 30;
        const i = Math.floor(c / 4);
        const k = c % 4;
        const l = (32 + 2 * e + 2 * i - h - k) % 7;
        const m = Math.floor((a + 11 * h + 22 * l) / 451);
        const month = Math.floor((h + l - 7 * m + 114) / 31) - 1;
        const day = ((h + l - 7 * m + 114) % 31) + 1;
        
        const easter = new Date(year, month, day);
        
        if (today > easter) {
            return getNextEasterForYear(year + 1);
        }
        
        return easter;
    }
    
    function getNextEasterForYear(year) {
        // Algoritmo de Gauss para calcular a Páscoa
        const a = year % 19;
        const b = Math.floor(year / 100);
        const c = year % 100;
        const d = Math.floor(b / 4);
        const e = b % 4;
        const f = Math.floor((b + 8) / 25);
        const g = Math.floor((b - f + 1) / 3);
        const h = (19 * a + b - d - g + 15) % 30;
        const i = Math.floor(c / 4);
        const k = c % 4;
        const l = (32 + 2 * e + 2 * i - h - k) % 7;
        const m = Math.floor((a + 11 * h + 22 * l) / 451);
        const month = Math.floor((h + l - 7 * m + 114) / 31) - 1;
        const day = ((h + l - 7 * m + 114) % 31) + 1;
        
        return new Date(year, month, day);
    }
    
    function getNextBirthday(birthdayDate) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const currentYear = today.getFullYear();
        let nextBirthday = new Date(currentYear, birthdayDate.getMonth(), birthdayDate.getDate());
        
        if (today > nextBirthday) {
            nextBirthday.setFullYear(currentYear + 1);
        }
        
        return nextBirthday;
    }
});