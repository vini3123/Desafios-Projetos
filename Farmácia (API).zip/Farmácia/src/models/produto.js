/**
 * Representa a estrutura de um Produto.
 * Este arquivo serve como documentação central da "forma" de um objeto Produto.
 * 
 * @typedef {object} Produto
 * @property {string} id - O ID único do produto (UUID).
 * @property {string} nome - O nome do produto.
 * @property {string} fabricante - O nome do fabricante do produto.
 * @property {number} preco - O preço do produto.
 * @property {number} estoque - A quantidade em estoque.
 * @property {boolean} requerReceita - Indica se o produto requer receita médica.
 */

// Este arquivo não exporta código executável, serve apenas para documentação da estrutura (JSDoc).
