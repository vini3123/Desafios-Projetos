/**
 * Representa a estrutura de um Cliente.
 * 
 * @typedef {object} Cliente
 * @property {string} id - O ID único do cliente (UUID).
 * @property {string} nome - O nome completo do cliente.
 * @property {string} cpf - O CPF do cliente (deve ser único no sistema).
 * @property {string} [endereco] - O endereço do cliente (opcional).
 * @property {string} [telefone] - O telefone de contato do cliente (opcional).
 */

// Este arquivo não exporta código executável, serve apenas para documentação da estrutura (JSDoc).
