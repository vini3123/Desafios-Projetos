/**
 * Representa um item individual dentro de uma Venda.
 * É um "snapshot" do produto no momento da compra.
 * 
 * @typedef {object} ItemVenda
 * @property {string} produtoId - O ID do produto vendido.
 * @property {string} nome - O nome do produto no momento da venda.
 * @property {number} quantidade - A quantidade de unidades vendidas.
 * @property {number} precoUnitario - O preço do produto no momento da venda.
 */

/**
 * Representa a estrutura de uma Venda.
 * 
 * @typedef {object} Venda
 * @property {string} id - O ID único da venda (UUID).
 * @property {string} clienteId - O ID do cliente que realizou a compra.
 * @property {string} clienteNome - O nome do cliente no momento da venda (para referência).
 * @property {string} data - A data da venda no formato ISO 8601.
 * @property {ItemVenda[]} itens - A lista de itens vendidos.
 * @property {number} valorTotal - O valor total da venda.
 */

// Este arquivo não exporta código executável, serve apenas para documentação da estrutura (JSDoc).
