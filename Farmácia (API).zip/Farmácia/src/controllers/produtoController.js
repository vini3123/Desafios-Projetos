const { lerDados, escreverDados } = require('../repositories/farmaciaRepository');
const bodyParser = require('../utils/bodyParser');
const { randomUUID } = require('crypto');

/**
 * @route GET /produtos
 * @description Lista todos os produtos.
 */
async function listarProdutos(req, res) {
    const dados = await lerDados();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(dados.produtos || []));
}

/**
 * @route GET /produtos/:id
 * @description Obtém um produto específico pelo ID.
 */
async function obterProduto(req, res, params) {
    const { id } = params;
    const dados = await lerDados();
    const produto = dados.produtos.find(p => p.id === id);

    if (produto) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(produto));
    } else {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Produto não encontrado' }));
    }
}

/**
 * @route POST /produtos
 * @description Cria um novo produto.
 */
async function criarProduto(req, res) {
    try {
        const body = await bodyParser(req);
        const { nome, fabricante, preco, estoque, requerReceita } = body;

        if (!nome || !fabricante || preco === undefined || estoque === undefined) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Campos nome, fabricante, preco e estoque são obrigatórios' }));
            return;
        }

        const dados = await lerDados();
        const novoProduto = {
            id: randomUUID(),
            nome,
            fabricante,
            preco: parseFloat(preco),
            estoque: parseInt(estoque, 10),
            requerReceita: !!requerReceita, // Converte para booleano
        };

        dados.produtos.push(novoProduto);
        await escreverDados(dados);

        res.writeHead(201, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(novoProduto));
    } catch (error) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: `Erro ao processar requisição: ${error.message}` }));
    }
}

/**
 * @route PUT /produtos/:id
 * @description Atualiza um produto existente.
 */
async function atualizarProduto(req, res, params) {
    try {
        const { id } = params;
        const dados = await lerDados();
        const index = dados.produtos.findIndex(p => p.id === id);

        if (index === -1) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Produto não encontrado' }));
            return;
        }

        const body = await bodyParser(req);
        const produtoOriginal = dados.produtos[index];
        
        const produtoAtualizado = {
            ...produtoOriginal,
            ...body,
            id: produtoOriginal.id, // Garante que o ID não seja alterado
            // Atualiza e converte os tipos se os campos existirem no body
            preco: body.preco !== undefined ? parseFloat(body.preco) : produtoOriginal.preco,
            estoque: body.estoque !== undefined ? parseInt(body.estoque, 10) : produtoOriginal.estoque,
            requerReceita: body.requerReceita !== undefined ? !!body.requerReceita : produtoOriginal.requerReceita,
        };

        dados.produtos[index] = produtoAtualizado;
        await escreverDados(dados);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(produtoAtualizado));
    } catch (error) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: `Erro ao processar requisição: ${error.message}` }));
    }
}

/**
 * @route DELETE /produtos/:id
 * @description Deleta um produto.
 */
async function deletarProduto(req, res, params) {
    const { id } = params;
    const dados = await lerDados();
    const novosProdutos = dados.produtos.filter(p => p.id !== id);

    if (novosProdutos.length === dados.produtos.length) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Produto não encontrado' }));
        return;
    }

    dados.produtos = novosProdutos;
    await escreverDados(dados);

    res.writeHead(204, { 'Content-Type': 'application/json' }); // No Content
    res.end();
}

module.exports = {
    listarProdutos,
    obterProduto,
    criarProduto,
    atualizarProduto,
    deletarProduto,
};