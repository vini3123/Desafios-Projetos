const { lerDados, escreverDados } = require('../repositories/farmaciaRepository');
const bodyParser = require('../utils/bodyParser');
const { randomUUID } = require('crypto');

/**
 * @route GET /clientes
 * @description Lista todos os clientes.
 */
async function listarClientes(req, res) {
    const dados = await lerDados();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(dados.clientes || []));
}

/**
 * @route GET /clientes/:id
 * @description Obtém um cliente específico pelo ID.
 */
async function obterCliente(req, res, params) {
    const { id } = params;
    const dados = await lerDados();
    const cliente = dados.clientes.find(c => c.id === id);

    if (cliente) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(cliente));
    } else {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Cliente não encontrado' }));
    }
}

/**
 * @route POST /clientes
 * @description Cria um novo cliente.
 */
async function criarCliente(req, res) {
    try {
        const body = await bodyParser(req);
        const { nome, cpf, endereco, telefone } = body;

        if (!nome || !cpf) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Campos nome e cpf são obrigatórios' }));
            return;
        }

        const dados = await lerDados();

        // Regra de negócio: Verificar se o CPF já existe
        if (dados.clientes.some(c => c.cpf === cpf)) {
            res.writeHead(409, { 'Content-Type': 'application/json' }); // 409 Conflict
            res.end(JSON.stringify({ message: 'CPF já cadastrado' }));
            return;
        }

        const novoCliente = {
            id: randomUUID(),
            nome,
            cpf,
            endereco: endereco || '',
            telefone: telefone || '',
        };

        dados.clientes.push(novoCliente);
        await escreverDados(dados);

        res.writeHead(201, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(novoCliente));
    } catch (error) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: `Erro ao processar requisição: ${error.message}` }));
    }
}

/**
 * @route PUT /clientes/:id
 * @description Atualiza um cliente existente.
 */
async function atualizarCliente(req, res, params) {
    try {
        const { id } = params;
        const dados = await lerDados();
        const index = dados.clientes.findIndex(c => c.id === id);

        if (index === -1) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Cliente não encontrado' }));
            return;
        }

        const body = await bodyParser(req);
        const clienteOriginal = dados.clientes[index];

        // Regra de negócio: Verificar se o CPF está sendo alterado para um já existente
        if (body.cpf && body.cpf !== clienteOriginal.cpf && dados.clientes.some(c => c.cpf === body.cpf)) {
            res.writeHead(409, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'CPF já pertence a outro cliente' }));
            return;
        }
        
        const clienteAtualizado = {
            ...clienteOriginal,
            ...body,
            id: clienteOriginal.id, // Garante que o ID não seja alterado
        };

        dados.clientes[index] = clienteAtualizado;
        await escreverDados(dados);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(clienteAtualizado));
    } catch (error) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: `Erro ao processar requisição: ${error.message}` }));
    }
}

/**
 * @route DELETE /clientes/:id
 * @description Deleta um cliente.
 */
async function deletarCliente(req, res, params) {
    const { id } = params;
    const dados = await lerDados();
    
    // Regra de negócio: Verificar se o cliente possui vendas associadas antes de deletar
    if (dados.vendas.some(v => v.clienteId === id)) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Não é possível deletar cliente com histórico de vendas.' }));
        return;
    }

    const novosClientes = dados.clientes.filter(c => c.id !== id);

    if (novosClientes.length === dados.clientes.length) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Cliente não encontrado' }));
        return;
    }

    dados.clientes = novosClientes;
    await escreverDados(dados);

    res.writeHead(204, { 'Content-Type': 'application/json' });
    res.end();
}

module.exports = {
    listarClientes,
    obterCliente,
    criarCliente,
    atualizarCliente,
    deletarCliente,
};