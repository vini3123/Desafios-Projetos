const { lerDados, escreverDados } = require('../repositories/farmaciaRepository');
const bodyParser = require('../utils/bodyParser');
const { randomUUID } = require('crypto');

/**
 * @route GET /vendas
 * @description Lista todas as vendas.
 */
async function listarVendas(req, res) {
    const dados = await lerDados();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(dados.vendas || []));
}

/**
 * @route GET /vendas/:id
 * @description Obtém uma venda específica pelo ID.
 */
async function obterVenda(req, res, params) {
    const { id } = params;
    const dados = await lerDados();
    const venda = dados.vendas.find(v => v.id === id);

    if (venda) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(venda));
    } else {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Venda não encontrada' }));
    }
}

/**
 * @route POST /vendas
 * @description Registra uma nova venda, validando estoque e dados.
 */
async function registrarVenda(req, res) {
    try {
        const body = await bodyParser(req);
        const { clienteId, itens } = body;

        if (!clienteId || !itens || !Array.isArray(itens) || itens.length === 0) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Campos clienteId e itens (com pelo menos um item) são obrigatórios' }));
            return;
        }

        const dados = await lerDados();

        // --- Início da Transação (Validação) ---

        // 1. Validar cliente
        const cliente = dados.clientes.find(c => c.id === clienteId);
        if (!cliente) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: `Cliente com id ${clienteId} não encontrado` }));
            return;
        }

        // 2. Validar todos os itens e estoque ANTES de qualquer modificação
        for (const item of itens) {
            const produto = dados.produtos.find(p => p.id === item.produtoId);
            if (!produto) {
                res.writeHead(404, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ message: `Produto com id ${item.produtoId} não encontrado.` }));
                return; // Aborta a operação
            }
            if (produto.estoque < item.quantidade) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ message: `Estoque insuficiente para o produto '${produto.nome}'. Estoque atual: ${produto.estoque}` }));
                return; // Aborta a operação
            }
        }

        // --- Fim da Transação (Execução) ---
        // Se todas as validações passaram, processar a venda

        let valorTotal = 0;
        const itensVendaDetalhado = [];

        for (const item of itens) {
            const produtoIndex = dados.produtos.findIndex(p => p.id === item.produtoId);
            const produto = dados.produtos[produtoIndex];

            // Deduzir do estoque
            produto.estoque -= item.quantidade;

            // Adicionar ao valor total
            valorTotal += produto.preco * item.quantidade;

            // Adicionar detalhes do item para o registro da venda (boa prática)
            itensVendaDetalhado.push({
                produtoId: produto.id,
                nome: produto.nome,
                quantidade: item.quantidade,
                precoUnitario: produto.preco
            });
        }

        const novaVenda = {
            id: randomUUID(),
            clienteId,
            clienteNome: cliente.nome, // Salva o nome do cliente para referência
            data: new Date().toISOString(),
            itens: itensVendaDetalhado,
            valorTotal: parseFloat(valorTotal.toFixed(2))
        };

        dados.vendas.push(novaVenda);
        await escreverDados(dados);

        res.writeHead(201, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(novaVenda));

    } catch (error) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: `Erro ao processar requisição: ${error.message}` }));
    }
}

module.exports = {
    listarVendas,
    obterVenda,
    registrarVenda,
};