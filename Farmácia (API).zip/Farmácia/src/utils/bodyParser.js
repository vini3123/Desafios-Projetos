/**
 * Processa o corpo (body) de uma requisição HTTP e o converte para JSON.
 * @param {import('http').IncomingMessage} req O objeto da requisição.
 * @returns {Promise<object>} Uma promessa que resolve com o corpo da requisição como um objeto JSON.
 */
async function bodyParser(req) {
    return new Promise((resolve, reject) => {
        let corpo = '';

        // Evento 'data' é emitido sempre que um novo pedaço de dados chega
        req.on('data', (chunk) => {
            corpo += chunk.toString();
        });

        // Evento 'end' é emitido quando todos os dados foram recebidos
        req.on('end', () => {
            try {
                // Se o corpo estiver vazio, retorna um objeto vazio
                if (!corpo) {
                    resolve({});
                    return;
                }
                // Tenta converter a string do corpo para JSON
                resolve(JSON.parse(corpo));
            } catch (error) {
                // Se a conversão falhar, rejeita a promessa com um erro
                reject(new Error('Corpo da requisição inválido: não é um JSON válido.'));
            }
        });

        // Trata erros na própria requisição
        req.on('error', (err) => {
            reject(err);
        });
    });
}

module.exports = bodyParser;
