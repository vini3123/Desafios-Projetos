const routes = [];

/**
 * Adiciona uma nova rota ao nosso roteador.
 * @param {string} method O método HTTP (GET, POST, PUT, DELETE).
 * @param {string} path O padrão do caminho da URL. Pode conter parâmetros como /produtos/:id.
 * @param {function} handler A função do controller que irá lidar com a requisição.
 */
function addRoute(method, path, handler) {
    const paramNames = [];
    // Converte o caminho em uma expressão regular, extraindo os nomes dos parâmetros
    const pathRegexString = `^${path.replace(/:([\w-]+)/g, (_, paramName) => {
        paramNames.push(paramName);
        return '([\w-]+)'; // Captura o valor do parâmetro
    })}`;
    const pathRegex = new RegExp(pathRegexString);

    routes.push({ method, path, pathRegex, handler, paramNames });
}

/**
 * Encontra a rota correspondente para uma dada requisição.
 * @param {string} method O método HTTP da requisição.
 * @param {string} url A URL da requisição.
 * @returns {{ handler: function, params: object } | null} O handler e os parâmetros da URL, ou null se nenhuma rota for encontrada.
 */
function findRoute(method, url) {
    // Usamos uma base "dummy" para que a URL seja parseada corretamente mesmo sem o host
    const parsedUrl = new URL(url, `http://localhost`);
    const pathname = parsedUrl.pathname;

    for (const route of routes) {
        if (route.method !== method) continue;

        const match = pathname.match(route.pathRegex);

        if (match) {
            const params = {};
            // O primeiro elemento do match é a string completa, os seguintes são os grupos capturados (nossos parâmetros)
            for (let i = 0; i < route.paramNames.length; i++) {
                params[route.paramNames[i]] = match[i + 1];
            }
            return { handler: route.handler, params };
        }
    }
    return null;
}

module.exports = {
    addRoute,
    findRoute,
};
