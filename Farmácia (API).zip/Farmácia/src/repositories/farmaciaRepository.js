const fs = require('fs/promises');
const path = require('path');

// Resolve o caminho para o database.json a partir da raiz do projeto
const dbPath = path.resolve(__dirname, '..', '..', 'database.json');

/**
 * Lê os dados do arquivo database.json.
 * @returns {Promise<object>} Os dados do banco de dados como um objeto.
 */
async function lerDados() {
    try {
        const dadosString = await fs.readFile(dbPath, 'utf-8');
        // Se o arquivo estiver vazio, retorna a estrutura padrão
        if (!dadosString) {
            return { produtos: [], clientes: [], vendas: [] };
        }
        return JSON.parse(dadosString);
    } catch (error) {
        // Se o arquivo não existir, retorna a estrutura padrão
        if (error.code === 'ENOENT') {
            return { produtos: [], clientes: [], vendas: [] };
        }
        // Se for outro erro, lança para ser tratado em outro lugar
        throw error;
    }
}

/**
 * Escreve os dados fornecidos no arquivo database.json.
 * @param {object} dados O objeto de dados a ser escrito no arquivo.
 */
async function escreverDados(dados) {
    await fs.writeFile(dbPath, JSON.stringify(dados, null, 2));
}

module.exports = {
    lerDados,
    escreverDados,
};
