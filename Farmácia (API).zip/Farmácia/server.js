const http = require('http');
const { addRoute, findRoute } = require('./src/utils/router');

// Importar controllers
const produtoController = require('./src/controllers/produtoController');
const clienteController = require('./src/controllers/clienteController');
const vendaController = require('./src/controllers/vendaController');

// --- Registrar as rotas da API ---

// Rotas de Produtos
addRoute('GET', '/produtos', produtoController.listarProdutos);
addRoute('GET', '/produtos/:id', produtoController.obterProduto);
addRoute('POST', '/produtos', produtoController.criarProduto);
addRoute('PUT', '/produtos/:id', produtoController.atualizarProduto);
addRoute('DELETE', '/produtos/:id', produtoController.deletarProduto);

// Rotas de Clientes
addRoute('GET', '/clientes', clienteController.listarClientes);
addRoute('GET', '/clientes/:id', clienteController.obterCliente);
addRoute('POST', '/clientes', clienteController.criarCliente);
addRoute('PUT', '/clientes/:id', clienteController.atualizarCliente);
addRoute('DELETE', '/clientes/:id', clienteController.deletarCliente);

// Rotas de Vendas
addRoute('GET', '/vendas', vendaController.listarVendas);
addRoute('GET', '/vendas/:id', vendaController.obterVenda);
addRoute('POST', '/vendas', vendaController.registrarVenda);

// --- Criar o servidor HTTP ---
const server = http.createServer(async (req, res) => {
    // Adicionar headers de CORS para permitir requisições de qualquer origem
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    // Responder a requisições OPTIONS (pre-flight) para CORS
    if (req.method === 'OPTIONS') {
        res.writeHead(204); // No Content
        res.end();
        return;
    }

    // Encontrar a rota correspondente
    const route = findRoute(req.method, req.url);

    if (route) {
        try {
            // Passa req, res e os parâmetros da URL para o handler da rota
            await route.handler(req, res, route.params);
        } catch (error) {
            console.error('Erro inesperado:', error); // Log do erro no console
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: `Erro interno do servidor: ${error.message}` }));
        }
    } else {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Rota não encontrada' }));
    }
});

// Iniciar o servidor
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
    console.log(`Endpoints disponíveis em http://localhost:${PORT}`);
});
