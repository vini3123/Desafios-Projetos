// server.js
import express from 'express';
import axios from 'axios';
import { JSDOM } from 'jsdom';

const app = express();
const PORT = 3000;

// Enable CORS for frontend access
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  next();
});

// Scrape endpoint
app.get('/api/scrape', async (req, res) => {
  try {
    const keyword = req.query.keyword;
    if (!keyword) {
      return res.status(400).json({ error: 'Keyword parameter is required' });
    }

    // Fetch Amazon search results
    const response = await axios.get(`https://www.amazon.com/s?k=${encodeURIComponent(keyword)}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
        'Accept-Language': 'en-US,en;q=0.9'
      }
    });

    // Parse HTML content
    const dom = new JSDOM(response.data);
    const document = dom.window.document;

    // Extract product data
    const products = [];
    const productElements = document.querySelectorAll('.s-result-item');

    productElements.forEach(element => {
      try {
        const titleElement = element.querySelector('h2 a');
        const title = titleElement?.textContent.trim();
        
        const ratingElement = element.querySelector('.a-icon-star-small');
        const ratingText = ratingElement?.getAttribute('aria-label') || '';
        const rating = parseFloat(ratingText.split(' ')[0]) || null;
        
        const reviewsElement = element.querySelector('.a-size-small .a-link-normal');
        const reviews = reviewsElement ? parseInt(reviewsElement.textContent.replace(/,/g, '')) : null;
        
        const imageElement = element.querySelector('img.s-image');
        const imageUrl = imageElement?.src;
        
        if (title && imageUrl) {
          products.push({
            title,
            rating,
            reviews,
            imageUrl
          });
        }
      } catch (error) {
        console.error('Error parsing product element:', error);
      }
    });

    res.json(products);
  } catch (error) {
    console.error('Scraping failed:', error);
    res.status(500).json({ error: 'Failed to scrape Amazon products' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});