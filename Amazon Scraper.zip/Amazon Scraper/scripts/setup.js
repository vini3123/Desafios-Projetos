import { execSync } from 'child_process'
import { existsSync, mkdirSync } from 'fs'

console.log('Setting up Amazon Scraper Project...')

// Create directories
const directories = ['backend', 'frontend/src', 'frontend/public', 'scripts']
directories.forEach(dir => {
  if (!existsSync(dir)) {
    mkdirSync(dir, { recursive: true })
    console.log(`Created directory: ${dir}`)
  }
})

console.log('Project structure created successfully!')
console.log('\nNext steps:')
console.log('1. cd backend && bun install')
console.log('2. cd ../frontend && npm install')
console.log('3. Start backend: bun run start')
console.log('4. Start frontend: npm run dev')