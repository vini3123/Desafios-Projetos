# Amazon Product Scraper

A simple application that scrapes Amazon product listings based on search keywords.

## Features
- Backend API built with Bun/Express
- Frontend UI with Vite
- Real-time product scraping from Amazon
- Responsive product grid display

## Installation

### Backend Setup
Install Bun: https://bun.sh/