# Amazon Product Scraper

A complete solution for scraping and displaying Amazon product listings based on search keywords. Built with Bun (backend) and Vite (frontend).

## Features

- **Real-time Amazon Scraping**
  - Product titles, ratings, reviews count, and images
  - First page results extraction
- **Modern Tech Stack**
  - Backend: Bun + Express + JSDOM
  - Frontend: Vite + Vanilla JavaScript
- **User-Friendly Interface**
  - Responsive design
  - Clean product cards display
  - Error handling and loading states
- **API Endpoint**
  - RESTful `/api/scrape` endpoint
  - CORS enabled for frontend access

## Prerequisites

- Node.js v18+
- Bun v1.0+ (for backend)
- npm or yarn (for frontend)

## Installation

### 1. Clone the Repository

```bash
git clone https://github.com/your-username/amazon-scraper.git
cd amazon-scraper

2. Backend Setup
cd backend
bun install

3. Frontend Setup

cd ../frontend

npm install

Start Backend Server

cd backend
bun run start
Server will run on http://localhost:3000

Start Frontend Development Server

cd frontend
npm run dev

Frontend will run on http://localhost:5173

Project Structure
amazon-scraper/
├── backend/
│   ├── server.js          # Main backend server
│   ├── package.json       # Backend dependencies
│   └── bun.lockb          # Bun lock file
├── frontend/
│   ├── src/
│   │   ├── main.js        # Frontend logic
│   │   ├── style.css      # Styling
│   │   └── index.html     # HTML template
│   ├── package.json       # Frontend dependencies
│   ├── vite.config.js     # Vite configuration
│   └── public/            # Static assets
└── scripts/
    └── setup.js  

Create .env file in backend directory:


PORT=3000
REQUEST_TIMEOUT=5000
USER_AGENT=Mozilla/5.0 (Windows NT 10.0; Win64; x64)...
Frontend Environment Variables
Create .env file in frontend directory:


VITE_API_BASE_URL=http://localhost:3000

Open the frontend in your browser (http://localhost:5173)

Enter a search keyword (e.g. "wireless headphones")

Click "Scrape Products" button

View the scraped results from Amazon's first page