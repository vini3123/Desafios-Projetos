// main.js
document.addEventListener('DOMContentLoaded', () => {
  const keywordInput = document.getElementById('keywordInput');
  const scrapeButton = document.getElementById('scrapeButton');
  const resultsContainer = document.getElementById('resultsContainer');
  const errorContainer = document.getElementById('errorContainer');
  const loader = document.createElement('div');
  loader.className = 'loader';
  document.body.appendChild(loader);

  scrapeButton.addEventListener('click', async () => {
    const keyword = keywordInput.value.trim();
    
    if (!keyword) {
      showError('Please enter a search keyword');
      return;
    }
    
    try {
      // Clear previous results and errors
      resultsContainer.innerHTML = '';
      errorContainer.textContent = '';
      loader.style.display = 'block';
      
      // Fetch data from backend
      const response = await fetch(`http://localhost:3000/api/scrape?keyword=${encodeURIComponent(keyword)}`);
      
      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }
      
      const products = await response.json();
      
      if (products.length === 0) {
        resultsContainer.innerHTML = '<p>No products found. Try a different keyword.</p>';
        return;
      }
      
      // Display results
      products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        
        productCard.innerHTML = `
          <img src="${product.imageUrl}" alt="${product.title}" class="product-image">
          <div class="product-title">${product.title}</div>
          <div class="product-rating">${product.rating ? '⭐'.repeat(Math.round(product.rating)) : 'No rating'}</div>
          <div class="product-reviews">${product.reviews ? `${product.reviews.toLocaleString()} reviews` : 'No reviews'}</div>
        `;
        
        resultsContainer.appendChild(productCard);
      });
    } catch (error) {
      showError(`Error: ${error.message}`);
    } finally {
      loader.style.display = 'none';
    }
  });
  
  function showError(message) {
    errorContainer.textContent = message;
  }
});