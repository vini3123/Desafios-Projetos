from django.views.generic import TemplateView

class HomeView(TemplateView):
    template_name = 'static_pages/index.html'

class AboutView(TemplateView):
    template_name = 'static_pages/about.html'

class ContactView(TemplateView):
    template_name = 'static_pages/contact.html'