from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Car, Brand
from .forms import CarForm, BrandForm

def home(request, brand_name=None):
    try:
        cars_list = Car.objects.filter(is_sold=False).order_by('-created_at')
        brands = Brand.objects.all()
        
        if brand_name:
            brand = get_object_or_404(Brand, name=brand_name)
            cars_list = cars_list.filter(brand=brand)
        
        paginator = Paginator(cars_list, 9)  # 9 cars per page
        page = request.GET.get('page')
        
        try:
            cars = paginator.page(page)
        except PageNotAnInteger:
            cars = paginator.page(1)
        except EmptyPage:
            cars = paginator.page(paginator.num_pages)
        
        context = {
            'cars': cars,
            'brands': brands,
            'brand_name': brand_name,
        }
        return render(request, 'home.html', context)
    
    except Exception as e:
        messages.error(request, "An error occurred while loading the page.")
        return render(request, 'error.html', status=500)

def about(request):
    return render(request, 'about.html')

def contact(request):
    if request.method == 'POST':
        # Process contact form
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        # Here you would typically send an email or save to database
        messages.success(request, "Thank you for your message! We'll get back to you soon.")
        return redirect('contact')
    return render(request, 'contact.html')

@login_required
def add_car(request):
    if request.method == 'POST':
        form = CarForm(request.POST, request.FILES)
        if form.is_valid():
            car = form.save(commit=False)
            car.created_by = request.user
            car.save()
            messages.success(request, "Car added successfully!")
            return redirect('home')
    else:
        form = CarForm()
    return render(request, 'cars/add_car.html', {'form': form})

@login_required
def add_brand(request):
    if request.method == 'POST':
        form = BrandForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Brand added successfully!")
            return redirect('home')
    else:
        form = BrandForm()
    return render(request, 'brands/add_brand.html', {'form': form})