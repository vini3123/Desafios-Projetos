from django import forms
from .models import Car, Brand

class CarForm(forms.ModelForm):
    class Meta:
        model = Car
        fields = [
            'brand', 'model', 'year', 'price', 'mileage', 
            'color', 'transmission', 'fuel_type', 'engine_size',
            'description', 'image'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'year': forms.NumberInput(attrs={'min': 1900, 'max': 2025}),
        }

class BrandForm(forms.ModelForm):
    class Meta:
        model = Brand
        fields = ['name', 'logo', 'founded', 'headquarters', 'website', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'founded': forms.NumberInput(attrs={'min': 1800, 'max': 2025}),
        }