document.addEventListener('DOMContentLoaded', () => {
    // Dados do quiz
    const quizData = [
        {
            question: "Qual linguagem foi criada por Guido van Rossum?",
            options: ["JavaScript", "Python", "Java", "C++"],
            answer: "Python"
        },
        {
            question: "Qual linguagem é conhecida como a linguagem da web?",
            options: ["Python", "Java", "JavaScript", "C#"],
            answer: "JavaScript"
        },
        {
            question: "Qual linguagem foi desenvolvida pela Microsoft?",
            options: ["Java", "C#", "Python", "Ruby"],
            answer: "C#"
        },
        {
            question: "Qual linguagem é usada principalmente para desenvolvimento Android?",
            options: ["Swift", "Kotlin", "Objective-C", "Dart"],
            answer: "Kotlin"
        },
        {
            question: "Qual linguagem foi criada por Brendan Eich em apenas 10 dias?",
            options: ["Python", "Ruby", "JavaScript", "PHP"],
            answer: "JavaScript"
        }
    ];

    const questionElement = document.getElementById('question');
    const optionsElement = document.querySelector('.options');
    const scoreElement = document.getElementById('score');
    const prevButton = document.getElementById('prev');
    const nextButton = document.getElementById('next');
    const submitButton = document.getElementById('submit');
    const quizElement = document.querySelector('.quiz');
    const resultElement = document.querySelector('.result');
    const correctElement = document.getElementById('correct');
    const totalElement = document.getElementById('total');
    const percentageElement = document.getElementById('percentage');
    const restartButton = document.getElementById('restart');

    let currentQuestion = 0;
    let score = 0;
    let selectedOption = null;
    let userAnswers = new Array(quizData.length).fill(null);

    function loadQuestion() {
        const currentQuizData = quizData[currentQuestion];
        questionElement.textContent = currentQuizData.question;
        
        optionsElement.innerHTML = '';
        currentQuizData.options.forEach(option => {
            const button = document.createElement('button');
            button.textContent = option;
            button.classList.add('option');
            if (userAnswers[currentQuestion] === option) {
                button.classList.add('selected');
                selectedOption = button;
            }
            button.addEventListener('click', selectOption);
            optionsElement.appendChild(button);
        });

        prevButton.disabled = currentQuestion === 0;
        nextButton.style.display = currentQuestion === quizData.length - 1 ? 'none' : 'block';
        submitButton.style.display = currentQuestion === quizData.length - 1 ? 'block' : 'none';
    }

    function selectOption(e) {
        if (selectedOption) {
            selectedOption.classList.remove('selected');
        }
        
        selectedOption = e.target;
        selectedOption.classList.add('selected');
        userAnswers[currentQuestion] = selectedOption.textContent;
    }

    function calculateScore() {
        let correct = 0;
        quizData.forEach((question, index) => {
            if (userAnswers[index] === question.answer) {
                correct++;
            }
        });
        score = correct;
        return correct;
    }

    function showResult() {
        const correct = calculateScore();
        quizElement.style.display = 'none';
        resultElement.style.display = 'block';
        correctElement.textContent = correct;
        totalElement.textContent = quizData.length;
        percentageElement.textContent = Math.round((correct / quizData.length) * 100);
    }

    prevButton.addEventListener('click', () => {
        currentQuestion--;
        loadQuestion();
    });

    nextButton.addEventListener('click', () => {
        if (currentQuestion < quizData.length - 1) {
            currentQuestion++;
            loadQuestion();
        }
    });

    submitButton.addEventListener('click', showResult);

    restartButton.addEventListener('click', () => {
        currentQuestion = 0;
        score = 0;
        userAnswers = new Array(quizData.length).fill(null);
        quizElement.style.display = 'block';
        resultElement.style.display = 'none';
        scoreElement.textContent = '0';
        loadQuestion();
    });

    // Inicializar quiz
    loadQuestion();
});