Como usar a Aplicação TODO

Esta é uma aplicação de lista de tarefas (TODO list) simples construída com React.

Funcionalidades:
- Adicionar novas tarefas.
- Marcar tarefas como concluídas (clicando no texto da tarefa).
- Remover tarefas (clicando no botão "Delete").

Como executar a aplicação:

1.  Navegue até o diretório da aplicação:
    cd todo-app

2.  Instale as dependências (se ainda não o fez ou se houver erros):
    npm install

3.  Inicie o servidor de desenvolvimento:
    npm start

A aplicação será aberta automaticamente no seu navegador padrão em http://localhost:3000.
Se não abrir, acesse manualmente o endereço no seu navegador.

Como interagir com a aplicação:

- Para adicionar uma tarefa: Digite o texto da tarefa no campo de entrada e clique no botão "Add".
- Para marcar/desmarcar uma tarefa como concluída: Clique no texto da tarefa na lista.
- Para remover uma tarefa: Clique no botão "Delete" ao lado da tarefa.
