const express = require('express');
const app = express();
const port = 3009;

app.use(express.json());

// Middleware de autenticação
app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== 'turma2025') {
    return res.status(401).json({ error: 'API key inválida' });
  }
  next();
});

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'forno', time: new Date().toISOString() });
});

// Simular preparo da pizza
app.post('/v1/preparar', async (req, res) => {
  const { pedidoId } = req.body;
  
  // Simular tempo de preparo (5-15 segundos)
  const tempoPreparo = Math.floor(Math.random() * 10000) + 5000;
  
  console.log(`Preparando pedido ${pedidoId}, tempo estimado: ${tempoPreparo/1000} segundos`);
  
  setTimeout(async () => {
    try {
      // Atualizar status para "pronto"
      await axios.post(`http://localhost:3007/v1/pedido/${pedidoId}/status`, {
        status: 'pronto'
      }, {
        headers: { 
          'x-api-key': 'turma2025',
          'x-pedido-id': pedidoId
        }
      });
      
      console.log(`Pedido ${pedidoId} pronto!`);
      
      // Notificar cliente (simulação)
      await axios.post('http://localhost:3000/v1/entrega', {
        pedidoId: pedidoId,
        status: 'pronto',
        mensagem: 'Sua pizza está pronta!'
      }, {
        headers: { 
          'x-api-key': 'turma2025',
          'x-pedido-id': pedidoId
        }
      });
      
    } catch (error) {
      console.error(`Erro ao finalizar pedido ${pedidoId}:`, error.message);
    }
  }, tempoPreparo);
  
  res.json({ message: 'Pizza em preparo', tempoEstimado: tempoPreparo });
});

app.listen(port, () => {
  console.log(`Serviço de forno rodando na porta ${port}`);
});