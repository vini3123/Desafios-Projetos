const express = require('express');
const app = express();
const port = 3005;

app.use(express.json());

// Middleware de autenticação
app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== 'turma2025') {
    return res.status(401).json({ error: 'API key inválida' });
  }
  next();
});

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'pagamento', time: new Date().toISOString() });
});

// Processar pagamento
app.post('/v1/pagamento', (req, res) => {
  // Simulação de processamento de pagamento (80% de chance de aprovação)
  const aprovado = Math.random() > 0.2;
  
  if (!aprovado) {
    return res.json({ aprovado: false, transacaoId: 'tx_' + Math.random().toString(36).substr(2, 9) });
  }
  
  res.json({ aprovado: true, transacaoId: 'tx_' + Math.random().toString(36).substr(2, 9) });
});

app.listen(port, () => {
  console.log(`Serviço de pagamento A rodando na porta ${port}`);
});