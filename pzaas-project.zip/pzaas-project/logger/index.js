const express = require('express');
const app = express();
const port = 3012;

app.use(express.json());

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'logger', time: new Date().toISOString() });
});

// Receber logs
app.post('/v1/logs', (req, res) => {
  console.log('LOG:', req.body);
  res.status(200).send('OK');
});

app.listen(port, () => {
  console.log(`Serviço de logger rodando na porta ${port}`);
});