const express = require('express');
const axios = require('axios');
const app = express();
const port = 3010;

app.use(express.json());

// Middleware de autenticação
app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== 'turma2025') {
    return res.status(401).json({ error: 'API key inválida' });
  }
  next();
});

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'fila', time: new Date().toISOString() });
});

// Fila de produção
let fila = [];
let processando = false;

// Adicionar à fila
app.post('/v1/fila', (req, res) => {
  const { pedidoId } = req.body;
  
  fila.push(pedidoId);
  console.log(`Pedido ${pedidoId} adicionado à fila. Tamanho da fila: ${fila.length}`);
  
  // Iniciar processamento se não estiver processando
  if (!processando) {
    processarFila();
  }
  
  res.json({ message: 'Pedido adicionado à fila', posicao: fila.length });
});

// Processar fila
async function processarFila() {
  if (fila.length === 0) {
    processando = false;
    return;
  }
  
  processando = true;
  const pedidoId = fila.shift();
  
  console.log(`Processando pedido ${pedidoId}...`);
  
  try {
    // Atualizar status para "preparando"
    await axios.post(`http://localhost:3007/v1/pedido/${pedidoId}/status`, {
      status: 'preparando'
    }, {
      headers: { 
        'x-api-key': 'turma2025',
        'x-pedido-id': pedidoId
      }
    });
    
    // Enviar para o forno
    await axios.post('http://localhost:3009/v1/preparar', {
      pedidoId: pedidoId
    }, {
      headers: { 
        'x-api-key': 'turma2025',
        'x-pedido-id': pedidoId
      }
    });
    
  } catch (error) {
    console.error(`Erro ao processar pedido ${pedidoId}:`, error.message);
  }
  
  // Processar próximo pedido após um delay
  setTimeout(processarFila, 1000);
}

app.listen(port, () => {
  console.log(`Serviço de fila rodando na porta ${port}`);
});