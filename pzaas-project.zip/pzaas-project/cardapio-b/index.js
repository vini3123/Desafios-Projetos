const express = require('express');
const app = express();
const port = 3002;

app.use(express.json());

// Middleware de autenticação
app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== 'turma2025') {
    return res.status(401).json({ error: 'API key inválida' });
  }
  next();
});

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'cardapio-b', time: new Date().toISOString() });
});

// Cardápio de pizzas (versão alternativa)
const cardapio = [
  { id: 1, nome: 'Margherita Clássica', ingredientes: ['molho', 'muçarela', 'manjericão'], preco: 26.00 },
  { id: 2, nome: 'Pepperoni Especial', ingredientes: ['molho', 'muçarela', 'pepperoni'], preco: 31.00 },
  { id: 3, nome: 'Quatro Queijos Premium', ingredientes: ['molho', 'muçarela', 'gorgonzola', 'parmesão', 'provolone'], preco: 36.00 },
  { id: 6, nome: 'Frango com Catupiry', ingredientes: ['molho', 'muçarela', 'frango', 'catupiry'], preco: 33.00 },
  { id: 7, nome: 'Napolitana', ingredientes: ['molho', 'muçarela', 'tomate', 'manjericão'], preco: 29.00 }
];

// Rota do cardápio
app.get('/v1/cardapio', (req, res) => {
  res.json(cardapio);
});

app.listen(port, () => {
  console.log(`Serviço de cardápio B rodando na porta ${port}`);
});