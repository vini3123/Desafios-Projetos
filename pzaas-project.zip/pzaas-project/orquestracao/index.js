const express = require('express');
const app = express();
const port = 3007;

app.use(express.json());

// Middleware de autenticação
app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== 'turma2025') {
    return res.status(401).json({ error: 'API key inválida' });
  }
  next();
});

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'orquestracao', time: new Date().toISOString() });
});

// Banco de dados em memória para pedidos
const pedidos = {};

// Criar pedido
app.post('/v1/pedido', (req, res) => {
  const pedidoId = 'ped_' + Math.random().toString(36).substr(2, 9);
  pedidos[pedidoId] = {
    id: pedidoId,
    pizza: req.body.pizza,
    cliente: req.body.cliente,
    status: 'recebido',
    timestamp: new Date().toISOString()
  };
  
  res.json({ pedidoId });
});

// Consultar status
app.get('/v1/pedido/:pedidoId/status', (req, res) => {
  const pedido = pedidos[req.params.pedidoId];
  if (!pedido) {
    return res.status(404).json({ error: 'Pedido não encontrado' });
  }
  
  res.json({ status: pedido.status });
});

// Atualizar status
app.post('/v1/pedido/:pedidoId/status', (req, res) => {
  const pedido = pedidos[req.params.pedidoId];
  if (!pedido) {
    return res.status(404).json({ error: 'Pedido não encontrado' });
  }
  
  pedido.status = req.body.status;
  res.json({ status: pedido.status });
});

app.listen(port, () => {
  console.log(`Serviço de orquestração rodando na porta ${port}`);
});