const express = require('express');
const app = express();
const port = 3003;

app.use(express.json());

 //Middleware de autenticação
app.use((req, res, next) = {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey  apiKey !== 'turma2025') {
    return res.status(401).json({ error 'API key inválida' });
  }
  next();
});

 Healthcheck
app.get('health', (req, res) = {
  res.json({ status 'ok', service 'estoque', time new Date().toISOString() });
});

 Verificar estoque
app.post('v1estoqueverificar', (req, res) = {
   Simulação de verificação de estoque
  res.json({ disponivel true, mensagem 'Ingredientes disponíveis' });
});

app.listen(port, () = {
  console.log(`Serviço de estoque rodando na porta ${port}`);
});