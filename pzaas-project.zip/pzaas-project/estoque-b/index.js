const express = require('express');
const app = express();
const port = 3004;

app.use(express.json());

// Middleware de autenticação
app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== 'turma2025') {
    return res.status(401).json({ error: 'API key inválida' });
  }
  next();
});

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'estoque-b', time: new Date().toISOString() });
});

// Verificar estoque
app.post('/v1/estoque/verificar', (req, res) => {
  // Sempre disponível no serviço B
  res.json({ disponivel: true, mensagem: 'Ingredientes disponíveis (serviço B)' });
});

app.listen(port, () => {
  console.log(`Serviço de estoque B rodando na porta ${port}`);
});