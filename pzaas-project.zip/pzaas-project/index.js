const express = require('express');
const axios = require('axios');
const app = express();
const port = 3000;

 Middleware para parsing JSON
app.use(express.json());

 Middleware para headers obrigatórios
app.use((req, res, next) = {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey  apiKey !== 'turma2025') {
    return res.status(401).json({ error 'API key inválida' });
  }
  next();
});

 Healthcheck
app.get('health', (req, res) = {
  res.json({ status 'ok', service 'gateway', time new Date().toISOString() });
});

 Rota do cardápio
app.get('v1cardapio', async (req, res) = {
  try {
    const response = await axios.get('httplocalhost3001v1cardapio', {
      headers { 'x-api-key' 'turma2025' }
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error 'Serviço de cardápio indisponível' });
  }
});

 Rota de pedido
app.post('v1pedido', async (req, res) = {
  try {
     Verificar cardápio
    await axios.get('httplocalhost3001v1cardapio', {
      headers { 'x-api-key' 'turma2025' }
    });
    
     Verificar estoque
    await axios.post('httplocalhost3003v1estoqueverificar', {
      pizza req.body.pizza
    }, {
      headers { 'x-api-key' 'turma2025' }
    });
    
     Processar pagamento
    const pagamentoResponse = await axios.post('httplocalhost3005v1pagamento', {
      metodo req.body.metodoPagamento,
      valor req.body.valor
    }, {
      headers { 'x-api-key' 'turma2025' }
    });
    
    if (!pagamentoResponse.data.aprovado) {
      return res.status(400).json({ error 'Pagamento recusado' });
    }
    
     Criar pedido
    const pedidoResponse = await axios.post('httplocalhost3007v1pedido', {
      pizza req.body.pizza,
      cliente req.body.cliente
    }, {
      headers { 'x-api-key' 'turma2025' }
    });
    
    res.json({ pedidoId pedidoResponse.data.pedidoId });
  } catch (error) {
    res.status(500).json({ error 'Erro ao processar pedido' });
  }
});

 Rota de status
app.get('v1statuspedidoId', async (req, res) = {
  try {
    const response = await axios.get(`httplocalhost3007v1pedido${req.params.pedidoId}status`, {
      headers { 'x-api-key' 'turma2025' }
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error 'Erro ao consultar status' });
  }
});

 Rota de entrega (webhook)
app.post('v1entrega', (req, res) = {
  console.log('Notificação de entrega recebida', req.body);
  res.status(200).send('OK');
});

app.listen(port, () = {
  console.log(`Gateway rodando na porta ${port}`);
});