const express = require('express');
const axios = require('axios');
const app = express();
const port = 3013;

app.use(express.json());

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'chaos-monkey', time: new Date().toISOString() });
});

// Introduzir falhas aleatórias
setInterval(() => {
  if (Math.random() < 0.3) { // 30% de chance de causar falha
    const services = [
      'http://localhost:3001/health',
      'http://localhost:3003/health',
      'http://localhost:3005/health'
    ];
    
    const target = services[Math.floor(Math.random() * services.length)];
    
    console.log(`Chaos Monkey atacando: ${target}`);
    
    // Simular falha fazendo uma requisição e ignorando erro
    axios.get(target).catch(() => {});
  }
}, 30000); // Verificar a cada 30 segundos

app.listen(port, () => {
  console.log(`Chaos Monkey rodando na porta ${port}`);
});