const express = require('express');
const app = express();
const port = 3011;

app.use(express.json());

// Middleware de autenticação
app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== 'turma2025') {
    return res.status(401).json({ error: 'API key inválida' });
  }
  next();
});

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'auth', time: new Date().toISOString() });
});

// Validar token (simulação simples)
app.get('/v1/auth/validate', (req, res) => {
  // Simulação simples de validação
  const valid = Math.random() > 0.1; // 90% de validade
  
  if (!valid) {
    return res.json({ valid: false, message: 'Token inválido' });
  }
  
  res.json({ valid: true, user: { id: 1, name: 'Cliente Teste' } });
});

app.listen(port, () => {
  console.log(`Serviço de autenticação rodando na porta ${port}`);
});