const express = require('express');
const axios = require('axios');
const app = express();
const port = 3000;

app.use(express.json());

// Middleware para headers obrigatórios
app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== 'turma2025') {
    return res.status(401).json({ error: 'API key inválida' });
  }
  
  // Gerar ID de pedido se não existir
  if (!req.headers['x-pedido-id']) {
    req.headers['x-pedido-id'] = 'ped_' + Math.random().toString(36).substr(2, 9);
  }
  
  next();
});

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'gateway', time: new Date().toISOString() });
});

// Rota do cardápio
app.get('/v1/cardapio', async (req, res) => {
  try {
    const response = await axios.get('http://localhost:3001/v1/cardapio', {
      headers: { 
        'x-api-key': 'turma2025',
        'x-pedido-id': req.headers['x-pedido-id']
      }
    });
    res.json(response.data);
  } catch (error) {
    // Fallback para cardápio B
    try {
      const response = await axios.get('http://localhost:3002/v1/cardapio', {
        headers: { 
          'x-api-key': 'turma2025',
          'x-pedido-id': req.headers['x-pedido-id']
        }
      });
      res.json(response.data);
    } catch (error) {
      res.status(503).json({ error: 'Serviço de cardápio indisponível' });
    }
  }
});

// Rota de pedido
app.post('/v1/pedido', async (req, res) => {
  try {
    // Verificar autenticação
    const authResponse = await axios.get('http://localhost:3010/v1/auth/validate', {
      headers: { 
        'x-api-key': 'turma2025',
        'x-pedido-id': req.headers['x-pedido-id']
      }
    });
    
    if (!authResponse.data.valid) {
      return res.status(401).json({ error: 'Não autorizado' });
    }
    
    // Verificar estoque
    const estoqueResponse = await axios.post('http://localhost:3003/v1/estoque/verificar', {
      pizza: req.body.pizza
    }, {
      headers: { 
        'x-api-key': 'turma2025',
        'x-pedido-id': req.headers['x-pedido-id']
      }
    });
    
    if (!estoqueResponse.data.disponivel) {
      return res.status(400).json({ error: 'Item fora de estoque' });
    }
    
    // Processar pagamento
    const pagamentoResponse = await axios.post('http://localhost:3005/v1/pagamento', {
      metodo: req.body.metodoPagamento,
      valor: req.body.valor
    }, {
      headers: { 
        'x-api-key': 'turma2025',
        'x-pedido-id': req.headers['x-pedido-id']
      }
    });
    
    if (!pagamentoResponse.data.aprovado) {
      return res.status(400).json({ error: 'Pagamento recusado' });
    }
    
    // Criar pedido
    const pedidoResponse = await axios.post('http://localhost:3007/v1/pedido', {
      pizza: req.body.pizza,
      cliente: req.body.cliente
    }, {
      headers: { 
        'x-api-key': 'turma2025',
        'x-pedido-id': req.headers['x-pedido-id']
      }
    });
    
    // Adicionar à fila de produção
    await axios.post('http://localhost:3009/v1/fila', {
      pedidoId: pedidoResponse.data.pedidoId
    }, {
      headers: { 
        'x-api-key': 'turma2025',
        'x-pedido-id': req.headers['x-pedido-id']
      }
    });
    
    res.json({ pedidoId: pedidoResponse.data.pedidoId });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao processar pedido' });
  }
});

// Rota de status
app.get('/v1/status/:pedidoId', async (req, res) => {
  try {
    const response = await axios.get(`http://localhost:3007/v1/pedido/${req.params.pedidoId}/status`, {
      headers: { 
        'x-api-key': 'turma2025',
        'x-pedido-id': req.headers['x-pedido-id']
      }
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao consultar status' });
  }
});

// Rota de entrega (webhook)
app.post('/v1/entrega', (req, res) => {
  console.log('Notificação de entrega recebida:', req.body);
  // Enviar log
  axios.post('http://localhost:3011/v1/logs', {
    service: 'gateway',
    message: 'Notificação de entrega recebida',
    data: req.body,
    timestamp: new Date().toISOString()
  }, {
    headers: { 
      'x-api-key': 'turma2025',
      'x-pedido-id': req.headers['x-pedido-id']
    }
  }).catch(() => {}); // Ignora erros de log
  
  res.status(200).send('OK');
});

app.listen(port, () => {
  console.log(`Gateway rodando na porta ${port}`);
});