const express = require('express');
const app = express();
const port = 3001;

app.use(express.json());

// Middleware de autenticação
app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== 'turma2025') {
    return res.status(401).json({ error: 'API key inválida' });
  }
  next();
});

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'cardapio', time: new Date().toISOString() });
});

// Cardápio de pizzas
const cardapio = [
  { id: 1, nome: 'Margherita', ingredientes: ['molho', 'muçarela', 'manjericão'], preco: 25.00 },
  { id: 2, nome: 'Pepperoni', ingredientes: ['molho', 'muçarela', 'pepperoni'], preco: 30.00 },
  { id: 3, nome: 'Quatro Queijos', ingredientes: ['molho', 'muçarela', 'gorgonzola', 'parmesão', 'provolone'], preco: 35.00 }
];

// Rota do cardápio
app.get('/v1/cardapio', (req, res) => {
  res.json(cardapio);
});

app.listen(port, () => {
  console.log(`Serviço de cardápio rodando na porta ${port}`);
});