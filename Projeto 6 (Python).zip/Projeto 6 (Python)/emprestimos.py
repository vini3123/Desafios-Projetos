# main.py

import pandas as pd
import json

# Lista de cursos a serem avaliados
CURSOS_AVALIADOS = [
    "Biblioteconomia",
    "Ciências sociais",
    "Comunicação social",
    "Direito",
    "Filosofia",
    "Pedagogia"
]

# Função para carregar dados do Excel
def carregar_excel(caminho_arquivo):
    df = pd.read_excel(caminho_arquivo)
    return df

# Função para carregar dados do JSON
def carregar_json(caminho_arquivo):
    with open(caminho_arquivo, 'r', encoding='utf-8') as f:
        data = json.load(f)
    df = pd.DataFrame(data)
    return df

# Função principal para processar os dados
def processar_dados(df_excel, df_json):
    # Unificar os dataframes
    df_unificado = pd.concat([df_excel, df_json], ignore_index=True)

    # Garantir que a coluna de matrícula seja string e não tenha nulos
    df_unificado['matricula'] = df_unificado['matricula'].astype(str)
    df_unificado.dropna(subset=['matricula'], inplace=True)

    # Converter 'data_emprestimo' para datetime e extrair o ano
    df_unificado['data_emprestimo'] = pd.to_datetime(df_unificado['data_emprestimo'])
    df_unificado['ano'] = df_unificado['data_emprestimo'].dt.year

    # Filtrar por anos entre 2015 e 2020 e cursos avaliados
    df_filtrado = df_unificado[
        (df_unificado['ano'] >= 2015) &
        (df_unificado['ano'] <= 2020) &
        (df_unificado['curso'].isin(CURSOS_AVALIADOS))
    ].copy()

    # Calcular a quantidade de empréstimos por curso e ano
    df_emprestimos = df_filtrado.groupby(['curso', 'ano']).size().reset_index(name='quantidade_emprestimos')

    # Criar a tabela pivot
    tabela_pivot = df_emprestimos.pivot_table(
        index='curso',
        columns='ano',
        values='quantidade_emprestimos',
        fill_value=0
    )

    # Adicionar linha e coluna de totais
    tabela_pivot.loc['Total'] = tabela_pivot.sum()
    tabela_pivot['Total'] = tabela_pivot.sum(axis=1)

    return tabela_pivot

if __name__ == "__main__":
    # Exemplo de uso (assumindo que os arquivos existem no mesmo diretório)
    try:
        df_excel = carregar_excel('emprestimos_excel.xlsx')
        df_json = carregar_json('emprestimos_json.json')

        tabela_final = processar_dados(df_excel, df_json)
        print("Tabela de Empréstimos por Curso e Ano:")
        print(tabela_final)

        # Salvar a tabela final em um arquivo CSV para visualização
        tabela_final.to_csv('tabela_emprestimos.csv')
        print("\nTabela salva em 'tabela_emprestimos.csv'")

    except FileNotFoundError as e:
        print(f"Erro: Arquivo não encontrado. Certifique-se de que 'emprestimos_excel.xlsx' e 'emprestimos_json.json' estão no diretório correto. Detalhes: {e}")
    except Exception as e:
        print(f"Ocorreu um erro inesperado: {e}")


