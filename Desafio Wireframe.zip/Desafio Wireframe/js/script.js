document.addEventListener('DOMContentLoaded', () => {

    // --- Elementos do DOM ---
    const navButtons = document.querySelectorAll('.nav-btn');
    const pages = document.querySelectorAll('.page');
    const headerTitle = document.querySelector('.header h1');
    const transactionForm = document.querySelector('#add-page form');
    const transactionsContainer = document.getElementById('transactions-page');
    const typeInput = document.getElementById('type');
    const addIncomeBtn = document.querySelector('.btn-primary');
    const addExpenseBtn = document.querySelector('.btn-secondary');
    const balanceDisplay = document.querySelector('.balance');

    // --- Estado da Aplicação (Fonte da Verdade) ---
    let transactions = [
        { description: 'Salário', amount: 2500, type: 'income' },
        { description: 'Compra no mercado', amount: 150, type: 'expense' },
        { description: 'Café', amount: 12.50, type: 'expense' }
    ];

    // --- Mapeamento de Títulos ---
    const pageTitles = {
        'dashboard-page': 'Dashboard',
        'transactions-page': 'Transações',
        'add-page': 'Adicionar Transação'
    };

    // --- Funções ---

    function formatCurrency(value) {
        const signal = value < 0 ? '- ' : '';
        return signal + `R$ ${Math.abs(value).toFixed(2).replace('.', ',')}`;
    }

    function updateBalance() {
        const balance = transactions.reduce((acc, transaction) => {
            return transaction.type === 'income' ? acc + transaction.amount : acc - transaction.amount;
        }, 0);
        balanceDisplay.textContent = formatCurrency(balance);
        
        // Mudar a cor do saldo se for negativo
        if (balance < 0) {
            balanceDisplay.classList.add('expense');
            balanceDisplay.classList.remove('income'); // Garante que a classe de receita não esteja presente
        } else {
            balanceDisplay.classList.remove('expense');
            balanceDisplay.classList.add('income'); // Adiciona a classe de receita para saldo positivo ou zero
        }
    }


    function renderTransactions() {
        transactionsContainer.innerHTML = ''; // Limpa a lista antes de renderizar

        if (transactions.length === 0) {
            transactionsContainer.innerHTML = '<p style="text-align: center; color: var(--text-color-secondary);">Nenhuma transação registrada.</p>';
            return;
        }
        
        transactions.forEach((transaction, index) => {
            const isIncome = transaction.type === 'income';
            const amountFormatted = (isIncome ? '+ ' : '- ') + `R$ ${Math.abs(transaction.amount).toFixed(2).replace('.', ',')}`;
            const amountClass = isIncome ? 'income' : 'expense';

            const transactionElement = document.createElement('div');
            transactionElement.classList.add('card', 'transaction-item');

            transactionElement.innerHTML = `
                <div class="transaction-item-info">
                    <p>${transaction.description}</p>
                    <p class="${amountClass}">${amountFormatted}</p>
                </div>
                <button class="btn-delete" data-index="${index}" title="Excluir transação">&times;</button>
            `;

            transactionsContainer.appendChild(transactionElement);
        });
    }

    function addTransaction(description, amount, type) {
        transactions.unshift({ description, amount, type }); // Adiciona no início do array
        renderTransactions();
        updateBalance();
    }

    function deleteTransaction(index) {
        transactions.splice(index, 1);
        renderTransactions();
        updateBalance();
    }

    function showPage(pageId) {
        pages.forEach(page => page.classList.remove('active'));
        const newPage = document.getElementById(pageId);
        if (newPage) newPage.classList.add('active');

        headerTitle.textContent = pageTitles[pageId] || 'Meu Dinheiro';

        navButtons.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.page === pageId);
        });
    }
    
    // --- Listeners de Eventos ---

    navButtons.forEach(button => {
        button.addEventListener('click', () => showPage(button.dataset.page));
    });
    
    addIncomeBtn.addEventListener('click', () => {
        typeInput.value = 'income';
        showPage('add-page');
        document.getElementById('description').focus();
    });

    addExpenseBtn.addEventListener('click', () => {
        typeInput.value = 'expense';
        showPage('add-page');
        document.getElementById('description').focus();
    });

    transactionForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const descriptionInput = document.getElementById('description');
        const amountInput = document.getElementById('amount');

        const description = descriptionInput.value.trim();
        const amount = parseFloat(amountInput.value);
        const type = typeInput.value;

        if (description === '' || isNaN(amount) || amount <= 0) {
            alert('Por favor, preencha a descrição e um valor positivo.');
            return;
        }

        addTransaction(description, amount, type);

        transactionForm.reset();
        typeInput.value = 'income'; // Garante que o padrão seja 'income'

        showPage('transactions-page');
    });

    transactionsContainer.addEventListener('click', (event) => {
        if (event.target.classList.contains('btn-delete')) {
            const index = parseInt(event.target.dataset.index, 10);
            deleteTransaction(index);
        }
    });

    // --- Inicialização ---
    
    function init() {
        renderTransactions();
        updateBalance();
        showPage('dashboard-page');
    }

    init();

});
