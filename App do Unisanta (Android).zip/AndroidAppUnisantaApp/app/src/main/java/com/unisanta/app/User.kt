package com.unisanta.app

data class User(
    val email: String,
    val password: String
)

