package com.unisanta.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var buttonLogin: Button
    private lateinit var buttonRegister: Button
    private lateinit var textViewForgotPassword: TextView
    private lateinit var userManager: UserManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        initViews()
        userManager = UserManager(this)
        setupClickListeners()
    }
    
    private fun initViews() {
        editTextEmail = findViewById(R.id.editTextEmail)
        editTextPassword = findViewById(R.id.editTextPassword)
        buttonLogin = findViewById(R.id.buttonLogin)
        buttonRegister = findViewById(R.id.buttonRegister)
        textViewForgotPassword = findViewById(R.id.textViewForgotPassword)
    }
    
    private fun setupClickListeners() {
        buttonLogin.setOnClickListener {
            performLogin()
        }
        
        buttonRegister.setOnClickListener {
            performRegister()
        }
        
        textViewForgotPassword.setOnClickListener {
            showForgotPasswordDialog()
        }
    }
    
    private fun performLogin() {
        val email = editTextEmail.text.toString().trim()
        val password = editTextPassword.text.toString().trim()
        
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (userManager.loginUser(email, password)) {
            Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, UsersListActivity::class.java)
            startActivity(intent)
        } else {
            Toast.makeText(this, "Email ou senha incorretos", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun performRegister() {
        val email = editTextEmail.text.toString().trim()
        val password = editTextPassword.text.toString().trim()
        
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Por favor, insira um email válido", Toast.LENGTH_SHORT).show()
            return
        }
        
        val user = User(email, password)
        if (userManager.registerUser(user)) {
            Toast.makeText(this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
            editTextEmail.text.clear()
            editTextPassword.text.clear()
        } else {
            Toast.makeText(this, "Este email já está cadastrado", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun showForgotPasswordDialog() {
        AlertDialog.Builder(this)
            .setTitle("Esqueceu a Senha?")
            .setMessage("Fale Com O Administrador")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}

