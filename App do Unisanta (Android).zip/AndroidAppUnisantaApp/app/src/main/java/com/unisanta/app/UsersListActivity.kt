package com.unisanta.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class UsersListActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var userAdapter: UserAdapter
    private lateinit var userManager: UserManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_users_list)
        
        initViews()
        setupRecyclerView()
        loadUsers()
    }
    
    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerViewUsers)
    }
    
    private fun setupRecyclerView() {
        userManager = UserManager(this)
        userAdapter = UserAdapter()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = userAdapter
    }
    
    private fun loadUsers() {
        val users = userManager.getAllUsers()
        userAdapter.submitList(users)
    }
}

