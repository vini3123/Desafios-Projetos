package com.unisanta.app

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class UserManager(context: Context) {
    private val sharedPreferences: SharedPreferences = 
        context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()
    
    fun registerUser(user: User): Boolean {
        val users = getAllUsers().toMutableList()
        
        // Verifica se o usuário já existe
        if (users.any { it.email == user.email }) {
            return false
        }
        
        users.add(user)
        saveUsers(users)
        return true
    }
    
    fun loginUser(email: String, password: String): Boolean {
        val users = getAllUsers()
        return users.any { it.email == email && it.password == password }
    }
    
    fun getAllUsers(): List<User> {
        val usersJson = sharedPreferences.getString("users", "[]")
        val type = object : TypeToken<List<User>>() {}.type
        return gson.fromJson(usersJson, type) ?: emptyList()
    }
    
    private fun saveUsers(users: List<User>) {
        val usersJson = gson.toJson(users)
        sharedPreferences.edit().putString("users", usersJson).apply()
    }
}

