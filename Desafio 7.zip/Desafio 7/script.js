document.addEventListener('DOMContentLoaded', function() {
    const listaCompras = {
        frutas: [],
        laticinios: [],
        congelados: [],
        doces: [],
        outros: []
    };

    const itemInput = document.getElementById('item');
    const categoriaSelect = document.getElementById('categoria');
    const adicionarBtn = document.getElementById('adicionar');
    const limparBtn = document.getElementById('limpar');
    const listaContainer = document.getElementById('lista-compras');

    // Adiciona um item à lista
    adicionarBtn.addEventListener('click', function() {
        const item = itemInput.value.trim();
        const categoria = categoriaSelect.value;

        if (item) {
            listaCompras[categoria].push(item);
            itemInput.value = '';
            atualizarLista();
        } else {
            alert('Por favor, digite um item válido!');
        }
    });

    // Limpa toda a lista
    limparBtn.addEventListener('click', function() {
        if (confirm('Tem certeza que deseja limpar toda a lista de compras?')) {
            for (const categoria in listaCompras) {
                listaCompras[categoria] = [];
            }
            atualizarLista();
        }
    });

    // Atualiza a exibição da lista
    function atualizarLista() {
        // Verifica se há itens na lista
        const hasItems = Object.values(listaCompras).some(categoria => categoria.length > 0);
        
        if (!hasItems) {
            listaContainer.innerHTML = '<p class="empty-message">Sua lista está vazia. Adicione itens acima!</p>';
            return;
        }

        let html = '';

        for (const categoria in listaCompras) {
            if (listaCompras[categoria].length > 0) {
                // Formata o nome da categoria (primeira letra maiúscula)
                const nomeCategoria = categoria.charAt(0).toUpperCase() + categoria.slice(1);
                
                html += `
                    <div class="categoria">
                        <h3>${nomeCategoria}</h3>
                        <div class="itens">
                            ${listaCompras[categoria].map(item => `
                                <div class="item">
                                    ${item}
                                    <button onclick="removerItem('${categoria}', '${item.replace(/'/g, "\\'")}')">×</button>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
            }
        }

        listaContainer.innerHTML = html;
    }

    // Função global para remover itens (precisa estar no escopo global para ser chamada pelo HTML)
    window.removerItem = function(categoria, item) {
        listaCompras[categoria] = listaCompras[categoria].filter(i => i !== item);
        atualizarLista();
    };

    // Permite adicionar itens pressionando Enter
    itemInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            adicionarBtn.click();
        }
    });
});