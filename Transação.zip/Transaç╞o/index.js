const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const port = 3000;
const JWT_SECRET = 'seu-segredo-super-secreto-aqui'; // Em produção, use variáveis de ambiente!

app.use(express.json());

// --- Configuração do Banco de Dados SQLite ---
const db = new sqlite3.Database('./database.db', (err) => {
    if (err) {
        console.error("Erro ao abrir o banco de dados:", err.message);
    } else {
        console.log('Conectado ao banco de dados SQLite.');
        // Cria as tabelas se não existirem
        db.serialize(() => {
            db.run(`CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                senha TEXT NOT NULL
            )`);
            db.run(`CREATE TABLE IF NOT EXISTS transacoes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                descricao TEXT NOT NULL,
                valor REAL NOT NULL,
                tipo TEXT NOT NULL CHECK(tipo IN ('credito', 'debito')),
                data DATETIME DEFAULT CURRENT_TIMESTAMP,
                usuario_id INTEGER,
                FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
            )`);
        });
    }
});

// --- Middleware de Autenticação ---
function autenticarToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(401); // Não autorizado

    jwt.verify(token, JWT_SECRET, (err, usuario) => {
        if (err) return res.sendStatus(403); // Token inválido/expirado
        req.usuario = usuario;
        next();
    });
}

// --- Rotas de Autenticação ---

// [POST] /api/registrar - Registrar novo usuário
app.post('/api/registrar', async (req, res) => {
    const { email, senha } = req.body;
    if (!email || !senha) {
        return res.status(400).json({ erro: 'Email e senha são obrigatórios.' });
    }

    const salt = await bcrypt.genSalt(10);
    const senhaHash = await bcrypt.hash(senha, salt);

    const sql = `INSERT INTO usuarios (email, senha) VALUES (?, ?)`;
    db.run(sql, [email, senhaHash], function(err) {
        if (err) {
            return res.status(500).json({ erro: 'Erro ao registrar usuário. O email talvez já exista.' });
        }
        res.status(201).json({ id: this.lastID, email: email });
    });
});

// [POST] /api/login - Fazer login
app.post('/api/login', (req, res) => {
    const { email, senha } = req.body;
    if (!email || !senha) {
        return res.status(400).json({ erro: 'Email e senha são obrigatórios.' });
    }

    const sql = `SELECT * FROM usuarios WHERE email = ?`;
    db.get(sql, [email], async (err, usuario) => {
        if (err || !usuario) {
            return res.status(404).json({ erro: 'Usuário não encontrado.' });
        }

        const senhaValida = await bcrypt.compare(senha, usuario.senha);
        if (!senhaValida) {
            return res.status(401).json({ erro: 'Senha inválida.' });
        }

        // Gerar Token JWT
        const token = jwt.sign({ id: usuario.id, email: usuario.email }, JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    });
});


// --- Rotas de Transações (Protegidas) ---

// [POST] /api/transacoes
app.post('/api/transacoes', autenticarToken, (req, res) => {
    const { descricao, valor, tipo } = req.body;
    const usuario_id = req.usuario.id;

    // Validações
    if (!descricao || !valor || !tipo) {
        return res.status(400).json({ erro: 'Descrição, valor e tipo são obrigatórios.' });
    }
    if (tipo !== 'credito' && tipo !== 'debito') {
        return res.status(400).json({ erro: 'Tipo deve ser "credito" ou "debito".' });
    }

    const sql = `INSERT INTO transacoes (descricao, valor, tipo, usuario_id) VALUES (?, ?, ?, ?)`;
    db.run(sql, [descricao, valor, tipo, usuario_id], function(err) {
        if (err) {
            return res.status(500).json({ erro: 'Erro ao criar transação.' });
        }
        res.status(201).json({ id: this.lastID, descricao, valor, tipo });
    });
});

// [GET] /api/transacoes
app.get('/api/transacoes', autenticarToken, (req, res) => {
    const usuario_id = req.usuario.id;
    const sql = `SELECT * FROM transacoes WHERE usuario_id = ? ORDER BY data DESC`;

    db.all(sql, [usuario_id], (err, rows) => {
        if (err) {
            return res.status(500).json({ erro: 'Erro ao buscar transações.' });
        }
        res.json(rows);
    });
});

// [GET] /api/saldo
app.get('/api/saldo', autenticarToken, (req, res) => {
    const usuario_id = req.usuario.id;
    const sql = `SELECT 
                    COALESCE(SUM(CASE WHEN tipo = 'credito' THEN valor ELSE 0 END), 0) as creditos,
                    COALESCE(SUM(CASE WHEN tipo = 'debito' THEN valor ELSE 0 END), 0) as debitos
                 FROM transacoes WHERE usuario_id = ?`;

    db.get(sql, [usuario_id], (err, row) => {
        if (err) {
            return res.status(500).json({ erro: 'Erro ao calcular saldo.' });
        }
        const saldo = row.creditos - row.debitos;
        res.json({ saldo: saldo });
    });
});


// --- Iniciar Servidor ---
app.listen(port, () => {
    console.log(`Servidor da API de Transações rodando em http://localhost:${port}`);
});