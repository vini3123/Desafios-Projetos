const HISTORY_KEY = 'marketingGen_history';
const FAVORITES_KEY = 'marketingGen_favorites';
const THEME_KEY = 'marketingGen_theme';

/**
 * Retrieves data from localStorage and parses it as JSON.
 * @param {string} key The key to retrieve.
 * @returns {any} The parsed data or null if not found.
 */
function getJSON(key) {
    try {
        const value = localStorage.getItem(key);
        return value ? JSON.parse(value) : null;
    } catch (error) {
        console.error(`Error getting JSON from localStorage for key "${key}":`, error);
        return null;
    }
}

/**
 * Saves data to localStorage as a JSON string.
 * @param {string} key The key to save.
 * @param {any} value The value to save.
 */
function setJSON(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
        console.error(`Error setting JSON to localStorage for key "${key}":`, error);
    }
}

// --- History ---
export function getHistory() {
    return getJSON(HISTORY_KEY) || [];
}

export function saveHistory(historyArray) {
    setJSON(HISTORY_KEY, historyArray);
}

// --- Favorites ---
export function getFavorites() {
    return getJSON(FAVORITES_KEY) || [];
}

export function saveFavorites(favoritesArray) {
    setJSON(FAVORITES_KEY, favoritesArray);
}

// --- Theme ---
export function getTheme() {
    return localStorage.getItem(THEME_KEY);
}

export function saveTheme(themeString) {
    localStorage.setItem(THEME_KEY, themeString);
}
