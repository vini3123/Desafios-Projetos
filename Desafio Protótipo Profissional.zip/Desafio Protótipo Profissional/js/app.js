import * as storage from './storage.js';
import * as ui from './ui.js';
import * as generator from './generator.js';

// --- Application State ---
let state = {
    history: [],
    favorites: [],
    theme: 'light',
};

// --- Event Handlers ---

function handleThemeToggle() {
    state.theme = ui.toggleTheme();
    storage.saveTheme(state.theme);
}

function handleTabClick(event) {
    event.preventDefault();
    const link = event.target.closest('.nav-link');
    if (!link) return;

    const tabName = link.dataset.tab;
    ui.switchTab(tabName);
    // Re-render content when switching tabs to ensure it's up to date
    if (tabName === 'history') {
        ui.renderHistory(state.history, state.favorites);
    } else if (tabName === 'favorites') {
        ui.renderFavorites(state.favorites);
    }
}

async function handleFormSubmit(event) {
    event.preventDefault();
    const formValues = ui.getFormValues();
    
    ui.showLoading();
    
    const results = await generator.generate(formValues);
    const newEntries = results.map(text => ({ id: Date.now() + Math.random(), text }));

    // Add to history (most recent first)
    state.history.unshift(...newEntries);
    // Optional: Limit history size
    if (state.history.length > 50) {
        state.history.length = 50;
    }
    storage.saveHistory(state.history);
    
    ui.hideLoading();
    ui.renderResults(newEntries, state.favorites);
}

function handleCardAction(event) {
    const button = event.target.closest('[data-action]');
    if (!button) return;

    const card = button.closest('.result-card');
    const id = parseFloat(card.dataset.id);
    const text = card.querySelector('.card-text').innerText;
    const action = button.dataset.action;

    if (action === 'copy') {
        navigator.clipboard.writeText(text).then(() => {
            button.innerHTML = '<i class="bi bi-check-all me-1"></i> Copiado!';
            setTimeout(() => {
                button.innerHTML = '<i class="bi bi-clipboard-check-fill me-1"></i> Copiar';
            }, 2000);
        });
    } else if (action === 'favorite') {
        const existingIndex = state.favorites.findIndex(fav => fav.text === text);
        
        if (existingIndex > -1) {
            // Unfavorite
            state.favorites.splice(existingIndex, 1);
            ui.updateFavoriteIcon(card, false);
        } else {
            // Favorite
            state.favorites.unshift({ id, text });
            ui.updateFavoriteIcon(card, true);
        }
        storage.saveFavorites(state.favorites);
    }
}

// --- Initialization ---

function init() {
    // Load state from storage
    state.theme = storage.getTheme() || 'light';
    state.history = storage.getHistory();
    state.favorites = storage.getFavorites();

    // Apply initial UI settings
    ui.applyTheme(state.theme);
    ui.switchTab('generator'); // Start on the generator tab
    ui.renderResults([], state.favorites); // Initially empty results

    // Set up event listeners
    document.getElementById('theme-toggle').addEventListener('click', handleThemeToggle);
    document.getElementById('main-tabs').addEventListener('click', handleTabClick);
    document.getElementById('generator-form').addEventListener('submit', handleFormSubmit);

    // Use event delegation for card actions
    document.getElementById('tab-content').addEventListener('click', handleCardAction);
}

// --- Run Application ---
init();
