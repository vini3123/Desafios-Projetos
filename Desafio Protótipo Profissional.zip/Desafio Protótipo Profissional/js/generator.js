// --- Vocabulary Banks ---

const adjectives = {
    profissional: ['eficiente', 'inovador', 'confiável', 'integrado', 'otimizado'],
    divertido: ['incrível', 'fantástico', 'mágico', 'alucinante', 'surpreendente'],
    urgente: ['essencial', 'imediato', 'indispensável', 'único', 'limitado'],
    inspirador: ['revolucionário', 'transformador', 'inspirador', 'visionário', 'poderoso'],
};

const nouns = {
    produto: 'solução',
    servico: 'experiência',
    app: 'plataforma',
};

const ctas = {
    instagram: ['Toque no link da bio!', 'Compre agora!', 'Saiba mais!', '#lançamento'],
    facebook: ['Clique em "Saiba Mais" para descobrir!', 'Garanta o seu hoje mesmo!', 'Visite nosso site!'],
    email: ['Clique aqui para aproveitar.', 'Não perca esta oportunidade.', 'Compre agora com um clique.'],
    blog: ['Leia o artigo completo em nosso site.', 'Deixe seu comentário abaixo!', 'Compartilhe sua opinião!'],
};

// --- Template Engine ---

/**
 * Generates an array of marketing copy based on user inputs.
 * @param {object} options - The user's input.
 * @param {string} options.productName
 * @param {string} options.targetAudience
 * @param {string} options.keywords
 * @param {string} options.tone
 * @param {string} options.platform
 * @returns {Promise<string[]>} A promise that resolves to an array of generated strings.
 */
export function generate(options) {
    return new Promise(resolve => {
        // Simula o tempo de geração
        setTimeout(() => {
            const results = [];
            const { productName, targetAudience, keywords, tone, platform } = options;
            const kwArray = keywords.split(',').map(k => k.trim()).filter(Boolean);

            const adj = adjectives[tone] || adjectives.profissional;
            const cta = ctas[platform] || ctas.instagram;

            // Template 1: Simple and direct
            results.push(`Descubra ${productName}: a ${nouns.produto} ${adj[0]} para ${targetAudience}. ${cta[0]}`);

            // Template 2: Focus on benefit
            results.push(`Você, que é ${targetAudience}, precisa ver como ${productName} é ${adj[1]}. Transforme sua rotina! ${cta[1]}`);

            // Template 3: Using a keyword
            if (kwArray.length > 0) {
                results.push(`O novo ${productName} é simplesmente ${adj[2]}. Com foco em ${kwArray[0]}, ele redefine o mercado. ${cta[2]}`);
            } else {
                results.push(`O ${productName} é a escolha ${adj[2]} para quem busca qualidade. Não fique de fora! ${cta[2]}`);
            }

            // Template 4: More descriptive
            results.push(`Eleve sua experiência com ${productName}. Uma ${nouns.produto} ${adj[3]} e ${adj[4]}, pensada para ${targetAudience}. ${cta[3] || cta[0]}`);
            
            // Template 5: For blog post title
            if (platform === 'blog') {
                results.push(`Título: 5 maneiras como ${productName} vai mudar a vida de ${targetAudience}`);
                results.push(`Introdução: Em um mundo onde ${kwArray[0] || 'a tecnologia'} avança, ${productName} surge como uma solução ${adj[0]} e ${adj[1]}. Descubra neste post por que ele é ${adj[3]} para você.`);
            }

            resolve(results);
        }, 1500); // 1.5 second delay
    });
}
