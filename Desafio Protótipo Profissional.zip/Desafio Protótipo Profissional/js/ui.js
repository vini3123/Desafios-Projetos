// --- Element Selectors ---
const themeToggle = document.getElementById('theme-toggle');
const mainTabs = document.getElementById('main-tabs');
const tabContent = document.getElementById('tab-content');
const loadingSpinner = document.getElementById('loading-spinner');
const resultsContainer = document.getElementById('results-container');
const historyContainer = document.getElementById('history-container');
const favoritesContainer = document.getElementById('favorites-container');
const generatorForm = document.getElementById('generator-form');

// --- Theme Management ---

export function applyTheme(theme) {
    if (theme === 'dark') {
        document.body.classList.add('dark-mode');
        themeToggle.innerHTML = '<i class="bi bi-sun-fill"></i>';
    } else {
        document.body.classList.remove('dark-mode');
        themeToggle.innerHTML = '<i class="bi bi-moon-stars-fill"></i>';
    }
}

export function toggleTheme() {
    const isDarkMode = document.body.classList.contains('dark-mode');
    applyTheme(isDarkMode ? 'light' : 'dark');
    return isDarkMode ? 'light' : 'dark';
}

// --- Tab Management ---

export function switchTab(tabName) {
    // Update active link
    mainTabs.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.dataset.tab === tabName) {
            link.classList.add('active');
        }
    });

    // Update active content
    tabContent.querySelectorAll('.tab-pane').forEach(pane => {
        pane.classList.remove('active');
        if (pane.id === `${tabName}-tab`) {
            pane.classList.add('active');
        }
    });
}

// --- Content Rendering ---

function createCard(text, id, isFavorite = false) {
    const favClass = isFavorite ? 'favorited' : '';
    const favIcon = isFavorite ? 'bi-star-fill' : 'bi-star';
    return `
        <div class="card result-card mb-3" data-id="${id}">
            <div class="card-body result-card-body">
                <p class="card-text">${text}</p>
                <div class="d-flex justify-content-end result-card-actions">
                    <button class="btn btn-sm btn-outline-secondary me-2" data-action="copy">
                        <i class="bi bi-clipboard-check-fill me-1"></i> Copiar
                    </button>
                    <button class="btn btn-sm btn-outline-warning ${favClass}" data-action="favorite">
                        <i class="bi ${favIcon}"></i>
                    </button>
                </div>
            </div>
        </div>
    `;
}

export function renderResults(results, favorites) {
    if (results.length === 0) {
        resultsContainer.innerHTML = '<p class="text-center text-muted">Nenhum resultado gerado ainda.</p>';
        return;
    }
    const favoritesSet = new Set(favorites.map(fav => fav.text));
    resultsContainer.innerHTML = results.map(result => {
        const isFavorite = favoritesSet.has(result.text);
        return createCard(result.text, result.id, isFavorite);
    }).join('');
}

export function renderHistory(history, favorites) {
    if (history.length === 0) {
        historyContainer.innerHTML = '<p class="text-center text-muted">Seu histórico está vazio.</p>';
        return;
    }
    const favoritesSet = new Set(favorites.map(fav => fav.text));
    historyContainer.innerHTML = history.map(item => {
        const isFavorite = favoritesSet.has(item.text);
        return createCard(item.text, item.id, isFavorite);
    }).join('');
}

export function renderFavorites(favorites) {
    if (favorites.length === 0) {
        favoritesContainer.innerHTML = '<p class="text-center text-muted">Você ainda não favoritou nenhum item.</p>';
        return;
    }
    favoritesContainer.innerHTML = favorites.map(item => createCard(item.text, item.id, true)).join('');
}

export function updateFavoriteIcon(cardElement, isFavorite) {
    const button = cardElement.querySelector('[data-action="favorite"]');
    const icon = button.querySelector('i');
    if (isFavorite) {
        button.classList.add('favorited');
        icon.classList.remove('bi-star');
        icon.classList.add('bi-star-fill');
    } else {
        button.classList.remove('favorited');
        icon.classList.remove('bi-star-fill');
        icon.classList.add('bi-star');
    }
}


// --- UI State ---

export function showLoading() {
    loadingSpinner.classList.remove('d-none');
    resultsContainer.innerHTML = '';
}

export function hideLoading() {
    loadingSpinner.classList.add('d-none');
}

export function getFormValues() {
    return {
        productName: generatorForm.elements['product-name'].value,
        targetAudience: generatorForm.elements['target-audience'].value,
        keywords: generatorForm.elements['keywords'].value,
        tone: generatorForm.elements['tone-of-voice'].value,
        platform: generatorForm.elements['platform'].value,
    };
}
