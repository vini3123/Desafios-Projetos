import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def analyze_and_plot_boxplots(file_path='dados_emprestimos.csv'):
    # Carregar os dados
    df = pd.read_csv(file_path)

    # Filtrar dados para o período de 2010 a 2020
    df = df[(df['Ano'] >= 2010) & (df['Ano'] <= 2020)]

    # Converter 'Ano' para string para garantir que o seaborn trate como categoria
    df['Ano'] = df['Ano'].astype(str)

    # Identificar a coleção com maior frequência para cada tipo de usuário
    # Para Graduação
    graduacao_df = df[df['Tipo_Usuario'] == 'Graduacao']
    colecao_graduacao = graduacao_df['Colecao'].mode()[0]
    print(f"Coleção mais frequente para Graduação: {colecao_graduacao}")

    # Para Pós-Graduação
    pos_graduacao_df = df[df['Tipo_Usuario'] == 'Pos-Graduacao']
    colecao_pos_graduacao = pos_graduacao_df['Colecao'].mode()[0]
    print(f"Coleção mais frequente para Pós-Graduação: {colecao_pos_graduacao}")

    # Filtrar os dados para as coleções mais frequentes
    df_graduacao_filtered = graduacao_df[graduacao_df['Colecao'] == colecao_graduacao]
    df_pos_graduacao_filtered = pos_graduacao_df[pos_graduacao_df['Colecao'] == colecao_pos_graduacao]

    # Fazer a contagem de empréstimos mensais por cada ano (já está implícito na estrutura do CSV)
    # A coluna 'Emprestimos' já representa a contagem mensal

    # Função para gerar o boxplot
    def generate_boxplot(data, user_type, collection_name):
        plt.figure(figsize=(12, 7))
        sns.boxplot(x='Ano', y='Emprestimos', data=data, palette='viridis')
        plt.title(f'Distribuição de Empréstimos Mensais por Ano para {user_type} (Coleção: {collection_name})')
        plt.xlabel('Ano')
        plt.ylabel('Número de Empréstimos Mensais')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        plt.savefig(f'boxplot_{user_type.lower().replace(" ", "_").replace("-", "_")}.png')
        plt.show()

    # Gerar boxplots para cada tipo de usuário
    generate_boxplot(df_graduacao_filtered, 'Alunos de Graduação', colecao_graduacao)
    generate_boxplot(df_pos_graduacao_filtered, 'Alunos de Pós-Graduação', colecao_pos_graduacao)

    print("Análise e geração de boxplots concluídas. Verifique os arquivos PNG gerados.")

if __name__ == '__main__':
    analyze_and_plot_boxplots()


