class DataService {
    constructor() {
        this.baseUrl = 'data/sampleData.json';
        this.realtimeUrl = 'data/realtimeMock.js';
    }

    async fetchData(url) {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    }

    async getStats() {
        const data = await this.fetchData(this.baseUrl);
        return data.stats;
    }

    async getChartData(chartType, period = '30days') {
        const data = await this.fetchData(this.baseUrl);
        return data.charts[chartType][period];
    }

    async getTransactions(page = 1, pageSize = 10) {
        const data = await this.fetchData(this.baseUrl);
        const start = (page - 1) * pageSize;
        const end = start + pageSize;
        const paginatedData = data.transactions.slice(start, end);
        
        return {
            transactions: paginatedData,
            totalPages: Math.ceil(data.transactions.length / pageSize),
            currentPage: page
        };
    }

    async getTransactionDetails(id) {
        const data = await this.fetchData(this.baseUrl);
        return data.transactions.find(t => t.id === id);
    }

    exportTransactionsToCSV() {
        // In a real app, this would generate a CSV file
        console.log('Exporting transactions to CSV...');
        // Mock implementation
        const link = document.createElement('a');
        link.href = 'data:text/csv;charset=utf-8,ID,Cliente,Data,Valor,Status\n' +
                    '1,John Doe,2023-05-15,125.00,completed\n' +
                    '2,Jane Smith,2023-05-16,89.50,pending';
        link.download = 'transactions_export.csv';
        link.click();
    }

    startRealtimeUpdates(callback) {
        // Simulate realtime updates
        this.realtimeInterval = setInterval(() => {
            const randomUpdate = {
                id: Math.floor(Math.random() * 1000),
                type: ['sale', 'user', 'pageview'][Math.floor(Math.random() * 3)],
                value: Math.floor(Math.random() * 100) + 1,
                timestamp: new Date().toISOString()
            };
            callback(randomUpdate);
        }, 3000);

        return () => clearInterval(this.realtimeInterval);
    }
}