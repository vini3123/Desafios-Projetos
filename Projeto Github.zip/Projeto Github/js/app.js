// Main Application Module
class DataVisionApp {
    constructor() {
        this.init();
    }

    init() {
        // Initialize all modules
        this.ui = new UIComponents();
        this.dataService = new DataService();
        this.chartRenderer = new ChartRenderer();
        
        // Load initial data
        this.loadData();
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Check for preferred theme
        this.checkThemePreference();
    }

    loadData() {
        // Load stats data
        this.dataService.getStats()
            .then(stats => {
                this.updateStatsCards(stats);
            })
            .catch(error => {
                console.error('Error loading stats:', error);
                this.ui.showNotification('Failed to load statistics', 'error');
            });

        // Load chart data
        this.dataService.getChartData('monthlySales')
            .then(data => {
                this.chartRenderer.renderLineChart('monthlySalesChart', data);
            });

        this.dataService.getChartData('regionDistribution')
            .then(data => {
                this.chartRenderer.renderDoughnutChart('regionDistributionChart', data);
            });

        // Load transactions
        this.loadTransactions(1);
    }

    updateStatsCards(stats) {
        document.getElementById('total-users').textContent = stats.totalUsers.toLocaleString();
        // Update other stats similarly...
    }

    loadTransactions(page) {
        this.dataService.getTransactions(page)
            .then(data => {
                this.renderTransactions(data.transactions);
                this.updatePagination(data.totalPages, page);
            })
            .catch(error => {
                console.error('Error loading transactions:', error);
                this.ui.showNotification('Failed to load transactions', 'error');
            });
    }

    renderTransactions(transactions) {
        const tbody = document.getElementById('transactions-body');
        tbody.innerHTML = '';

        transactions.forEach(transaction => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${transaction.id}</td>
                <td>
                    <div class="user-cell">
                        <img src="assets/img/users/${transaction.userImage}" alt="${transaction.user}" width="30" height="30">
                        <span>${transaction.user}</span>
                    </div>
                </td>
                <td>${new Date(transaction.date).toLocaleDateString()}</td>
                <td>$${transaction.amount.toFixed(2)}</td>
                <td><span class="status-badge ${transaction.status}">${transaction.statusText}</span></td>
                <td>
                    <button class="btn-action view-details" data-id="${transaction.id}">
                        <i class="icon-eye"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });

        // Add event listeners to detail buttons
        document.querySelectorAll('.view-details').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const transactionId = e.currentTarget.getAttribute('data-id');
                this.showTransactionDetails(transactionId);
            });
        });
    }

    updatePagination(totalPages, currentPage) {
        const pageInfo = document.querySelector('.page-info');
        const prevBtn = document.querySelector('.page-btn.prev');
        const nextBtn = document.querySelector('.page-btn.next');

        pageInfo.textContent = `Página ${currentPage} de ${totalPages}`;
        
        prevBtn.disabled = currentPage === 1;
        nextBtn.disabled = currentPage === totalPages;

        // Update event listeners
        prevBtn.onclick = () => this.loadTransactions(currentPage - 1);
        nextBtn.onclick = () => this.loadTransactions(currentPage + 1);
    }

    showTransactionDetails(transactionId) {
        this.dataService.getTransactionDetails(transactionId)
            .then(details => {
                const modalBody = document.querySelector('.modal-body');
                modalBody.innerHTML = `
                    <div class="detail-row">
                        <span class="detail-label">ID:</span>
                        <span class="detail-value">${details.id}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Cliente:</span>
                        <span class="detail-value">${details.user}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Data:</span>
                        <span class="detail-value">${new Date(details.date).toLocaleString()}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Valor:</span>
                        <span class="detail-value">$${details.amount.toFixed(2)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status:</span>
                        <span class="detail-value"><span class="status-badge ${details.status}">${details.statusText}</span></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Método de Pagamento:</span>
                        <span class="detail-value">${details.paymentMethod}</span>
                    </div>
                    <div class="detail-row full">
                        <span class="detail-label">Descrição:</span>
                        <span class="detail-value">${details.description}</span>
                    </div>
                `;
                this.ui.openModal('details-modal');
            })
            .catch(error => {
                console.error('Error loading transaction details:', error);
                this.ui.showNotification('Failed to load transaction details', 'error');
            });
    }

    checkThemePreference() {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const savedTheme = localStorage.getItem('theme');
        
        if (savedTheme) {
            document.body.classList.add(savedTheme + '-theme');
        } else if (prefersDark) {
            document.body.classList.add('dark-theme');
        }
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', () => {
                const section = item.getAttribute('data-section');
                this.ui.switchSection(section);
            });
        });

        // Menu toggle for mobile
        document.querySelector('.menu-toggle').addEventListener('click', () => {
            this.ui.toggleMobileMenu();
        });

        // Theme switcher
        document.querySelector('.theme-switcher').addEventListener('click', () => {
            this.ui.toggleTheme();
        });

        // Time filter for charts
        document.querySelector('.time-filter').addEventListener('change', (e) => {
            const period = e.target.value;
            this.updateChartData('monthlySalesChart', period);
        });

        // Export button
        document.querySelector('.btn-export').addEventListener('click', () => {
            this.dataService.exportTransactionsToCSV();
        });

        // Modal close button
        document.querySelector('.modal-close').addEventListener('click', () => {
            this.ui.closeModal('details-modal');
        });
    }

    updateChartData(chartId, period) {
        this.dataService.getChartData('monthlySales', period)
            .then(data => {
                this.chartRenderer.updateChartData(chartId, data);
            })
            .catch(error => {
                console.error('Error updating chart data:', error);
                this.ui.showNotification('Failed to update chart data', 'error');
            });
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const app = new DataVisionApp();
});