class UIComponents {
    constructor() {
        this.activeSection = 'dashboard';
    }

    switchSection(sectionId) {
        // Hide current active section
        document.querySelector(`.${this.activeSection}-section`).classList.remove('active');
        document.querySelector(`[data-section="${this.activeSection}"]`).classList.remove('active');
        
        // Show new section
        document.querySelector(`.${sectionId}-section`).classList.add('active');
        document.querySelector(`[data-section="${sectionId}"]`).classList.add('active');
        
        // Update active section
        this.activeSection = sectionId;
        
        // Update page title
        document.querySelector('.page-title').textContent = this.getSectionTitle(sectionId);
    }

    getSectionTitle(sectionId) {
        const titles = {
            dashboard: 'Dashboard Analítico',
            realtime: 'Dados em Tempo Real',
            reports: 'Relatórios Personalizados',
            settings: 'Configurações'
        };
        return titles[sectionId] || 'Dashboard';
    }

    toggleMobileMenu() {
        document.querySelector('.sidebar').classList.toggle('active');
        document.querySelector('.menu-toggle').classList.toggle('active');
    }

    toggleTheme() {
        document.body.classList.toggle('dark-theme');
        
        const isDark = document.body.classList.contains('dark-theme');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
    }

    openModal(modalId) {
        document.getElementById(modalId).classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    closeModal(modalId) {
        document.getElementById(modalId).classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    createTooltip(element, content) {
        const tooltip = document.createElement('div');
        tooltip.className = 'tooltip';
        tooltip.textContent = content;
        
        document.body.appendChild(tooltip);
        
        const updatePosition = () => {
            const rect = element.getBoundingClientRect();
            tooltip.style.left = `${rect.left + rect.width / 2 - tooltip.offsetWidth / 2}px`;
            tooltip.style.top = `${rect.top - tooltip.offsetHeight - 10}px`;
        };
        
        element.addEventListener('mouseenter', () => {
            tooltip.classList.add('visible');
            updatePosition();
        });
        
        element.addEventListener('mouseleave', () => {
            tooltip.classList.remove('visible');
        });
        
        window.addEventListener('scroll', updatePosition);
        window.addEventListener('resize', updatePosition);
        
        return {
            destroy: () => {
                document.body.removeChild(tooltip);
                element.removeEventListener('mouseenter', updatePosition);
                element.removeEventListener('mouseleave', updatePosition);
                window.removeEventListener('scroll', updatePosition);
                window.removeEventListener('resize', updatePosition);
            }
        };
    }
}