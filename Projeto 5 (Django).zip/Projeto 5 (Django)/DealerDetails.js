import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';

const DealerDetails = () => {
  const { id } = useParams();
  const [dealer, setDealer] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch dealer details
        const dealerResponse = await fetch(`/api/dealers/${id}`);
        const dealerData = await dealerResponse.json();
        setDealer(dealerData);
        
        // Fetch reviews for this dealer
        const reviewsResponse = await fetch(`/api/reviews?dealer_id=${id}`);
        const reviewsData = await reviewsResponse.json();
        setReviews(reviewsData);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [id]);

  if (loading) return <div>Loading...</div>;
  if (!dealer) return <div>Dealer not found</div>;

  return (
    <div className="dealer-details">
      <h2>{dealer.name}</h2>
      <div className="dealer-info">
        <p><strong>Address:</strong> {dealer.address}, {dealer.city}, {dealer.state} {dealer.zip}</p>
        <p><strong>Phone:</strong> {dealer.phone}</p>
        {dealer.website && <p><strong>Website:</strong> <a href={dealer.website} target="_blank" rel="noopener noreferrer">{dealer.website}</a></p>}
      </div>
      
      <div className="reviews-section">
        <h3>Customer Reviews</h3>
        <Link to={`/dealers/${id}/add-review`} className="add-review-btn">
          Add Your Review
        </Link>
        
        {reviews.length === 0 ? (
          <p>No reviews yet. Be the first to review!</p>
        ) : (
          <div className="reviews-list">
            {reviews.map(review => (
              <div key={review.id} className="review-card">
                <div className="review-header">
                  <span className="review-author">{review.name}</span>
                  <span className="review-rating">Rating: {review.rating}/5</span>
                </div>
                <p className="review-text">{review.review}</p>
                <p className="review-date">{new Date(review.date).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default DealerDetails;