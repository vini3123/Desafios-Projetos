import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import DealershipList from './components/DealershipList';
import DealerDetails from './components/DealerDetails';
import AddReview from './components/AddReview';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <header>
          <h1>Car Dealerships</h1>
        </header>
        
        <main>
          <Routes>
            <Route path="/" element={<DealershipList />} />
            <Route path="/dealers/:id" element={<DealerDetails />} />
            <Route path="/dealers/:id/add-review" element={<AddReview />} />
          </Routes>
        </main>
        
        <footer>
          <p>&copy; 2023 Car Dealership Reviews</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;