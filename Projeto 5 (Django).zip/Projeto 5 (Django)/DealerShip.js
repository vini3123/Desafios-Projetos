import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const DealershipList = () => {
  const [dealers, setDealers] = useState([]);
  const [filteredDealers, setFilteredDealers] = useState([]);
  const [states, setStates] = useState([]);
  const [selectedState, setSelectedState] = useState('all');

  useEffect(() => {
    // Fetch dealers from backend API
    const fetchDealers = async () => {
      const response = await fetch('/api/dealers');
      const data = await response.json();
      setDealers(data);
      setFilteredDealers(data);
      
      // Extract unique states
      const uniqueStates = [...new Set(data.map(dealer => dealer.state))];
      setStates(uniqueStates);
    };
    
    fetchDealers();
  }, []);

  useEffect(() => {
    if (selectedState === 'all') {
      setFilteredDealers(dealers);
    } else {
      setFilteredDealers(dealers.filter(dealer => dealer.state === selectedState));
    }
  }, [selectedState, dealers]);

  return (
    <div className="dealership-list">
      <h2>Dealerships</h2>
      
      <div className="filter-section">
        <label htmlFor="state-filter">Filter by State:</label>
        <select 
          id="state-filter" 
          value={selectedState}
          onChange={(e) => setSelectedState(e.target.value)}
        >
          <option value="all">All States</option>
          {states.map(state => (
            <option key={state} value={state}>{state}</option>
          ))}
        </select>
      </div>
      
      <div className="dealer-cards">
        {filteredDealers.map(dealer => (
          <div key={dealer.id} className="dealer-card">
            <h3>{dealer.name}</h3>
            <p>{dealer.city}, {dealer.state}</p>
            <p>{dealer.address}</p>
            <p>Phone: {dealer.phone}</p>
            <Link to={`/dealers/${dealer.id}`} className="details-link">
              View Details
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DealershipList;