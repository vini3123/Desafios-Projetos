document.addEventListener('DOMContentLoaded', function() {
    // Dados de exemplo (substitua por uma API real se necessário)
    const movies = [
        { id: '1', title: 'O Poderoso Chefão', year: '1972', poster: 'https://m.media-amazon.com/images/M/MV5BM2MyNjYxNmUtYTAwNi00MTYxLWJmNWYtYzZlODY3ZTk3OTFlXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg' },
        { id: '2', title: 'O Senhor dos Anéis: O Retorno do Rei', year: '2003', poster: 'https://m.media-amazon.com/images/M/MV5BNzA5ZDNlZWMtM2NhNS00NDJjLTk4NDItYTRmY2EwMWZlMTY3XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg' },
        { id: '3', title: 'Interestelar', year: '2014', poster: 'https://m.media-amazon.com/images/M/MV5BZjdkOTU3MDktN2IxOS00OGEyLWFmMjktY2FiMmZkNWIyODZiXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_.jpg' },
        { id: '4', title: 'Clube da Luta', year: '1999', poster: 'https://m.media-amazon.com/images/M/MV5BMmEzNTkxYjQtZTc0MC00YTVjLTg5ZTEtZWMwOWVlYzY0NWIwXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg' },
        { id: '5', title: 'Matrix', year: '1999', poster: 'https://m.media-amazon.com/images/M/MV5BNzQzOTk3OTAtNDQ0Zi00ZTVkLWI0MTEtMDllZjNkYzNjNTc4L2ltYWdlXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_.jpg' },
        { id: '6', title: 'Parasita', year: '2019', poster: 'https://m.media-amazon.com/images/M/MV5BYWZjMjk3ZTItODQ2ZC00NTY5LWE0ZDYtZTI3MjcwN2Q5NTVkXkEyXkFqcGdeQXVyODk4OTc3MTY@._V1_.jpg' },
        { id: '7', title: 'Cidade de Deus', year: '2002', poster: 'https://m.media-amazon.com/images/M/MV5BOTMwYjc5ZmItYTFjZC00ZGQ3LTlkNTMtMjZiNTZlMWQzNzI5XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg' },
        { id: '8', title: 'A Origem', year: '2010', poster: 'https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_.jpg' }
    ];

    const moviesContainer = document.getElementById('movies-container');
    const favoriteCheckbox = document.getElementById('favorite-checkbox');
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');

    // Carrega os filmes favoritos do localStorage
    let favoriteMovies = JSON.parse(localStorage.getItem('favoriteMovies')) || [];

    // Renderiza os filmes
    function renderMovies(moviesToRender) {
        moviesContainer.innerHTML = '';
        
        moviesToRender.forEach(movie => {
            const isFavorite = favoriteMovies.includes(movie.id);
            
            const movieElement = document.createElement('div');
            movieElement.className = 'movie';
            movieElement.dataset.id = movie.id;
            
            movieElement.innerHTML = `
                <img src="${movie.poster}" alt="${movie.title}" class="movie-poster">
                <div class="movie-info">
                    <h3 class="movie-title">${movie.title}</h3>
                    <p class="movie-year">${movie.year}</p>
                </div>
                <button class="favorite-button ${isFavorite ? 'favorited' : ''}">
                    <i class="fas fa-heart"></i>
                </button>
            `;
            
            moviesContainer.appendChild(movieElement);
        });
        
        // Adiciona eventos aos botões de favorito
        document.querySelectorAll('.favorite-button').forEach(button => {
            button.addEventListener('click', function() {
                const movieId = this.closest('.movie').dataset.id;
                toggleFavorite(movieId);
                
                // Atualiza a visualização se o filtro estiver ativo
                if (favoriteCheckbox.checked) {
                    showOnlyFavorites();
                }
            });
        });
    }

    // Alterna o status de favorito
    function toggleFavorite(movieId) {
        if (favoriteMovies.includes(movieId)) {
            favoriteMovies = favoriteMovies.filter(id => id !== movieId);
        } else {
            favoriteMovies.push(movieId);
        }
        
        localStorage.setItem('favoriteMovies', JSON.stringify(favoriteMovies));
        
        // Atualiza o ícone do botão
        const button = document.querySelector(`.movie[data-id="${movieId}"] .favorite-button`);
        if (button) {
            button.classList.toggle('favorited');
        }
    }

    // Mostra apenas os filmes favoritos
    function showOnlyFavorites() {
        const allMovies = document.querySelectorAll('.movie');
        
        allMovies.forEach(movie => {
            const movieId = movie.dataset.id;
            if (favoriteMovies.includes(movieId)) {
                movie.style.display = 'block';
            } else {
                movie.style.display = 'none';
            }
        });
    }

    // Mostra todos os filmes
    function showAllMovies() {
        document.querySelectorAll('.movie').forEach(movie => {
            movie.style.display = 'block';
        });
    }

    // Filtra os filmes por título
    function filterMovies(searchTerm) {
        const filtered = movies.filter(movie => 
            movie.title.toLowerCase().includes(searchTerm.toLowerCase())
        );
        renderMovies(filtered);
        
        // Mantém o estado do filtro de favoritos
        if (favoriteCheckbox.checked) {
            showOnlyFavorites();
        }
    }

    // Event listeners
    favoriteCheckbox.addEventListener('change', function() {
        if (this.checked) {
            showOnlyFavorites();
        } else {
            showAllMovies();
        }
    });

    searchButton.addEventListener('click', () => {
        filterMovies(searchInput.value);
    });

    searchInput.addEventListener('keyup', (e) => {
        if (e.key === 'Enter') {
            filterMovies(searchInput.value);
        }
    });

    // Renderiza os filmes inicialmente
    renderMovies(movies);
});