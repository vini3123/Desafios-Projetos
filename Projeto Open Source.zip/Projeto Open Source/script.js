document.addEventListener('DOMContentLoaded', () => {

    // --- ProductManager Module ---
    const ProductManager = (() => {
        const products = [
            { id: 1, name: 'Smart TV 4K 50"', price: 2500.00, image: 'https://imgs.via.com.br/special-contents/9747e6fd-ae02-45bb-8e76-4adcbc883e43/b32df616-3823-4601-bb64-5c8d9cb1b8c2.jpg', category: 'Eletrônicos', description: 'Uma televisão inteligente com resolução 4K para uma experiência visual imersiva e cores vibrantes.' },
            { id: 2, name: 'Smartphone Pro X', price: 1800.00, image: 'https://imgs.casasbahia.com.br/1571075540/1xg.jpg', category: 'Eletrônicos', description: 'O mais recente smartphone com câmera avançada, processador ultra-rápido e design elegante.' },
            { id: 3, name: 'Fone Bluetooth Premium', price: 300.00, image: 'https://down-br.img.susercontent.com/file/br-11134207-7qukw-lhuktnozns6v79', category: 'Acessórios', description: 'Fones de ouvido sem fio com cancelamento de ruído ativo e áudio de alta fidelidade para imersão total.' },
            { id: 4, name: 'Notebook Ultrafino', price: 3500.00, image: 'https://blog.bbbaterias.com.br/wp-content/uploads/2024/07/image_4-notebook-ultrafino.jpg', category: 'Eletrônicos', description: 'Portátil e potente, ideal para produtividade e entretenimento em qualquer lugar, com tela Full HD.' },
            { id: 5, name: 'Smartwatch Fitness', price: 450.00, image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLfgJktuUNZOq4_q7kchvBqFpaH5OX0YQgaw&s', category: 'Wearables', description: 'Monitore sua saúde, batimentos cardíacos, sono e atividades físicas com um design moderno.' },
            { id: 6, name: 'Câmera Digital HD', price: 1200.00, image: 'https://m.media-amazon.com/images/I/612JKMqZttL._AC_UF894,1000_QL80_.jpg', category: 'Eletrônicos', description: 'Capture fotos e vídeos incríveis em alta definição com facilidade e recursos profissionais.' },
            { id: 7, name: 'Mouse Gamer RGB', price: 150.00, image: 'https://images.tcdn.com.br/img/img_prod/1008764/mouse_gamer_rgb_7_botoes_c_fio_kp_mu007_7575_1_43e106fcf62616a5149623497b130478.jpg', category: 'Acessórios', description: 'Mouse de alta precisão com sensores avançados e iluminação RGB personalizável para gamers.' },
            { id: 8, name: 'Teclado Mecânico', price: 400.00, image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRT7v4_hBRpFke1LOCdKc_wpQk8rkIifTQiNw&s', category: 'Acessórios', description: 'Teclado com switches mecânicos duráveis, resposta tátil e iluminação personalizável para digitação e jogos.' },
        ];

        const getAllProducts = () => products;
        const getProductById = (id) => products.find(p => p.id === id);

        const getUniqueCategories = () => {
            const categories = products.map(product => product.category);
            return ['Todas', ...new Set(categories)];
        };

        const getFilteredProducts = (category = 'Todas', searchTerm = '') => {
            let filtered = products;

            if (category !== 'Todas') {
                filtered = filtered.filter(product => product.category === category);
            }

            if (searchTerm) {
                const lowerCaseSearchTerm = searchTerm.toLowerCase();
                filtered = filtered.filter(product =>
                    product.name.toLowerCase().includes(lowerCaseSearchTerm) ||
                    product.description.toLowerCase().includes(lowerCaseSearchTerm)
                );
            }
            return filtered;
        };

        return {
            getAllProducts,
            getProductById,
            getUniqueCategories,
            getFilteredProducts
        };
    })();

    // --- CartManager Module ---
    const CartManager = (() => {
        let cart = [];
        const CART_STORAGE_KEY = 'minhaLojaOnlineCart';
        const COUPON_STORAGE_KEY = 'minhaLojaOnlineCoupon';

        const availableCoupons = {
            'PROMO10': 0.10, // 10% discount
            'SAVE20': 0.20,  // 20% discount
            'FREE30': 30.00 // R$30 fixed discount
        };
        let appliedCoupon = null;

        const loadCart = () => {
            const storedCart = localStorage.getItem(CART_STORAGE_KEY);
            cart = storedCart ? JSON.parse(storedCart) : [];
            const storedCoupon = localStorage.getItem(COUPON_STORAGE_KEY);
            appliedCoupon = storedCoupon ? JSON.parse(storedCoupon) : null;
        };

        const saveCart = () => {
            localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
            localStorage.setItem(COUPON_STORAGE_KEY, JSON.stringify(appliedCoupon));
        };

        const addToCart = (productId) => {
            const product = ProductManager.getProductById(productId);
            if (!product) return;

            const cartItem = cart.find(item => item.id === productId);

            if (cartItem) {
                cartItem.quantity++;
            } else {
                cart.push({ ...product, quantity: 1 });
            }
            saveCart();
            UIManager.updateCartDisplay();
        };

        const removeFromCart = (productId) => {
            cart = cart.filter(item => item.id !== productId);
            saveCart();
            UIManager.updateCartDisplay();
        };

        const updateQuantity = (productId, change) => {
            const cartItem = cart.find(item => item.id === productId);
            if (cartItem) {
                cartItem.quantity += change;
                if (cartItem.quantity <= 0) {
                    removeFromCart(productId);
                } else {
                    saveCart();
                    UIManager.updateCartDisplay();
                }
            }
        };

        const getSubtotal = () => {
            return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
        };

        const applyCoupon = (couponCode) => {
            couponCode = couponCode.toUpperCase();
            if (availableCoupons[couponCode]) {
                appliedCoupon = {
                    code: couponCode,
                    discount: availableCoupons[couponCode],
                    type: typeof availableCoupons[couponCode] === 'number' && availableCoupons[couponCode] < 1 ? 'percentage' : 'fixed'
                };
                saveCart();
                UIManager.updateCartDisplay();
                return true;
            } else {
                appliedCoupon = null;
                saveCart();
                UIManager.updateCartDisplay();
                return false;
            }
        };

        const clearCoupon = () => {
            appliedCoupon = null;
            saveCart();
            UIManager.updateCartDisplay();
        };

        const getAppliedCoupon = () => appliedCoupon;

        const getCartTotal = () => {
            let total = getSubtotal();
            if (appliedCoupon) {
                if (appliedCoupon.type === 'percentage') {
                    total -= total * appliedCoupon.discount;
                } else if (appliedCoupon.type === 'fixed') {
                    total -= appliedCoupon.discount;
                }
            }
            return Math.max(0, total); // Ensure total doesn't go below zero
        };

        const getCartItemCount = () => {
            return cart.reduce((count, item) => count + item.quantity, 0);
        };

        const clearCart = () => {
            cart = [];
            clearCoupon(); // Also clear coupon when cart is cleared
            saveCart();
            UIManager.updateCartDisplay();
        };

        const getCart = () => [...cart]; // Return a copy to prevent direct modification

        loadCart(); // Load cart when module initializes

        return {
            addToCart,
            removeFromCart,
            updateQuantity,
            getSubtotal,
            getCartTotal,
            getCartItemCount,
            clearCart,
            getCart,
            applyCoupon,
            clearCoupon,
            getAppliedCoupon
        };
    })();

    // --- UIManager Module ---
    const UIManager = (() => {
        const productListDiv = document.getElementById('product-list');
        const cartItemsDiv = document.getElementById('cart-items');
        const cartTotalSpan = document.getElementById('cart-total');
        const cartCountSpan = document.getElementById('cart-count');
        const checkoutButton = document.getElementById('checkout-button');
        const categoryFilterSelect = document.getElementById('category-filter');
        const searchInput = document.getElementById('search-input');

        // Coupon elements
        const couponInput = document.getElementById('coupon-input');
        const applyCouponBtn = document.getElementById('apply-coupon-btn');

        // Modal elements
        const productDetailModal = document.getElementById('product-detail-modal');
        const modalProductImage = document.getElementById('modal-product-image');
        const modalProductName = document.getElementById('modal-product-name');
        const modalProductDescription = document.getElementById('modal-product-description');
        const modalProductPrice = document.getElementById('modal-product-price');
        const modalAddToCartBtn = document.getElementById('modal-add-to-cart-btn');
        const closeButton = document.querySelector('.modal-content .close-button');

        // Toast elements
        const toastContainer = document.getElementById('toast-container');


        const showToast = (message, type = 'info', duration = 3000) => {
            const toast = document.createElement('div');
            toast.classList.add('toast', `toast-${type}`);
            toast.textContent = message;
            toastContainer.appendChild(toast);

            // Trigger reflow to restart animation (important for CSS animations)
            void toast.offsetWidth;

            let timeoutId;

            const dismissToast = () => {
                toast.style.animation = 'fadeOut 0.5s forwards';
                toast.addEventListener('animationend', () => toast.remove());
                clearTimeout(timeoutId); // Clear any pending auto-dismiss
            };

            const startDismissTimer = () => {
                clearTimeout(timeoutId); // Clear any previous timer
                timeoutId = setTimeout(dismissToast, duration);
            };

            // Click to dismiss
            toast.addEventListener('click', dismissToast);

            // Pause on hover
            toast.addEventListener('mouseover', () => clearTimeout(timeoutId));
            toast.addEventListener('mouseleave', startDismissTimer);

            startDismissTimer(); // Start initial dismiss timer
        };




        const renderProducts = (productsToRender) => {
            productListDiv.innerHTML = '';
            if (productsToRender.length === 0) {
                productListDiv.innerHTML = '<p class="no-products">Nenhum produto encontrado com os critérios de busca.</p>';
                return;
            }
            productsToRender.forEach(product => {
                const productCard = document.createElement('div');
                productCard.classList.add('product-card');
                productCard.dataset.productId = product.id; // Add data-product-id
                productCard.innerHTML = `
                    <img src="${product.image}" alt="${product.name}">
                    <h3>${product.name}</h3>
                    <p class="price">R$ ${product.price.toFixed(2)}</p>
                    <button class="btn add-to-cart-btn" data-id="${product.id}">Adicionar ao Carrinho</button>
                `;
                productListDiv.appendChild(productCard);
            });

            // Re-attach event listeners for "Add to Cart" buttons
            document.querySelectorAll('.add-to-cart-btn').forEach(button => {
                button.addEventListener('click', (e) => {
                    e.stopPropagation(); // Prevent modal from opening when clicking add to cart button
                    const productId = parseInt(e.target.dataset.id);
                    CartManager.addToCart(productId);
                });
            });
            // Attach event listeners for product cards to open modal
            document.querySelectorAll('.product-card').forEach(card => {
                card.addEventListener('click', (e) => {
                    const productId = parseInt(e.currentTarget.dataset.productId);
                    openProductModal(productId);
                });
            });
        };

        const renderCategoryFilters = () => {
            const categories = ProductManager.getUniqueCategories();
            categoryFilterSelect.innerHTML = ''; // Clear existing options
            categories.forEach(category => {
                const option = document.createElement('option');
                option.value = category === 'Todas' ? 'all' : category;
                option.textContent = category;
                categoryFilterSelect.appendChild(option);
            });
        };

        const filterAndRenderProducts = () => {
            const selectedCategory = categoryFilterSelect.value === 'all' ? 'Todas' : categoryFilterSelect.value;
            const searchTerm = searchInput.value;
            const filteredProducts = ProductManager.getFilteredProducts(selectedCategory, searchTerm);
            renderProducts(filteredProducts);
        };

        const updateCartDisplay = () => {
            const currentCart = CartManager.getCart();
            cartItemsDiv.innerHTML = '';

            if (currentCart.length === 0) {
                cartItemsDiv.innerHTML = '<p>Nenhum item no carrinho.</p>';
            } else {
                currentCart.forEach(item => {
                    const cartItemDiv = document.createElement('div');
                    cartItemDiv.classList.add('cart-item');
                    cartItemDiv.innerHTML = `
                        <div class="cart-item-info">
                            <h4>${item.name}</h4>
                            <span>${item.quantity} x R$ ${item.price.toFixed(2)}</span>
                        </div>
                        <div class="cart-item-actions">
                            <button class="btn decrease" data-id="${item.id}">-</button>
                            <span>${item.quantity}</span>
                            <button class="btn increase" data-id="${item.id}">+</button>
                            <button class="btn remove" data-id="${item.id}">Remover</button>
                        </div>
                    `;
                    cartItemsDiv.appendChild(cartItemDiv);
                });

                // Re-attach event listeners for cart item actions
                document.querySelectorAll('.cart-item-actions .remove').forEach(button => {
                    button.addEventListener('click', (e) => {
                        const productId = parseInt(e.target.dataset.id);
                        CartManager.removeFromCart(productId);
                    });
                });

                document.querySelectorAll('.cart-item-actions .increase').forEach(button => {
                    button.addEventListener('click', (e) => {
                        const productId = parseInt(e.target.dataset.id);
                        CartManager.updateQuantity(productId, 1);
                    });
                });

                document.querySelectorAll('.cart-item-actions .decrease').forEach(button => {
                    button.addEventListener('click', (e) => {
                        const productId = parseInt(e.target.dataset.id);
                        CartManager.updateQuantity(productId, -1);
                    });
                });
            }

            const subtotal = CartManager.getSubtotal();
            let total = CartManager.getCartTotal();
            const appliedCoupon = CartManager.getAppliedCoupon();

            cartTotalSpan.textContent = total.toFixed(2);
            cartCountSpan.textContent = CartManager.getCartItemCount();

            if (appliedCoupon) {
                // Add a visual indicator for applied coupon
                const couponMessage = document.createElement('p');
                couponMessage.classList.add('coupon-message');
                couponMessage.innerHTML = `Cupom Aplicado: <strong>${appliedCoupon.code}</strong> `;
                if (appliedCoupon.type === 'percentage') {
                    couponMessage.innerHTML += `(-${(appliedCoupon.discount * 100).toFixed(0)}%)`;
                } else if (appliedCoupon.type === 'fixed') {
                    couponMessage.innerHTML += `(-R$ ${appliedCoupon.discount.toFixed(2)})`;
                }
                const clearCouponBtn = document.createElement('button');
                clearCouponBtn.textContent = 'Remover';
                clearCouponBtn.classList.add('btn', 'btn-clear-coupon');
                clearCouponBtn.addEventListener('click', () => {
                    CartManager.clearCoupon();
                    showToast('Cupom removido!', 'info');
                });
                couponMessage.appendChild(clearCouponBtn);
                
                // Find the cart-summary div to insert message
                const cartSummaryDiv = document.querySelector('.cart-summary');
                const existingMessage = cartSummaryDiv.querySelector('.coupon-message');
                if (existingMessage) {
                    existingMessage.remove();
                }
                cartSummaryDiv.insertBefore(couponMessage, cartSummaryDiv.querySelector('p'));
            } else {
                const existingMessage = document.querySelector('.cart-summary .coupon-message');
                if (existingMessage) {
                    existingMessage.remove();
                }
            }
        };

        const openProductModal = (productId) => {
            const product = ProductManager.getProductById(productId);
            if (!product) return;

            modalProductImage.src = product.image;
            modalProductImage.alt = product.name;
            modalProductName.textContent = product.name;
            modalProductDescription.textContent = product.description || 'Nenhuma descrição disponível.';
            modalProductPrice.textContent = `R$ ${product.price.toFixed(2)}`;
            modalAddToCartBtn.dataset.id = product.id;
            productDetailModal.style.display = 'flex';
        };

        const closeProductModal = () => {
            productDetailModal.style.display = 'none';
        };

        const setupEventListeners = () => {
            checkoutButton.addEventListener('click', () => {
                if (CartManager.getCartItemCount() > 0) {
                    UIManager.showToast(`Compra finalizada! Total: R$ ${CartManager.getCartTotal().toFixed(2)}\nObrigado por comprar na Minha Loja Online!`, 'success');
                    CartManager.clearCart();
                } else {
                    UIManager.showToast('Seu carrinho está vazio. Adicione itens antes de finalizar a compra.', 'error');
                }
            });

            categoryFilterSelect.addEventListener('change', filterAndRenderProducts);
            searchInput.addEventListener('input', filterAndRenderProducts);

            closeButton.addEventListener('click', closeProductModal);
            productDetailModal.addEventListener('click', (e) => {
                // Close modal if clicked outside modal-content
                if (e.target === productDetailModal) {
                    closeProductModal();
                }
            });
            modalAddToCartBtn.addEventListener('click', (e) => {
                const productId = parseInt(e.target.dataset.id);
                CartManager.addToCart(productId);
                closeProductModal();
            });

            applyCouponBtn.addEventListener('click', () => {
                const couponCode = couponInput.value.trim();
                if (couponCode) {
                    if (CartManager.applyCoupon(couponCode)) {
                        showToast(`Cupom "${couponCode}" aplicado com sucesso!`, 'success');
                        couponInput.value = ''; // Clear input on success
                    } else {
                        showToast(`Cupom "${couponCode}" inválido ou expirado.`, 'error');
                        CartManager.clearCoupon();
                    }
                } else {
                    CartManager.clearCoupon(); // Clear any existing coupon if input is empty
                    showToast('Nenhum cupom inserido. Cupom desativado.', 'info');
                }
            });
        };

        return {
            renderProducts,
            updateCartDisplay,
            setupEventListeners,
            renderCategoryFilters,
            filterAndRenderProducts, // Expose for initial render after filters are set
            showToast // Expose showToast for CartManager to use
        };
    })();

    // --- Initialize Application ---
    UIManager.renderCategoryFilters(); // Render category filters first
    UIManager.filterAndRenderProducts(); // Render products based on initial filters/search
    UIManager.updateCartDisplay(); // Update cart display
    UIManager.setupEventListeners(); // Setup general event listeners
});
