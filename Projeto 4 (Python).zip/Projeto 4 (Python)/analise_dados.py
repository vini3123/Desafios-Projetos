#Nome: Vinícius Gonçalves
import pandas as pd #type: ignore

def generate_frequency_table(dataframe, column_name):
    """
    Gera uma tabela de frequência e percentual para uma dada coluna categórica.

    Args:
        dataframe (pd.DataFrame): O DataFrame contendo os dados.
        column_name (str): O nome da coluna categórica a ser analisada.

    Returns:
        pd.DataFrame: Uma tabela com a frequência e o percentual da coluna.
    """
    if column_name not in dataframe.columns:
        print(f"Erro: A coluna '{column_name}' não existe no DataFrame.")
        return None

    frequency_table = dataframe[column_name].value_counts().reset_index()
    frequency_table.columns = [column_name, 'Frequência']
    frequency_table['Percentual'] = (frequency_table['Frequência'] / len(dataframe)) * 100
    frequency_table['Percentual'] = frequency_table['Percentual'].round(2)
    return frequency_table

if __name__ == "__main__":
    # Simulação de dados de empréstimos de bibliotecas
    data = {
        'Tipo de vínculo': ['Aluno', 'Professor', 'Servidor', 'Aluno', 'Professor', 'Aluno', 'Servidor', 'Aluno', 'Professor', 'Aluno'],
        'Coleção': ['Literatura', 'Ciências', 'História', 'Literatura', 'Ciências', 'Literatura', 'História', 'Ciências', 'Literatura', 'História'],
        'Biblioteca': ['Central', 'Setorial A', 'Central', 'Setorial B', 'Central', 'Setorial A', 'Setorial B', 'Central', 'Setorial A', 'Central'],
        'Classificação geral da CDU': ['800 Literatura', '500 Ciências Naturais', '900 História', '800 Literatura', '500 Ciências Naturais', '800 Literatura', '900 História', '500 Ciências Naturais', '800 Literatura', '900 História'],
        'Número de Empréstimos': [5, 2, 3, 7, 1, 4, 6, 8, 2, 5]
    }
    df = pd.DataFrame(data)

    print("\n--- Análise de Empréstimos de Bibliotecas ---")

    # Variáveis categóricas a serem analisadas
    categorical_variables = [
        'Tipo de vínculo',
        'Coleção',
        'Biblioteca',
        'Classificação geral da CDU'
    ]

    results = {}
    for col in categorical_variables:
        print(f"\nAnálise para: {col}")
        table = generate_frequency_table(df, col)
        if table is not None:
            print(table.to_string(index=False))
            results[col] = table

    print("\n--- Questionamentos para a diretoria ---")
    print("\n1. Como se distribuem os empréstimos de exemplares pelos tipos de vínculo dos usuários?")
    print("   Percepção: A tabela de 'Tipo de vínculo' mostra a distribuição. Isso pode indicar qual público mais utiliza a biblioteca.")

    print("\n2. Quais coleções são mais emprestadas?")
    print("   Percepção: A tabela de 'Coleção' ranqueia as coleções mais populares, auxiliando na estratégia de aquisição e promoção.")

    print("\n3. Quais são as bibliotecas com mais ou menos quantidade de empréstimos?")
    print("   Percepção: A tabela de 'Biblioteca' destaca o desempenho de cada unidade, indicando onde focar melhorias ou investimentos.")

    print("\n4. De quais temas da CDU são os exemplares emprestados?")
    print("   Percepção: A tabela de 'Classificação geral da CDU' revela os temas mais procurados, essencial para marketing e desenvolvimento de acervo.")

    print("\n--- Outras métricas para enriquecer a análise ---")
    print("- Média de empréstimos por usuário (se houver ID de usuário).")
    print("- Empréstimos por período (mensal, trimestral) para identificar sazonalidade.")
    print("- Comparação de empréstimos por tamanho de biblioteca ou público-alvo específico.")
    print("- Taxa de renovação de empréstimos.")
    print("- Análise de co-ocorrência: quais tipos de livros são emprestados juntos?")
    print("- Tempo médio de posse do livro.")

    print("\n--- Percepções gerais para a diretoria ---")
    print("Com base nas análises das tabelas de frequência e percentual, a diretoria pode:")
    print("- Otimizar a aquisição de novos títulos com base nas coleções e temas mais populares.")
    print("- Desenvolver campanhas de marketing direcionadas a públicos específicos (Tipo de vínculo) ou para promover coleções/temas menos procurados.")
    print("- Alocar recursos de forma mais eficiente entre as diferentes bibliotecas, focando em melhorias onde há menor engajamento ou reforçando o sucesso onde há maior demanda.")
    print("- Avaliar a necessidade de expandir ou diversificar o acervo em áreas de alta demanda ou explorar nichos com potencial.")
    print("- Utilizar as métricas adicionais sugeridas para uma visão mais holística do comportamento dos usuários e do desempenho das bibliotecas.")