import { Routes } from '@angular/router';
import { PostListComponent } from './post-list/post-list';
import { PostDetailsComponent } from './post-details/post-details';

export const routes: Routes = [
  { path: '', component: PostListComponent },
  { path: 'post/:id', component: PostDetailsComponent }
];
