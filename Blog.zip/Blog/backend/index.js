const express = require('express');
const cors = require('cors');
const fs = require('fs'); // Import the 'fs' module
const path = require('path'); // Import the 'path' module

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Read posts from db.json
const dbPath = path.join(__dirname, 'db.json');
let posts = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

app.get('/', (req, res) => {
  res.send('Backend is running!');
});

// Endpoint to get all posts
app.get('/api/posts', (req, res) => {
  res.json(posts);
});

// Endpoint to get a single post by ID
app.get('/api/posts/:id', (req, res) => {
  const postId = parseInt(req.params.id);
  const post = posts.find(p => p.id === postId);
  if (post) {
    res.json(post);
  } else {
    res.status(404).send('Post not found');
  }
});

app.listen(PORT, () => {
  console.log(`Backend server listening at http://localhost:${PORT}`);
});
