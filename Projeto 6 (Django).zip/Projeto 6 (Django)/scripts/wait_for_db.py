import os
import time
import psycopg2
from psycopg2 import OperationalError

def wait_for_db():
    db_host = os.getenv("DB_HOST", "postgres-service")
    db_port = os.getenv("DB_PORT", 5432)
    db_user = os.getenv("DB_USER", "postgres")
    db_password = os.getenv("DB_PASSWORD", "postgres")
    db_name = os.getenv("DB_NAME", "postgres")

    max_retries = 10
    retry_delay = 5

    for i in range(max_retries):
        try:
            conn = psycopg2.connect(
                dbname=db_name,
                user=db_user,
                password=db_password,
                host=db_host,
                port=db_port
            )
            conn.close()
            print("Database is ready!")
            return
        except OperationalError as e:
            print(f"Database not ready, waiting... (attempt {i+1}/{max_retries})")
            time.sleep(retry_delay)
    
    print("Failed to connect to database after multiple attempts")
    exit(1)

if __name__ == "__main__":
    wait_for_db()