#!/bin/bash

python wait_for_db.py
python manage.py migrate
python manage.py collectstatic --noinput
gunicorn django_app.wsgi:application --bind 127.0.0.1:8000