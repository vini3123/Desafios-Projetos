// src/data/mockData.ts

export interface DataPoint {
  date: string;
  value: number;
}

// Gera uma série de dados de série temporal
export function generateStockData(points = 30, initialValue = 100, volatility = 0.02): DataPoint[] {
  const data: DataPoint[] = [];
  let value = initialValue;
  const today = new Date();
 //Retornar a data de hoje
  for (let i = points - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    
    // Simula uma flutuação de preço
    const changePercent = 2 * volatility * Math.random() - volatility;
    value += value * changePercent;

    // Adiciona uma tendência geral para não ficar totalmente aleatório
    value += (Math.random() - 0.4) * 0.5; 
    
    if (value < 0) {
      value = 0;
    }

    data.push({
      date: date.toLocaleDateString('pt-BR', { month: 'short', day: 'numeric' }),
      value: parseFloat(value.toFixed(2)),
    });
  }

  return data;
}

// Gera um novo ponto de dado para simular tempo real
export function generateNewDataPoint(lastPoint: DataPoint): DataPoint {
  const newDate = new Date();
  let value = lastPoint.value;
  const volatility = 0.02;

  const changePercent = 2 * volatility * Math.random() - volatility;
  value += value * changePercent;
  value += (Math.random() - 0.4) * 0.5;

  if (value < 0) {
    value = 0;
  }

  return {
    date: newDate.toLocaleTimeString('pt-BR'),
    value: parseFloat(value.toFixed(2)),
  };
}
