import { useState, FormEvent } from 'react';
import { Form, Button, InputGroup } from 'react-bootstrap';

interface AddStockFormProps {
  onAddStock: (name: string) => void;
}

function AddStockForm({ onAddStock }: AddStockFormProps) {
  const [name, setName] = useState('');

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (name.trim()) {
      onAddStock(name.trim().toUpperCase());
      setName('');
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      <InputGroup className="mb-3">
        <Form.Control
          placeholder="Nome da Ação (ex: PETR4)"
          aria-label="Nome da Ação"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <Button variant="primary" type="submit">
          Adicionar Ação
        </Button>
      </InputGroup>
    </Form>
  );
}

export default AddStockForm;
