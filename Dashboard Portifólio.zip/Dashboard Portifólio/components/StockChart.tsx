import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { DataPoint } from '../data/mockData';

interface StockChartProps {
  data: DataPoint[];
  title: string;
  color: string;
}

function StockChart({ data, title, color }: StockChartProps) {
  return (
    <div style={{ width: '100%', height: 300 }}>
      <h4>{title}</h4>
      <ResponsiveContainer>
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#555" />
          <XAxis dataKey="date" stroke="#ccc" />
          <YAxis stroke="#ccc" domain={['dataMin - 10', 'dataMax + 10']} />
          <Tooltip 
            contentStyle={{ backgroundColor: '#333', border: '1px solid #555' }}
            labelStyle={{ color: '#fff' }}
          />
          <Legend />
          <Line type="monotone" dataKey="value" name={title} stroke={color} strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default StockChart;
