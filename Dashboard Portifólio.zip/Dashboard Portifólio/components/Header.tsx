import { Navbar, Container } from 'react-bootstrap';

const headerStyle = {
  background: 'linear-gradient(90deg, #FF6384, #36A2EB, #FFCE56)',
  borderBottom: '4px solid #F4A261'
};

function Header() {
  return (
    <Navbar style={headerStyle} variant="dark">
      <Container>
        <Navbar.Brand href="#home">
          <strong>Portfólio Dashboard</strong>
        </Navbar.Brand>
      </Container>
    </Navbar>
  );
}

export default Header;
