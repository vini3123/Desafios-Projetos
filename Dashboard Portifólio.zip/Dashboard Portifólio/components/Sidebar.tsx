import { Nav } from 'react-bootstrap';
import DashboardIcon from '@mui/icons-material/Dashboard';
import ShowChartIcon from '@mui/icons-material/ShowChart';
import SettingsIcon from '@mui/icons-material/Settings';

const sidebarLinkStyle = {
  color: 'rgba(255, 255, 255, 0.8)',
  display: 'flex',
  alignItems: 'center',
  gap: '0.8rem',
  padding: '0.5rem 0'
};

const sidebarLinkHoverStyle = {
  color: '#ffffff',
};


function Sidebar() {
  return (
    <Nav className="flex-column">
      <Nav.Link href="#dashboard" style={sidebarLinkStyle}>
        <DashboardIcon />
        Dashboard
      </Nav.Link>
      <Nav.Link href="#stocks" style={sidebarLinkStyle}>
        <ShowChartIcon />
        Ações
      </Nav.Link>
      <Nav.Link href="#settings" style={sidebarLinkStyle}>
        <SettingsIcon />
        Configurações
      </Nav.Link>
    </Nav>
  );
}

export default Sidebar;
