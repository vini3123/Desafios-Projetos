import { useEffect } from 'react';
import { Container, Row, Col, CloseButton } from 'react-bootstrap';
import StockChart from '../components/StockChart';
import { useRealTimeData } from '../hooks/useRealTimeData';
import { vibrantColors } from '../styles/colors';
import AddStockForm from '../components/AddStockForm';

function DashboardPage() {
  const { stocks, addStock, removeStock } = useRealTimeData(2000);

  // Adiciona algumas ações iniciais apenas uma vez
  useEffect(() => {
    addStock('PETR4');
    addStock('MGLU3');
    addStock('VALE3');
    addStock('ITUB4');
  }, [addStock]);


  return (
    <Container fluid>
      <Row>
        <Col>
          <h2 className="mt-3 mb-4 text-light">Visão Geral do Portfólio (Em Tempo Real)</h2>
        </Col>
      </Row>

      <Row className="mb-4">
        <Col md={6}>
          <AddStockForm onAddStock={addStock} />
        </Col>
      </Row>

      <Row>
        {stocks.map((stock, index) => (
          <Col key={stock.name} xs={12} md={6} className="mb-4">
            <div className="p-3" style={{backgroundColor: '#2d343a', borderRadius: '8px'}}>
              <div className="d-flex justify-content-between align-items-center">
                <h4 className="text-light">{stock.name}</h4>
                <CloseButton variant="white" onClick={() => removeStock(stock.name)} />
              </div>
              <StockChart 
                title={stock.name} 
                data={stock.data} 
                color={vibrantColors[index % vibrantColors.length]} 
              />
            </div>
          </Col>
        ))}
         {stocks.length === 0 && (
          <Col>
            <p className="text-light">Nenhuma ação no portfólio. Adicione uma acima para começar!</p>
          </Col>
        )}
      </Row>
    </Container>
  );
}

export default DashboardPage;
