export const vibrantColors = [
  '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40',
  '#E63946', '#F1FAEE', '#A8DADC', '#457B9D', '#1D3557', '#F4A261',
  '#2A9D8F', '#E9C46A', '#F4A261', '#E76F51', '#264653', '#A2D2FF',
  '#BDE0FE', '#FFB4A2', '#FFCDB2', '#E29578', '#83C5BE', '#FFDDD2',
  '#006D77',
];
