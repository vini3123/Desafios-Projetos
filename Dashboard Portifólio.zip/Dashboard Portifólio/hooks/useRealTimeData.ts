import { useState, useEffect, useCallback } from 'react';
import { generateStockData, generateNewDataPoint, DataPoint } from '../data/mockData';

export interface Stock {
  name: string;
  data: DataPoint[];
}

// O hook agora gerencia uma lista dinâmica de ações
export function useRealTimeData(updateInterval = 2000) {
  const [stocks, setStocks] = useState<Stock[]>([]);

  // Efeito para atualizar os dados existentes
  useEffect(() => {
    if (stocks.length === 0) return;

    const intervalId = setInterval(() => {
      setStocks(currentStocks =>
        currentStocks.map(stock => {
          const newDataPoint = generateNewDataPoint(stock.data[stock.data.length - 1]);
          const newData = [...stock.data.slice(1), newDataPoint];
          return { ...stock, data: newData };
        })
      );
    }, updateInterval);

    return () => clearInterval(intervalId);
  }, [stocks.length, updateInterval]); // Depende do número de ações

  // Função para adicionar uma nova ação
  const addStock = useCallback((name: string) => {
    const newStock: Stock = {
      name,
      data: generateStockData(30, 100 + Math.random() * 200, 0.02 + Math.random() * 0.05),
    };
    setStocks(currentStocks => [...currentStocks, newStock]);
  }, []);

  // Função para remover uma ação
  const removeStock = useCallback((name: string) => {
    setStocks(currentStocks => currentStocks.filter(stock => stock.name !== name));
  }, []);

  return { stocks, addStock, removeStock };
}
