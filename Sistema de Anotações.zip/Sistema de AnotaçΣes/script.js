class NotesApp {
    constructor() {
        this.notes = [];
        this.currentNoteId = null;
        this.isEditing = false;
        this.notesContainer = document.getElementById('notes-container');
        this.noteForm = document.getElementById('note-form');
        this.noteModal = document.getElementById('note-modal');
        this.modalTitle = document.getElementById('modal-title');
        this.searchInput = document.getElementById('search-notes');
        this.init();
    }    
    init() {
        this.loadNotes();
        this.setupEventListeners();
        this.renderNotes();
    }
    setupEventListeners() {
        document.getElementById('new-note-btn').addEventListener('click', () => this.openModal());
        document.querySelector('.close-btn').addEventListener('click', () => this.closeModal());
        document.getElementById('cancel-btn').addEventListener('click', () => this.closeModal());
        window.addEventListener('click', (e) => {
            if (e.target === this.noteModal) {
                this.closeModal();
            }
        });        
        this.noteForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveNote();
        });       
        this.searchInput.addEventListener('input', () => this.searchNotes());
        document.getElementById('search-btn').addEventListener('click', () => this.searchNotes());
    }    
    openModal(note = null) {
        if (note) {
            // Modo edição
            this.isEditing = true;
            this.currentNoteId = note.id;
            this.modalTitle.textContent = 'Editar Nota';
            document.getElementById('note-title').value = note.title;
            document.getElementById('note-content').value = note.content;
            document.getElementById('note-color').value = note.color;
        } else {
            // Modo criação
            this.isEditing = false;
            this.currentNoteId = null;
            this.modalTitle.textContent = 'Nova Nota';
            this.noteForm.reset();
        }        
        this.noteModal.style.display = 'flex';
        document.getElementById('note-title').focus();
    }    
    closeModal() {
        this.noteModal.style.display = 'none';
        this.noteForm.reset();
    } 
    saveNote() {
        const title = document.getElementById('note-title').value.trim();
        const content = document.getElementById('note-content').value.trim();
        const color = document.getElementById('note-color').value;       
        if (!title || !content) {
            alert('Por favor, preencha todos os campos');
            return;
        }        
        const now = new Date();
        const noteData = {
            id: this.isEditing ? this.currentNoteId : Date.now().toString(),
            title,
            content,
            color,
            createdAt: this.isEditing ? this.notes.find(n => n.id === this.currentNoteId).createdAt : now,
            updatedAt: now
        };        
        if (this.isEditing) {
            // Atualizar nota existente
            const index = this.notes.findIndex(n => n.id === this.currentNoteId);
            this.notes[index] = noteData;
        } else {
            this.notes.unshift(noteData);
        }        
        this.saveToLocalStorage();
        this.renderNotes();
        this.closeModal();
    }   
    deleteNote(id) {
        if (!confirm('Tem certeza que deseja excluir esta nota?')) return;
        this.notes = this.notes.filter(note => note.id !== id);
        this.saveToLocalStorage();
        this.renderNotes();
    }
    searchNotes() {
        const searchTerm = this.searchInput.value.toLowerCase();
        const filteredNotes = this.notes.filter(note => 
            note.title.toLowerCase().includes(searchTerm) || 
            note.content.toLowerCase().includes(searchTerm)
        );
        this.renderNotes(filteredNotes);
    }
    renderNotes(notesToRender = null) {
        const notes = notesToRender || this.notes;
        this.notesContainer.innerHTML = '';
        if (notes.length === 0) {
            this.showEmptyState();
            return;
        }
        notes.forEach(note => {
            const noteElement = document.createElement('div');
            noteElement.className = 'note';
            noteElement.style.borderTopColor = note.color;
            const createdAt = new Date(note.createdAt);
            const updatedAt = new Date(note.updatedAt);
            const isEdited = updatedAt.getTime() > createdAt.getTime();
            const dateText = isEdited 
            ? `Editada em: ${updatedAt.toLocaleDateString('pt-BR')}`
            : `Criada em: ${createdAt.toLocaleDateString('pt-BR')}`;
            noteElement.innerHTML = `
                <div class="note-header">
                    <h3>${note.title}</h3>
                    <div class="note-actions">
                        <button class="edit-btn" data-id="${note.id}"><i class="fas fa-edit"></i></button>
                        <button class="delete-btn" data-id="${note.id}"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
                <div class="note-content">
                    <p>${note.content}</p>
                </div>
                <div class="note-footer">
                    <small>${dateText}</small>
                </div>
            `;
            this.notesContainer.appendChild(noteElement);
        });
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const noteId = e.currentTarget.getAttribute('data-id');
                const note = this.notes.find(n => n.id === noteId);
                this.openModal(note);
            });
        });
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const noteId = e.currentTarget.getAttribute('data-id');
                this.deleteNote(noteId);
            });
        });
    }  
    showEmptyState() {
        const emptyState = document.createElement('div');
        emptyState.className = 'empty-state';
        emptyState.innerHTML = `
            <i class="fas fa-book-open"></i>
            <h3>Nenhuma nota encontrada</h3>
            <p>${this.searchInput.value ? 'Tente uma busca diferente' : 'Clique em "Nova Nota" para começar'}</p>
        `;
        this.notesContainer.appendChild(emptyState);
    }
    saveToLocalStorage() {
        localStorage.setItem('notes-app', JSON.stringify(this.notes));
    }
    loadNotes() {
        const savedNotes = localStorage.getItem('notes-app');
        this.notes = savedNotes ? JSON.parse(savedNotes) : [];
    }
}
document.addEventListener('DOMContentLoaded', () => {
    new NotesApp();
});