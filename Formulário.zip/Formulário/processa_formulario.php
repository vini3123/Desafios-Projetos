<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Coletar dados do formulário
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $telefone = $_POST['telefone'] ?? '';
    $assunto = $_POST['assunto'] ?? '';
    $mensagem = $_POST['mensagem'] ?? '';
    $newsletter = isset($_POST['newsletter']) ? 'Sim' : 'Não';

    // Validação básica
    if (empty($nome) || empty($email) || empty($mensagem)) {
        echo "Por favor, preencha todos os campos obrigatórios.";
        exit;
    }

    // Configurar e-mail
    $para = "seuemail@example.com";
    $assunto_email = "Novo contato do site: " . $assunto;
    
    $corpo = "Você recebeu uma nova mensagem do formulário de contato:\n\n";
    $corpo .= "Nome: $nome\n";
    $corpo .= "E-mail: $email\n";
    $corpo .= "Telefone: $telefone\n";
    $corpo .= "Assunto: $assunto\n";
    $corpo .= "Mensagem:\n$mensagem\n\n";
    $corpo .= "Deseja receber newsletter: $newsletter";

    $headers = "From: $email";

    // Enviar e-mail
    if (mail($para, $assunto_email, $corpo, $headers)) {
        echo "Mensagem enviada com sucesso!";
    } else {
        echo "Ocorreu um erro ao enviar a mensagem.";
    }
} else {
    echo "Método de requisição inválido.";
}
?>