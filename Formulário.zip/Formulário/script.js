document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Validação simples
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const mensagem = document.getElementById('mensagem').value;
    
    if(nome === '' || email === '' || mensagem === '') {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return;
    }
    
    // Se tudo estiver válido, pode enviar o formulário
    this.submit();
    
    // Ou fazer uma requisição AJAX
    /*
    const formData = new FormData(this);
    
    fetch(this.action, {
        method: this.method,
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert('Mensagem enviada com sucesso!');
        this.reset();
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Ocorreu um erro ao enviar a mensagem.');
    });
    */
});