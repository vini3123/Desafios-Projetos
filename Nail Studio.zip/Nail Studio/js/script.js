document.addEventListener('DOMContentLoaded', () => {
    const clientForm = document.getElementById('client-form');
    const clientNameInput = document.getElementById('client-name');
    const clientPhoneInput = document.getElementById('client-phone');
    const clientServiceInput = document.getElementById('client-service');
    const clientTimeInput = document.getElementById('client-time');
    const clientsList = document.getElementById('clients');

    let clients = JSON.parse(localStorage.getItem('clients')) || [];

    const saveClients = () => {
        localStorage.setItem('clients', JSON.stringify(clients));
    };

    const renderClients = () => {
        clientsList.innerHTML = '';
        clients.forEach((client, index) => {
            const clientItem = document.createElement('div');
            clientItem.classList.add('client-item');
            clientItem.innerHTML = `
                <span>${client.name} - ${client.service} - ${client.time}</span>
                <button data-index="${index}">Excluir</button>
            `;
            clientsList.appendChild(clientItem);
        });
    };

    clientForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const newClient = {
            name: clientNameInput.value,
            phone: clientPhoneInput.value,
            service: clientServiceInput.value,
            time: clientTimeInput.value
        };
        clients.push(newClient);
        saveClients();
        renderClients();
        clientNameInput.value = '';
        clientPhoneInput.value = '';
    });

    clientsList.addEventListener('click', (e) => {
        if (e.target.tagName === 'BUTTON') {
            const index = e.target.getAttribute('data-index');
            clients.splice(index, 1);
            saveClients();
            renderClients();
        }
    });

    renderClients();
});
