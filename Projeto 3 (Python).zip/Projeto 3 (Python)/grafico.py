import pandas as pd # type: ignore
import matplotlib.pyplot as plt # type: ignore

# Supondo que temos um DataFrame chamado 'emprestimos' com os dados
# Caso precise carregar de um arquivo, seria algo como:
# emprestimos = pd.read_csv('dados_emprestimos.csv')

# Como não temos os dados reais, vou criar um exemplo simulando dados de empréstimos
# Em um caso real, você substituiria esta parte pela leitura do seu arquivo de dados

# Criando dados simulados para exemplificação
import numpy as np # type: ignore
np.random.seed(42)

# Gerando datas de 2018 a 2023
datas = pd.date_range(start='2018-01-01', end='2023-12-31', freq='D')
datas = datas[datas.dayofweek < 5]  # Apenas dias úteis

# Criando DataFrame de exemplo
emprestimos = pd.DataFrame({
    'data_emprestimo': np.random.choice(datas, size=5000),
    'exemplares': np.random.randint(1, 5, size=5000),  # 1 a 4 exemplares por empréstimo
    'hora': np.random.randint(8, 18, size=5000)  # Horário de 8h às 17h
})

# 1. Análise anual de empréstimos
emprestimos['ano'] = emprestimos['data_emprestimo'].dt.year
emprestimos_ano = emprestimos.groupby('ano')['exemplares'].sum().reset_index()

plt.figure(figsize=(10, 5))
plt.plot(emprestimos_ano['ano'], emprestimos_ano['exemplares'], marker='o')
plt.title('Evolução Anual de Exemplares Emprestados')
plt.xlabel('Ano')
plt.ylabel('Exemplares Emprestados')
plt.grid(True)
plt.show()

# Análise: Observando o gráfico, podemos ver se a tendência é de aumento, diminuição ou estabilidade
# nos empréstimos ao longo dos anos. Isso ajuda a biblioteca no planejamento de aquisições.

# 2. Análise mensal de empréstimos
emprestimos['mes'] = emprestimos['data_emprestimo'].dt.month
emprestimos_mes = emprestimos.groupby('mes')['exemplares'].sum().reset_index()

plt.figure(figsize=(10, 5))
plt.plot(emprestimos_mes['mes'], emprestimos_mes['exemplares'], marker='o')
plt.title('Exemplares Emprestados por Mês')
plt.xlabel('Mês')
plt.ylabel('Exemplares Emprestados')
plt.xticks(range(1, 13), ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 
                         'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'])
plt.grid(True)
plt.show()

# Análise: Os meses com menor movimento podem ser bons para férias e atividades internas
# Enquanto os meses de pico (como março e setembro) precisam de toda equipe disponível

# 3. Análise horária diária
emprestimos_hora = emprestimos.groupby('hora')['exemplares'].sum().reset_index()

plt.figure(figsize=(10, 5))
plt.bar(emprestimos_hora['hora'], emprestimos_hora['exemplares'])
plt.title('Exemplares Emprestados por Hora do Dia')
plt.xlabel('Hora do Dia')
plt.ylabel('Exemplares Emprestados')
plt.xticks(range(8, 18))
plt.grid(True)
plt.show()

# Análise: Os horários com menor movimento podem ser usados para atividades internas
# enquanto os horários de pico precisam de mais colaboradores no atendimento