#Nome: Vinícius Gonçalves

import pandas as pd

# 1. Criar dados de exemplo
data = {
    'Curso': ['Engenharia', 'Medicina', 'Direito', 'Arquitetura', 'Economia'],
    '2017': [100, 150, 200, 120, 180],
    '2018': [110, 140, 220, 130, 190],
    '2019': [120, 160, 210, 140, 200],
    '2022_Previsao': [130, 170, 230, 150, 210]
}
df = pd.DataFrame(data)

# 2. Calcular diferenças percentuais
df['2017-2018 (%)'] = ((df['2018'] - df['2017']) / df['2017'] * 100).round(2)
df['2018-2019 (%)'] = ((df['2019'] - df['2018']) / df['2018'] * 100).round(2)
df['2019-2022 (%)'] = ((df['2022_Previsao'] - df['2019']) / df['2019'] * 100).round(2)

# Selecionar apenas as colunas de interesse para a tabela final
df_final = df[['Curso', '2017-2018 (%)', '2018-2019 (%)', '2019-2022 (%)']].copy()

# 3. Formatar a tabela HTML
# Capitalizar a primeira letra dos cursos
df_final['Curso'] = df_final['Curso'].apply(lambda x: x.capitalize())

# Função para aplicar cores e símbolo de porcentagem
def format_percentage(value):
    color = 'green' if value >= 0 else 'red'
    return f'<span style="color: {color};">{value:.2f}%</span>'

# Aplicar formatação às colunas percentuais
for col in ['2017-2018 (%)', '2018-2019 (%)', '2019-2022 (%)']:
    df_final[col] = df_final[col].apply(format_percentage)

# Converter para HTML sem índice
html_table = df_final.to_html(index=False, escape=False)

# 4. Aplicar estilos CSS opcionais (EXERCÍCIO OPCIONAL)
css_style = """
<style>
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }
    th {
        font-size: 1.4rem;
        text-align: center;
        font-weight: bold;
        color: whitesmoke;
        background-color: #001692;
        border-radius: 0.25rem;
        box-shadow: 0 0 1rem gray;
        padding: 0.5rem;
    }
    td {
        font-size: 1rem;
        padding: 0.5rem;
        text-align: left;
        font-weight: bold;
        border-bottom: 0.1rem solid lightgray;
    }
    tr:last-child td {
        border-bottom: none;
    }
</style>
"""

final_html = f"""{css_style}
{html_table}
"""

# 5. Salvar a tabela HTML em um arquivo
with open('tabela_emprestimos.html', 'w') as f:
    f.write(final_html)

print("Tabela HTML gerada com sucesso em 'tabela_emprestimos.html'")