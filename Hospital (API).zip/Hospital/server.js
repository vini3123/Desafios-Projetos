const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON bodies
app.use(express.json());

// Root route
app.get('/', (req, res) => {
    res.send('API do Hospital está funcionando!');
});

// Import routes
const patientRoutes = require('./routes/patients');

const doctorRoutes = require('./routes/doctors');

const appointmentRoutes = require('./routes/appointments');

// Use routes
app.use('/api/pacientes', patientRoutes);
app.use('/api/medicos', doctorRoutes);
app.use('/api/consultas', appointmentRoutes);



// Start the server
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
