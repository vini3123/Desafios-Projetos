const express = require('express');
const router = express.Router();
const { readData, writeData } = require('../utils/helpers');
const { randomUUID } = require('crypto');

const APPOINTMENTS_FILE = 'appointments.json';
const PATIENTS_FILE = 'patients.json';
const DOCTORS_FILE = 'doctors.json';

// GET all appointments
router.get('/', (req, res) => {
    const appointments = readData(APPOINTMENTS_FILE);
    res.json(appointments);
});

// POST a new appointment
router.post('/', (req, res) => {
    const { patientId, doctorId, date } = req.body;

    // Basic validation
    if (!patientId || !doctorId || !date) {
        return res.status(400).send('Os campos patientId, doctorId e date são obrigatórios.');
    }

    const patients = readData(PATIENTS_FILE);
    if (!patients.some(p => p.id === patientId)) {
        return res.status(404).send('Paciente não encontrado.');
    }

    const doctors = readData(DOCTORS_FILE);
    if (!doctors.some(d => d.id === doctorId)) {
        return res.status(404).send('Médico não encontrado.');
    }

    const appointments = readData(APPOINTMENTS_FILE);
    const newAppointment = {
        id: randomUUID(),
        patientId,
        doctorId,
        date,
        status: 'agendada'
    };

    appointments.push(newAppointment);
    writeData(APPOINTMENTS_FILE, appointments);
    res.status(201).json(newAppointment);
});

// DELETE an appointment
router.delete('/:id', (req, res) => {
    const appointments = readData(APPOINTMENTS_FILE);
    const newAppointments = appointments.filter(a => a.id !== req.params.id);

    if (appointments.length === newAppointments.length) {
        return res.status(404).send('Consulta não encontrada.');
    }

    writeData(APPOINTMENTS_FILE, newAppointments);
    res.status(204).send();
});

module.exports = router;
