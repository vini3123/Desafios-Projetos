const express = require('express');
const router = express.Router();
const { readData, writeData } = require('../utils/helpers');
const { randomUUID } = require('crypto');

const DOCTORS_FILE = 'doctors.json';

// GET all doctors
router.get('/', (req, res) => {
    const doctors = readData(DOCTORS_FILE);
    res.json(doctors);
});

// GET a single doctor by id
router.get('/:id', (req, res) => {
    const doctors = readData(DOCTORS_FILE);
    const doctor = doctors.find(d => d.id === req.params.id);
    if (!doctor) {
        return res.status(404).send('Médico não encontrado.');
    }
    res.json(doctor);
});

// POST a new doctor
router.post('/', (req, res) => {
    const doctors = readData(DOCTORS_FILE);
    const newDoctor = {
        id: randomUUID(),
        ...req.body
    };
    doctors.push(newDoctor);
    writeData(DOCTORS_FILE, doctors);
    res.status(201).json(newDoctor);
});

// PUT to update a doctor
router.put('/:id', (req, res) => {
    const doctors = readData(DOCTORS_FILE);
    const index = doctors.findIndex(d => d.id === req.params.id);
    if (index === -1) {
        return res.status(404).send('Médico não encontrado.');
    }
    const updatedDoctor = { ...doctors[index], ...req.body };
    doctors[index] = updatedDoctor;
    writeData(DOCTORS_FILE, doctors);
    res.json(updatedDoctor);
});

// DELETE a doctor
router.delete('/:id', (req, res) => {
    const doctors = readData(DOCTORS_FILE);
    const newDoctors = doctors.filter(d => d.id !== req.params.id);
    if (doctors.length === newDoctors.length) {
        return res.status(404).send('Médico não encontrado.');
    }
    writeData(DOCTORS_FILE, newDoctors);
    res.status(204).send();
});

module.exports = router;
