const express = require('express');
const router = express.Router();
const { readData, writeData } = require('../utils/helpers');
const { randomUUID } = require('crypto');

const PATIENTS_FILE = 'patients.json';

// GET all patients
router.get('/', (req, res) => {
    const patients = readData(PATIENTS_FILE);
    res.json(patients);
});

// GET a single patient by id
router.get('/:id', (req, res) => {
    const patients = readData(PATIENTS_FILE);
    const patient = patients.find(p => p.id === req.params.id);
    if (!patient) {
        return res.status(404).send('Paciente não encontrado.');
    }
    res.json(patient);
});

// POST a new patient
router.post('/', (req, res) => {
    const patients = readData(PATIENTS_FILE);
    const newPatient = {
        id: randomUUID(),
        ...req.body
    };
    patients.push(newPatient);
    writeData(PATIENTS_FILE, patients);
    res.status(201).json(newPatient);
});

// PUT to update a patient
router.put('/:id', (req, res) => {
    const patients = readData(PATIENTS_FILE);
    const index = patients.findIndex(p => p.id === req.params.id);
    if (index === -1) {
        return res.status(404).send('Paciente não encontrado.');
    }
    const updatedPatient = { ...patients[index], ...req.body };
    patients[index] = updatedPatient;
    writeData(PATIENTS_FILE, patients);
    res.json(updatedPatient);
});

// DELETE a patient
router.delete('/:id', (req, res) => {
    const patients = readData(PATIENTS_FILE);
    const newPatients = patients.filter(p => p.id !== req.params.id);
    if (patients.length === newPatients.length) {
        return res.status(404).send('Paciente não encontrado.');
    }
    writeData(PATIENTS_FILE, newPatients);
    res.status(204).send();
});

module.exports = router;
