let listaDeCompras = [];

function atualizarLista() {
  const lista = document.getElementById("lista");
  lista.innerHTML = "";

  listaDeCompras.forEach(item => {
    const li = document.createElement("li");
    li.textContent = item;
    lista.appendChild(li);
  });
}

function adicionarItem() {
  const input = document.getElementById("itemInput");
  const item = input.value.trim();

  if (item !== "") {
    listaDeCompras.push(item);
    input.value = "";
    atualizarLista();
    mostrarMensagem(`"${item}" foi adicionado à lista.`);
  } else {
    mostrarMensagem("Digite o nome da comida antes de adicionar.");
  }
}

function removerItem() {
  if (listaDeCompras.length === 0) {
    mostrarMensagem("A lista está vazia. Adicione itens antes de tentar remover.");
    return;
  }

  const itemParaRemover = prompt("Qual item você deseja remover da lista?");
  if (itemParaRemover === null) return;

  const index = listaDeCompras.indexOf(itemParaRemover.trim());

  if (index !== -1) {
    listaDeCompras.splice(index, 1);
    atualizarLista();
    mostrarMensagem(`"${itemParaRemover}" foi removido da lista.`);
  } else {
    mostrarMensagem("Não foi possível encontrar o item dentro da lista!");
  }
}

function mostrarMensagem(msg) {
  const mensagem = document.getElementById("mensagem");
  mensagem.textContent = msg;
  setTimeout(() => mensagem.textContent = "", 4000);
}
