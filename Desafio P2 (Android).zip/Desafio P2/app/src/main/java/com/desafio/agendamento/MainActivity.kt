package com.desafio.agendamento

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.desafio.agendamento.Constants.COLLECTION_USERS
import com.desafio.agendamento.Constants.PROFILE_MEDICO
import com.desafio.agendamento.Constants.PROFILE_PACIENTE
import com.desafio.agendamento.databinding.ActivityMainBinding
import com.desafio.agendamento.models.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Verifica se o usuário já está logado
        if (auth.currentUser != null) {
            checkUserProfileAndNavigate(auth.currentUser!!.uid)
        }

        setupListeners()
    }

    private fun setupListeners() {
        binding.btnLogin.setOnClickListener {
            loginUser()
        }

        binding.btnRegister.setOnClickListener {
            registerUser()
        }
    }

    private fun getSelectedProfile(): String {
        return if (binding.rbPaciente.isChecked) PROFILE_PACIENTE else PROFILE_MEDICO
    }

    private fun loginUser() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Preencha email e senha.", Toast.LENGTH_SHORT).show()
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        checkUserProfileAndNavigate(user.uid)
                    }
                } else {
                    Toast.makeText(this, "Falha no Login: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun registerUser() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        val profile = getSelectedProfile()

        if (email.isEmpty() || password.isEmpty() || password.length < 6) {
            Toast.makeText(this, "Email e senha (mínimo 6 caracteres) são obrigatórios.", Toast.LENGTH_SHORT).show()
            return
        }

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        saveUserProfile(user.uid, email, profile)
                    }
                } else {
                    Toast.makeText(this, "Falha no Registro: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun saveUserProfile(uid: String, email: String, profile: String) {
        val user = User(uid, email, profile)
        db.collection(COLLECTION_USERS).document(uid)
            .set(user)
            .addOnSuccessListener {
                Toast.makeText(this, "Registro e perfil salvos com sucesso!", Toast.LENGTH_SHORT).show()
                navigateToProfileActivity(profile)
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Erro ao salvar perfil: ${e.message}", Toast.LENGTH_LONG).show()
                // Opcional: deslogar o usuário se o perfil não puder ser salvo
                auth.signOut()
            }
    }

    private fun checkUserProfileAndNavigate(uid: String) {
        db.collection(COLLECTION_USERS).document(uid).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val profile = document.getString("profile")
                    if (profile != null) {
                        navigateToProfileActivity(profile)
                    } else {
                        Toast.makeText(this, "Perfil de usuário não encontrado.", Toast.LENGTH_SHORT).show()
                        auth.signOut()
                    }
                } else {
                    Toast.makeText(this, "Dados de usuário não encontrados no Firestore.", Toast.LENGTH_SHORT).show()
                    auth.signOut()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Erro ao buscar perfil: ${e.message}", Toast.LENGTH_LONG).show()
                auth.signOut()
            }
    }

    private fun navigateToProfileActivity(profile: String) {
        val intent = when (profile) {
            PROFILE_PACIENTE -> Intent(this, PacienteActivity::class.java)
            PROFILE_MEDICO -> Intent(this, MedicoActivity::class.java)
            else -> return // Não deve acontecer
        }
        startActivity(intent)
        finish() // Fecha a tela de login para evitar retorno
    }
}
