package com.desafio.agendamento

object Constants {
    const val ALUNO_NOME = "Vinícius Gonçalves Clemente de Araújo"
    const val ALUNO_RA = "210769"
    const val PREF_USER_PROFILE = "user_profile"
    const val PROFILE_PACIENTE = "Paciente"
    const val PROFILE_MEDICO = "Médico"
    const val COLLECTION_USERS = "users"
    const val COLLECTION_APPOINTMENTS = "appointments"
}
