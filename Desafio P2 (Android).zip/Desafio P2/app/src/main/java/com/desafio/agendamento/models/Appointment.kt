package com.desafio.agendamento.models

data class Appointment(
    val patientUid: String = "",
    val patientEmail: String = "",
    val date: String = "",
    val time: String = "",
    val timestamp: Long = 0L
)
