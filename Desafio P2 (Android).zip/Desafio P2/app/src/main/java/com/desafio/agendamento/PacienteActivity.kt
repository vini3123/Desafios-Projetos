package com.desafio.agendamento

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.desafio.agendamento.Constants.COLLECTION_APPOINTMENTS
import com.desafio.agendamento.databinding.ActivityPacienteBinding
import com.desafio.agendamento.models.Appointment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Date

class PacienteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPacienteBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPacienteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        setupListeners()
    }

    private fun setupListeners() {
        binding.btnSchedule.setOnClickListener {
            scheduleAppointment()
        }

        binding.btnLogoutPaciente.setOnClickListener {
            auth.signOut()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun scheduleAppointment() {
        val date = binding.etDate.text.toString().trim()
        val time = binding.etTime.text.toString().trim()
        val user = auth.currentUser

        if (date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Preencha a data e a hora da consulta.", Toast.LENGTH_SHORT).show()
            return
        }

        if (user == null) {
            Toast.makeText(this, "Usuário não autenticado.", Toast.LENGTH_SHORT).show()
            return
        }

        val appointment = Appointment(
            patientUid = user.uid,
            patientEmail = user.email ?: "Email Desconhecido",
            date = date,
            time = time,
            timestamp = Date().time // Usando timestamp para ordenação
        )

        db.collection(COLLECTION_APPOINTMENTS)
            .add(appointment)
            .addOnSuccessListener {
                Toast.makeText(this, "Consulta agendada com sucesso!", Toast.LENGTH_LONG).show()
                binding.etDate.text.clear()
                binding.etTime.text.clear()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Erro ao agendar consulta: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
}
