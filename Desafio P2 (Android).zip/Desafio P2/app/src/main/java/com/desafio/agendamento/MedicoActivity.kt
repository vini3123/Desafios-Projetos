package com.desafio.agendamento

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.desafio.agendamento.Constants.COLLECTION_APPOINTMENTS
import com.desafio.agendamento.adapters.AppointmentAdapter
import com.desafio.agendamento.databinding.ActivityMedicoBinding
import com.desafio.agendamento.models.Appointment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class MedicoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMedicoBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var appointmentAdapter: AppointmentAdapter
    private val appointmentsList = mutableListOf<Appointment>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMedicoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        setupRecyclerView()
        loadAppointments()
        setupListeners()
    }

    private fun setupRecyclerView() {
        appointmentAdapter = AppointmentAdapter(appointmentsList)
        binding.rvAppointments.apply {
            layoutManager = LinearLayoutManager(this@MedicoActivity)
            adapter = appointmentAdapter
        }
    }

    private fun loadAppointments() {
        db.collection(COLLECTION_APPOINTMENTS)
            .orderBy("timestamp", Query.Direction.ASCENDING) // Ordena por data de agendamento
            .get()
            .addOnSuccessListener { result ->
                appointmentsList.clear()
                for (document in result) {
                    val appointment = document.toObject(Appointment::class.java)
                    appointmentsList.add(appointment)
                }
                appointmentAdapter.notifyDataSetChanged()
                if (appointmentsList.isEmpty()) {
                    Toast.makeText(this, "Nenhuma consulta agendada.", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Erro ao carregar consultas: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun setupListeners() {
        binding.btnLogoutMedico.setOnClickListener {
            auth.signOut()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
