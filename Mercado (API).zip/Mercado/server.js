
const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

// Banco de dados em memória
let produtos = [
    { id: 1, nome: 'Coca-Cola Lata', preco: 3.50, quantidade: 100 },
    { id: 2, nome: 'Salgadinho Doritos', preco: 5.00, quantidade: 50 },
    { id: 3, nome: 'Barra de Chocolate', preco: 4.00, quantidade: 75 },
    { id: 4, nome: 'Pepsi', preco: 3.00, quantidade: 40 },
    { id: 5, nome: 'Biscoitos', preco: 1.00, quantidade: 50 }
];
let proximoId = 4;

// Rota para listar todos os produtos
app.get('/produtos', (req, res) => {
    res.json(produtos);
});

// Rota para obter um produto por ID
app.get('/produtos/:id', (req, res) => {
    const produto = produtos.find(p => p.id === parseInt(req.params.id));
    if (!produto) {
        return res.status(404).send('Produto não encontrado.');
    }
    res.json(produto);
});

// Rota para adicionar um novo produto
app.post('/produtos', (req, res) => {
    const { nome, preco, quantidade } = req.body;
    if (!nome || !preco || quantidade === undefined) {
        return res.status(400).send('Nome, preço e quantidade são obrigatórios.');
    }

    const novoProduto = {
        id: proximoId++,
        nome,
        preco,
        quantidade
    };

    produtos.push(novoProduto);
    res.status(201).json(novoProduto);
});

// Rota para atualizar um produto
app.put('/produtos/:id', (req, res) => {
    const produto = produtos.find(p => p.id === parseInt(req.params.id));
    if (!produto) {
        return res.status(404).send('Produto não encontrado.');
    }

    const { nome, preco, quantidade } = req.body;
    if (nome) produto.nome = nome;
    if (preco) produto.preco = preco;
    if (quantidade !== undefined) produto.quantidade = quantidade;

    res.json(produto);
});

// Rota para deletar um produto
app.delete('/produtos/:id', (req, res) => {
    const index = produtos.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
        return res.status(404).send('Produto não encontrado.');
    }

    produtos.splice(index, 1);
    res.status(204).send();
});

app.listen(port, () => {
    console.log(`Servidor da loja rodando em http://localhost:${port}`);
});
