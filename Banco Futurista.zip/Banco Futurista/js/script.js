document.addEventListener('DOMContentLoaded', () => {

    // --- Global State ---
    const state = {
        initialBalance: 12345.67,
        transactions: [
            { type: 'deposit', description: 'Salário Mensal', amount: 3500.00, category: 'Salário' },
            { type: 'withdrawal', description: 'Supermercado', amount: -150.25, category: 'Mercado' },
            { type: 'withdrawal', description: 'Compras Online', amount: -299.99, category: 'Compras' },
            { type: 'withdrawal', description: 'Pagamento de Aluguel', amount: -1200.00, category: 'Moradia' },
            { type: 'deposit', description: 'Projeto Freelancer', amount: 500.00, category: 'Salário' },
            { type: 'withdrawal', description: 'Posto de Gasolina', amount: -60.00, category: 'Transporte' },
        ],
    };

    // --- Selectors ---
    const balanceAmountEl = document.querySelector('.balance-amount');
    const transactionListEl = document.querySelector('.transaction-list');
    const transferForm = document.querySelector('.transfer-form');
    const chartContainer = document.querySelector('.chart-container');

    // --- Functions ---

    function updateBalance() {
        const currentBalance = state.initialBalance + state.transactions.reduce((acc, tx) => acc + tx.amount, 0);
        balanceAmountEl.textContent = `R$${currentBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    
    function renderTransactions() {
        transactionListEl.innerHTML = ''; // Clear existing list
        state.transactions.slice().reverse().forEach(tx => { // Reverse to show newest first, and slice to avoid modifying original array
            const listItem = document.createElement('li');
            listItem.style.display = 'flex';
            listItem.style.justifyContent = 'space-between';
            listItem.style.padding = '0.8rem 0.5rem';
            listItem.style.borderLeft = `4px solid ${tx.type === 'deposit' ? 'var(--green)' : 'var(--red)'}`;

            const descriptionSpan = document.createElement('span');
            descriptionSpan.textContent = tx.description;

            const amountSpan = document.createElement('span');
            amountSpan.textContent = `${tx.amount < 0 ? '-' : ''}R$${Math.abs(tx.amount).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            amountSpan.style.fontWeight = 'bold';
            amountSpan.style.color = tx.type === 'deposit' ? 'var(--green)' : 'var(--red)';

            listItem.appendChild(descriptionSpan);
            listItem.appendChild(amountSpan);
            transactionListEl.prepend(listItem); // Prepend to show newest first
        });
    }

    function calculateSpendingData() {
        const spending = {};
        state.transactions.filter(tx => tx.type === 'withdrawal').forEach(tx => {
            const category = tx.category || 'Outros'; // Assign 'Outros' if no category
            if (!spending[category]) {
                spending[category] = 0;
            }
            spending[category] += Math.abs(tx.amount);
        });
        return Object.keys(spending).map(category => ({
            category: category,
            amount: spending[category]
        }));
    }

    function handleTransfer(event) {
        event.preventDefault();
        const recipientInput = transferForm.querySelector('input[type="text"]');
        const amountInput = transferForm.querySelector('input[type="number"]');
        
        const recipient = recipientInput.value;
        const amount = parseFloat(amountInput.value);

        if (recipient && amount > 0) {
            const newTransaction = {
                type: 'withdrawal',
                description: `Transferência para ${recipient}`,
                amount: -amount,
                category: 'Transferências' // Assign a category for transfers
            };
            state.transactions.push(newTransaction);
            
            // Re-render UI
            updateBalance();
            renderTransactions();
            buildChart(); // Rebuild chart after new transaction

            // Clear form
            recipientInput.value = '';
            amountInput.value = '';
        }
    }
    
    function buildChart() {
        chartContainer.innerHTML = ''; // Clear existing chart
        const spendingData = calculateSpendingData();
        
        if (spendingData.length === 0) {
            chartContainer.textContent = 'Sem dados de gastos para exibir.';
            chartContainer.style.justifyContent = 'center';
            chartContainer.style.alignItems = 'center';
            return;
        }

        chartContainer.style.justifyContent = 'space-around';
        chartContainer.style.alignItems = 'flex-end';


        const maxAmount = Math.max(...spendingData.map(d => d.amount));

        spendingData.forEach(item => {
            const bar = document.createElement('div');
            const height = (item.amount / maxAmount) * 100;
            bar.style.width = `${100 / spendingData.length - 5}%`; // Distribute bars evenly
            bar.style.height = `${height}%`;
            bar.style.backgroundColor = 'var(--panel-bg)';
            bar.style.border = '2px solid';
            bar.style.borderImage = 'linear-gradient(to top, var(--glow-color-2), var(--glow-color-3)) 1';
            bar.style.borderBottom = 'none';
            bar.dataset.category = item.category;
            bar.dataset.amount = item.amount;
            bar.style.position = 'relative'; // Needed for tooltip positioning

            // Add category label below the bar
            const categoryLabel = document.createElement('div');
            categoryLabel.textContent = item.category;
            categoryLabel.className = 'chart-bar-label'; // Add class for styling
            categoryLabel.style.position = 'absolute';
            categoryLabel.style.bottom = '-1.5rem';
            categoryLabel.style.left = '50%';
            categoryLabel.style.transform = 'translateX(-50%)';
            categoryLabel.style.whiteSpace = 'nowrap';
            bar.appendChild(categoryLabel);

            chartContainer.appendChild(bar);
        });
    }
    
    function createChartTooltips() {
        const tooltip = document.createElement('div');
        tooltip.className = 'chart-tooltip';
        document.body.appendChild(tooltip);

        chartContainer.addEventListener('mouseover', (e) => {
            if (e.target.dataset.category) {
                const rect = e.target.getBoundingClientRect();
                tooltip.style.display = 'block';
                tooltip.style.left = `${rect.left + window.scrollX + rect.width / 2}px`;
                tooltip.style.top = `${rect.top + window.scrollY - 10}px`;
                tooltip.innerHTML = `<strong>${e.target.dataset.category}</strong><br>R$${parseFloat(e.target.dataset.amount).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            }
        });

        chartContainer.addEventListener('mouseout', () => {
            tooltip.style.display = 'none';
        });
    }

    // --- Initial App Load ---
    function init() {
        // Add categories to initial transactions
        state.transactions = state.transactions.map(tx => {
            if (!tx.category) {
                if (tx.description.includes('Salário')) tx.category = 'Salário';
                else if (tx.description.includes('Supermercado')) tx.category = 'Mercado';
                else if (tx.description.includes('Compras Online')) tx.category = 'Compras';
                else if (tx.description.includes('Aluguel')) tx.category = 'Moradia';
                else if (tx.description.includes('Freelancer')) tx.category = 'Salário';
                else if (tx.description.includes('Gasolina')) tx.category = 'Transporte';
                else tx.category = 'Outros';
            }
            return tx;
        });

        if (balanceAmountEl) updateBalance();
        if (transactionListEl) renderTransactions();
        if (transferForm) transferForm.addEventListener('submit', handleTransfer);
        
        if (chartContainer) {
            chartContainer.style.display = 'flex';
            chartContainer.style.justifyContent = 'space-around';
            chartContainer.style.alignItems = 'flex-end';
            chartContainer.style.height = '150px';
            chartContainer.style.padding = '1rem';
            buildChart(); // Initial chart build
            createChartTooltips();
        }
    }

    init();
});