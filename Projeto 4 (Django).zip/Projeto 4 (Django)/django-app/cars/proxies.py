import requests
from django.conf import settings
from requests.exceptions import RequestException

class ExternalServices:
    @staticmethod
    def get_cars():
        try:
            response = requests.get(f"{settings.EXPRESS_SERVICE_URL}/api/cars")
            response.raise_for_status()
            return response.json()
        except RequestException as e:
            return {'error': str(e)}

    @staticmethod
    def analyze_sentiment(text):
        try:
            response = requests.post(
                settings.SENTIMENT_SERVICE_URL,
                json={'text': text},
                headers={'Content-Type': 'application/json'}
            )
            response.raise_for_status()
            return response.json()
        except RequestException as e:
            return {'error': str(e)}