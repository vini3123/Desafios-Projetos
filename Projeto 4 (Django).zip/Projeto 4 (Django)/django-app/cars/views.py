from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from .proxies import ExternalServices

@require_http_methods(["GET"])
def car_list(request):
    data = ExternalServices.get_cars()
    return JsonResponse(data, safe=False)

@require_http_methods(["POST"])
def analyze_sentiment(request):
    text = request.POST.get('text') or request.body.decode('utf-8')
    if not text:
        return JsonResponse({'error': 'Text is required'}, status=400)
    
    analysis = ExternalServices.analyze_sentiment(text)
    return JsonResponse(analysis)