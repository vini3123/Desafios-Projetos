from django.db import models

class CarMake(models.Model):
    name = models.CharField(max_length=100, unique=True)
    country = models.CharField(max_length=100)
    founded = models.IntegerField()
    description = models.TextField(blank=True)

    class Meta:
        verbose_name = "Car Manufacturer"
        verbose_name_plural = "Car Manufacturers"
        ordering = ['name']

    def __str__(self):
        return self.name

class CarModel(models.Model):
    CAR_TYPES = [
        ('SEDAN', 'Sedan'),
        ('SUV', 'SUV'),
        ('TRUCK', 'Truck'),
        ('HATCH', 'Hatchback'),
        ('COUPE', 'Coupe'),
    ]

    make = models.ForeignKey(CarMake, on_delete=models.CASCADE, related_name='models')
    name = models.CharField(max_length=100)
    year = models.IntegerField()
    car_type = models.CharField(max_length=50, choices=CAR_TYPES)
    production_start = models.DateField()
    production_end = models.DateField(null=True, blank=True)

    class Meta:
        verbose_name = "Car Model"
        verbose_name_plural = "Car Models"
        ordering = ['make', '-year']
        unique_together = ['make', 'name', 'year']

    def __str__(self):
        return f"{self.make.name} {self.name} ({self.year})"