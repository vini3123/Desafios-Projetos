const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
const carsRouter = require('./routes/cars');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Database
connectDB();

// Routes
app.use('/api/cars', carsRouter);

// Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Express server running on port ${PORT}`);
});