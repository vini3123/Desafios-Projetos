# Configurações para serviços externos
EXPRESS_SERVICE_URL = os.getenv('EXPRESS_SERVICE_URL', 'http://express:3000')
SENTIMENT_SERVICE_URL = os.getenv('SENTIMENT_SERVICE_URL', 'http://sentiment:5000/analyze')

# Configurações de proxy
PROXY_SETTINGS = {
    'timeout': 10,  # segundos
    'retries': 2,
    'headers': {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
}