// Jogo de Escolha de Carreira em Desenvolvimento de Software

// Boas-vindas
alert("Bem-vindo ao Jogo de Carreira em Desenvolvimento de Software!");

// Passo 1: Escolha entre Front-End e Back-End
let area = prompt("Você quer seguir para área de Front-End ou Back-End? Digite 'Front' ou 'Back':");

let linguagem = "";

// Passo 2: Escolha de tecnologia específica
if (area.toLowerCase() === "front") {
    linguagem = prompt("Você quer aprender React ou Vue?");
} else if (area.toLowerCase() === "back") {
    linguagem = prompt("Você quer aprender C# ou Java?");
} else {
    alert("Você não inseriu uma área válida!");
}

// Passo 3: Escolha entre especialização ou Fullstack
if (linguagem) {
    let especializacao = prompt(`Você quer se especializar em ${linguagem} ou se tornar Fullstack? Digite 'Especializar' ou 'Fullstack':`);
    
    if (especializacao.toLowerCase() === "especializar") {
        alert(`Ótima escolha! Dominar ${linguagem} é um grande diferencial na área de ${area === "front" ? "Front-End" : "Back-End"}!`);
    } else if (especializacao.toLowerCase() === "fullstack") {
        alert("Ótimo! Desenvolvedores Fullstack são muito valorizados no mercado!");
    } else {
        alert("Opção inválida!");
    }
}

// Passo 4: Lista de tecnologias para aprender
let tecnologias = [];
let continuar = true;

alert("Agora vamos listar as tecnologias que você gostaria de aprender!");

while (continuar) {
    let tecnologia = prompt("Digite o nome de uma tecnologia que você gostaria de aprender:");
    tecnologias.push(tecnologia);
    
    // Mensagem sobre a tecnologia
    switch(tecnologia.toLowerCase()) {
        case "javascript":
            alert("JavaScript é a linguagem da web! Ótima escolha!");
            break;
        case "python":
            alert("Python é versátil e fácil de aprender. Excelente!");
            break;
        case "html":
            alert("HTML é a base da web. Fundamental!");
            break;
        case "css":
            alert("CSS transforma sites simples em obras de arte!");
            break;
        default:
            alert(`${tecnologia} é uma ótima tecnologia para se aprender!`);
    }
    
    let resposta = prompt("Tem mais alguma tecnologia que você gostaria de aprender? (Digite 'sim' ou 'não')");
    if (resposta.toLowerCase() !== "sim") {
        continuar = false;
    }
}

// Resumo final
alert(`Resumo da sua jornada:
Área escolhida: ${area === "front" ? "Front-End" : "Back-End"}
Tecnologia principal: ${linguagem}
Tecnologias que quer aprender: ${tecnologias.join(", ")}

Boa sorte na sua jornada como desenvolvedor(a)!`);